import os
import sys
from pathlib import Path
from typing import Dict, List

import matplotlib
import numpy as np
matplotlib.use("Agg")
import matplotlib.pyplot as plt

matplotlib.rcParams["font.family"] = "Times New Roman"
matplotlib.rcParams["axes.unicode_minus"] = False


SCRIPT_DIR = Path(__file__).resolve().parent
SECTION_421_DIR = SCRIPT_DIR.parent
INPUT_XLSX = str(SECTION_421_DIR / "case_analysis_results_table5_fig7.xlsx")
OUTPUT_PNG = str(SCRIPT_DIR / "Fig_7_resource_utilization.png")

SHEET_PAYLOAD = "Sheet2"
SHEET_RANGE = "Sheet3"

LABELS = ["C_1", "C_2", "C_3", "C_4"]

# Colors roughly matching the reference image
PAYLOAD_COLORS = ["#eaeff6", "#cae2f8", "#87b0d6", "#2f5d91"]
RANGE_COLORS = ["#dceccf", "#b8dca6", "#8cc37a", "#2f6b3a"]


def _normalize_header(text: str) -> str:
    return "".join(ch for ch in text.strip() if ch.isalnum() or ch in ("_", "-"))


def _read_sheet_columns_with_openpyxl(path: str, sheet_name: str) -> Dict[str, List[float]]:
    try:
        import openpyxl
    except Exception as exc:
        raise RuntimeError("openpyxl is required to read .xlsx files. Install with: pip install openpyxl") from exc

    wb = openpyxl.load_workbook(path, data_only=True)
    if sheet_name not in wb.sheetnames:
        raise ValueError(f"Sheet not found: {sheet_name}")

    ws = wb[sheet_name]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        raise ValueError(f"Empty sheet: {sheet_name}")

    header = [str(c).strip() if c is not None else "" for c in rows[0]]
    norm_header = [_normalize_header(h) for h in header]

    data_map: Dict[str, List[float]] = {label: [] for label in LABELS}

    for label in LABELS:
        # support headers like C_1 or C_1(Small)
        candidates = [i for i, h in enumerate(norm_header) if h.startswith(label)]
        if not candidates:
            continue
        col_idx = candidates[0]
        for r in rows[1:]:
            if col_idx >= len(r):
                continue
            val = r[col_idx]
            try:
                if val is None:
                    continue
                data_map[label].append(float(val))
            except (ValueError, TypeError):
                continue

    return data_map


def _plot_box(ax, data_map: Dict[str, List[float]], title: str, colors: List[str]):
    data = [data_map.get(label, []) for label in LABELS]
    positions = [1.0, 1.7, 2.4, 3.1]
    bp = ax.boxplot(
        data,
        positions=positions,
        widths=0.45,
        patch_artist=True,
        labels=LABELS,
        showfliers=False,
    )

    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_edgecolor("#444444")
        patch.set_linewidth(1.0)

    for element in ["whiskers", "caps", "medians"]:
        for line in bp[element]:
            line.set_color("#444444")
            line.set_linewidth(1.0)

    # Overlay data points (light gray) with jitter
    rng = np.random.default_rng(42)
    for i, values in enumerate(data, start=1):
        if not values:
            continue
        jitter = rng.uniform(-0.08, 0.08, size=len(values))
        x = np.full(len(values), positions[i - 1]) + jitter
        ax.scatter(x, values, s=4, c="#C0C0C0", alpha=0.6, zorder=3, marker='o')

    ax.set_title(title)
    ax.set_xlabel("Instance Label")
    ax.set_ylabel("Ratio (0-1)")


def main():
    if not os.path.exists(INPUT_XLSX):
        raise FileNotFoundError(f"Input file not found: {INPUT_XLSX}")

    payload = _read_sheet_columns_with_openpyxl(INPUT_XLSX, SHEET_PAYLOAD)
    rng = _read_sheet_columns_with_openpyxl(INPUT_XLSX, SHEET_RANGE)

    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.2), dpi=600)
    _plot_box(axes[0], payload, "Payload Utilization", PAYLOAD_COLORS)
    _plot_box(axes[1], rng, "Range Utilization", RANGE_COLORS)

    fig.tight_layout()
    fig.savefig(OUTPUT_PNG, dpi=600)
    print(f"Saved: {OUTPUT_PNG}")


if __name__ == "__main__":
    main()
