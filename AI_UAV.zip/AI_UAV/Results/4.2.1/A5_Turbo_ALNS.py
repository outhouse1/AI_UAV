import os
import time
import math
import random
import traceback
import warnings
import csv
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from numba import jit

# ==========================================
# 1. 环境配置
# ==========================================
warnings.filterwarnings("ignore")
try:
    matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
except:
    pass

def get_safe_cmap(name='tab20'):
    try:
        return matplotlib.colormaps[name]
    except AttributeError:
        return plt.cm.get_cmap(name)

def _ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

# ==========================================
# 2. Numba 加速核心函数 (极速版)
# ==========================================

@jit(nopython=True)
def calc_dist_matrix_haversine(lat_rad, lon_rad, size):
    """预计算地线距离矩阵 (km)"""
    R = 6371.0
    matrix = np.zeros((size, size), dtype=np.float64)
    for i in range(size):
        for j in range(size):
            dlat = lat_rad[j] - lat_rad[i]
            dlon = lon_rad[j] - lon_rad[i]
            a = (math.sin(dlat / 2.0) ** 2 +
                 math.cos(lat_rad[i]) * math.cos(lat_rad[j]) *
                 math.sin(dlon / 2.0) ** 2)
            c = 2.0 * math.asin(math.sqrt(a))
            matrix[i, j] = R * c
    return matrix

@jit(nopython=True)
def calc_delta_dist(dist_matrix, prev_node, next_node, target_node):
    """
    O(1) 计算插入一个节点带来的距离增量
    Delta = D(prev, target) + D(target, next) - D(prev, next)
    """
    return (dist_matrix[prev_node, target_node] +
            dist_matrix[target_node, next_node] -
            dist_matrix[prev_node, next_node])

@jit(nopython=True)
def calc_route_cost_numba(route, depot_idx, dist_matrix):
    """计算单条路线总距离"""
    cost = 0.0
    curr = depot_idx
    for i in range(len(route)):
        n = route[i]
        cost += dist_matrix[curr, n]
        curr = n
    cost += dist_matrix[curr, depot_idx]
    return cost

# ==========================================
# 3. 数据结构
# ==========================================

class MDVRPInstanceCSV:
    def __init__(self, supply_path, demand_path, model_name="DJI FlyCart 100",
                 max_payload=80.0, max_range_km=45.0, speed_kmh=54.0):
        self.supply_path = supply_path
        self.demand_path = demand_path
        self.model_name = model_name
        self.max_payload = float(max_payload)
        self.max_range_km = float(max_range_km)
        self.speed_kmh = float(speed_kmh)

        self.m = 0
        self.n = 0
        self.d = 0
        self.D = 0.0
        self.Q = 0.0
        self.nodes = []
        self.np_lat = None
        self.np_lon = None
        self.np_demands = None
        self.np_services = None
        self.dist_matrix = None
        self.max_vehicles_per_depot = 0
        self.invalid_supply_rows = 0
        self.invalid_demand_rows = 0

    @staticmethod
    def _normalize_row(row):
        clean = {}
        for k, v in row.items():
            if k is None:
                continue
            key = k.replace('\ufeff', '').strip().lower()
            clean[key] = v
        return clean

    @staticmethod
    def _to_float(value, default=None):
        if value is None:
            return default
        if isinstance(value, (int, float)):
            return float(value)
        s = str(value).strip()
        if s == '' or s.lower() in ('na', 'nan', 'null'):
            return default
        try:
            return float(s)
        except ValueError:
            return default

    def _read_supply(self, path):
        supply = []
        with open(path, 'r', encoding='utf-8-sig', errors='ignore') as f:
            reader = csv.DictReader(f)
            for row in reader:
                r = self._normalize_row(row)
                lat = self._to_float(r.get('latitude', None), None)
                lon = self._to_float(r.get('longitude', None), None)
                if lat is None or lon is None:
                    self.invalid_supply_rows += 1
                    continue
                supply.append((lat, lon))
        return supply

    def _read_demand(self, path):
        demand = []
        with open(path, 'r', encoding='utf-8-sig', errors='ignore') as f:
            reader = csv.DictReader(f)
            for row in reader:
                r = self._normalize_row(row)
                lat = self._to_float(r.get('latitude', None), None)
                lon = self._to_float(r.get('longitude', None), None)
                dem = self._to_float(r.get('demand', None), None)
                if lat is None or lon is None or dem is None:
                    self.invalid_demand_rows += 1
                    continue
                demand.append((lat, lon, dem))
        return demand

    def load(self):
        supply = self._read_supply(self.supply_path)
        demand = self._read_demand(self.demand_path)

        self.n = len(demand)
        self.d = len(supply)
        self.m = 0
        self.Q = self.max_payload
        self.D = self.max_range_km

        total_demand = sum(d[2] for d in demand)
        if self.d > 0:
            self.max_vehicles_per_depot = 5
        else:
            self.max_vehicles_per_depot = 0

        lat_list, lon_list, dem_list, serv_list = [], [], [], []

        # 需求点 (前 n)
        for i, (lat, lon, dem) in enumerate(demand):
            self.nodes.append({'id': i, 'idx': i})
            lat_list.append(lat)
            lon_list.append(lon)
            dem_list.append(dem)
            serv_list.append(0.0)

        # 供应点 (后 d)
        for j, (lat, lon) in enumerate(supply):
            idx = self.n + j
            self.nodes.append({'id': idx, 'idx': idx})
            lat_list.append(lat)
            lon_list.append(lon)
            dem_list.append(0.0)
            serv_list.append(0.0)

        self.np_lat = np.radians(np.array(lat_list, dtype=np.float64))
        self.np_lon = np.radians(np.array(lon_list, dtype=np.float64))
        self.np_demands = np.array(dem_list, dtype=np.float64)
        self.np_services = np.array(serv_list, dtype=np.float64)

        self.dist_matrix = calc_dist_matrix_haversine(self.np_lat, self.np_lon, len(self.nodes))

class Solution:
    def __init__(self, instance):
        self.inst = instance
        # routes: {depot_idx: [ np.array([nodes]), ... ]}
        self.routes = {d: [] for d in range(instance.n, instance.n + instance.d)}
        self.cost = 0.0
        self.unassigned = []

    def copy(self):
        new_sol = Solution(self.inst)
        new_routes = {}
        for d, r_list in self.routes.items():
            new_routes[d] = [r.copy() for r in r_list]
        new_sol.routes = new_routes
        new_sol.cost = self.cost
        new_sol.unassigned = list(self.unassigned)
        return new_sol

    def evaluate(self):
        total_dist = 0.0
        penalty = 0.0
        feasible = True

        for d_idx, d_routes in self.routes.items():
            for r in d_routes:
                if len(r) == 0:
                    continue
                # 使用 Numba 加速路线距离计算
                dist = calc_route_cost_numba(r, d_idx, self.inst.dist_matrix)
                total_dist += dist

                # 容量检查
                load = np.sum(self.inst.np_demands[r])
                if load > self.inst.Q:
                    penalty += (load - self.inst.Q) * 10000
                    feasible = False

                # 航程检查
                if self.inst.D > 0:
                    dur = dist + np.sum(self.inst.np_services[r])
                    if dur > self.inst.D:
                        penalty += (dur - self.inst.D) * 10000
                        feasible = False

        if self.unassigned:
            penalty += len(self.unassigned) * 1e8
            feasible = False

        self.cost = total_dist + penalty
        return total_dist, feasible

    def get_route_records(self):
        records = []
        total_routes = 0
        for d_idx, d_routes in self.routes.items():
            for r_idx, r in enumerate(d_routes):
                if len(r) == 0:
                    continue
                dist = calc_route_cost_numba(r, d_idx, self.inst.dist_matrix)
                load = float(np.sum(self.inst.np_demands[r]))
                utilization = load / self.inst.Q if self.inst.Q > 0 else 0.0
                travel_time = dist / self.inst.speed_kmh if self.inst.speed_kmh > 0 else 0.0
                records.append({
                    'depot_idx': int(d_idx),
                    'route_id': int(r_idx),
                    'num_nodes': int(len(r)),
                    'distance_km': float(dist),
                    'load_kg': float(load),
                    'load_utilization': float(utilization),
                    'max_payload_kg': float(self.inst.Q),
                    'max_range_km': float(self.inst.D),
                    'speed_kmh': float(self.inst.speed_kmh),
                    'travel_time_h': float(travel_time),
                    'node_indices': ';'.join(str(int(x)) for x in r.tolist()),
                    'node_demands': ';'.join(str(float(self.inst.np_demands[x])) for x in r.tolist())
                })
                total_routes += 1
        return records, total_routes

# ==========================================
# 4. ALNS Turbo Solver (深度优化版)
# ==========================================

class ALNSTurboSolver:
    def __init__(self, instance, seed=42):
        self.inst = instance
        random.seed(seed)
        np.random.seed(seed)

        # SA 参数
        self.sigma = [30, 15, 5]
        self.reaction = 0.1
        self.min_rem = 1
        self.max_rem = min(40, int(instance.n * 0.4))

        # 权重系统 (简化以提升速度)
        self.ops_d = ['random']
        self.ops_r = ['greedy']
        self.w_d = [1.0]; self.s_d = [0.0]; self.c_d = [0]
        self.w_r = [1.0]; self.s_r = [0.0]; self.c_r = [0]

    def _check_basic_feasibility(self):
        too_heavy = []
        too_far = []
        for i in range(self.inst.n):
            if self.inst.np_demands[i] > self.inst.Q:
                too_heavy.append(i)
        if self.inst.D > 0 and self.inst.d > 0:
            depot_slice = slice(self.inst.n, self.inst.n + self.inst.d)
            for i in range(self.inst.n):
                min_round = float(np.min(self.inst.dist_matrix[i, depot_slice]) * 2.0)
                if min_round > self.inst.D:
                    too_far.append(i)
        return too_heavy, too_far

    def _destroy_random(self, sol, q):
        routes_list = []
        for d, r_list in sol.routes.items():
            for r_idx, r in enumerate(r_list):
                for n in r:
                    routes_list.append((d, r_idx, n))

        if not routes_list:
            return

        targets = random.sample(routes_list, min(q, len(routes_list)))
        removed_nodes = set()

        temp_routes = {d: [list(r) for r in rs] for d, rs in sol.routes.items()}

        for d, r_idx, n in targets:
            if n not in removed_nodes:
                try:
                    temp_routes[d][r_idx].remove(n)
                    removed_nodes.add(n)
                except ValueError:
                    pass

        for d in temp_routes:
            sol.routes[d] = [np.array(r, dtype=np.int32) for r in temp_routes[d] if len(r) > 0]

        sol.unassigned.extend(list(removed_nodes))

    def _repair_fast(self, sol):
        """
        极速修复算子：
        1. 使用 Python List 进行动态操作
        2. 缓存 route_loads 进行 O(1) 容量检查
        3. 使用 Numba 进行 O(1) 距离增量计算，并硬性满足航程约束
        """
        working_routes = {}
        route_loads = {}
        route_dists = {}

        for d, r_list in sol.routes.items():
            working_routes[d] = [list(r) for r in r_list]
            loads = []
            dists = []
            for r in r_list:
                loads.append(np.sum(self.inst.np_demands[r]) if len(r) > 0 else 0)
                dists.append(calc_route_cost_numba(r, d, self.inst.dist_matrix) if len(r) > 0 else 0.0)
            route_loads[d] = loads
            route_dists[d] = dists

        random.shuffle(sol.unassigned)

        dist_matrix = self.inst.dist_matrix
        demands = self.inst.np_demands
        capacity = self.inst.Q
        max_dur = self.inst.D
        max_routes = self.inst.max_vehicles_per_depot

        failed = []
        while sol.unassigned:
            node = sol.unassigned.pop()
            node_dem = demands[node]

            best_delta = 1e9
            best_move = None

            for d, r_list in working_routes.items():
                for r_idx, r in enumerate(r_list):

                    if route_loads[d][r_idx] + node_dem > capacity:
                        continue

                    if not r:
                        delta = calc_delta_dist(dist_matrix, d, d, node)
                        if max_dur > 0 and (route_dists[d][r_idx] + delta > max_dur):
                            continue
                        if delta < best_delta:
                            best_delta = delta
                            best_move = (d, r_idx, 0, delta)
                    else:
                        len_r = len(r)
                        delta = calc_delta_dist(dist_matrix, d, r[0], node)
                        if max_dur > 0 and (route_dists[d][r_idx] + delta > max_dur):
                            pass
                        elif delta < best_delta:
                            best_delta = delta
                            best_move = (d, r_idx, 0, delta)

                        for i in range(len_r - 1):
                            delta = calc_delta_dist(dist_matrix, r[i], r[i+1], node)
                            if max_dur > 0 and (route_dists[d][r_idx] + delta > max_dur):
                                continue
                            if delta < best_delta:
                                best_delta = delta
                                best_move = (d, r_idx, i+1, delta)

                        delta = calc_delta_dist(dist_matrix, r[-1], d, node)
                        if max_dur > 0 and (route_dists[d][r_idx] + delta > max_dur):
                            pass
                        elif delta < best_delta:
                            best_delta = delta
                            best_move = (d, r_idx, len_r, delta)

                if node_dem <= capacity:
                    if max_routes <= 0 or len(working_routes[d]) < max_routes:
                        delta = calc_delta_dist(dist_matrix, d, d, node)
                        if max_dur > 0 and delta > max_dur:
                            continue
                        if delta < best_delta:
                            best_delta = delta
                            best_move = (d, -1, 0, delta)

            if best_move:
                d, r_idx, pos, delta = best_move
                if r_idx == -1:
                    working_routes[d].append([node])
                    route_loads[d].append(node_dem)
                    route_dists[d].append(delta)
                else:
                    working_routes[d][r_idx].insert(pos, node)
                    route_loads[d][r_idx] += node_dem
                    route_dists[d][r_idx] += delta
            else:
                failed.append(node)

        if failed:
            sol.unassigned.extend(failed)

        for d in working_routes:
            sol.routes[d] = [np.array(r, dtype=np.int32) for r in working_routes[d] if len(r) > 0]

    def solve(self, max_iters=50000, time_limit=None):
        start_t = time.time()

        too_heavy, too_far = self._check_basic_feasibility()
        if too_heavy or too_far:
            msg = "初始解不可行："
            if too_heavy:
                msg += f"存在需求大于载重的点(示例:{too_heavy[:5]})。"
            if too_far:
                msg += f"存在往返最短距离超过航程的点(示例:{too_far[:5]})。"
            raise RuntimeError(msg)

        curr_sol = None
        curr_obj = float('inf')
        feas = False
        best_feas_sol = None
        best_feas_obj = float('inf')
        for _ in range(50):
            temp_sol = Solution(self.inst)
            temp_sol.unassigned = list(range(self.inst.n))
            random.shuffle(temp_sol.unassigned)
            self._repair_fast(temp_sol)
            temp_obj, temp_feas = temp_sol.evaluate()
            if temp_feas and temp_obj < best_feas_obj:
                best_feas_sol = temp_sol.copy()
                best_feas_obj = temp_obj
            if temp_obj < curr_obj:
                curr_sol = temp_sol
                curr_obj = temp_obj
                feas = temp_feas

        if curr_sol is None:
            raise RuntimeError("初始解不可行：请检查约束或数据。")
        best_sol = curr_sol.copy()
        best_obj = curr_obj

        print(f"  > 初始解: {curr_obj:.2f}")

        T = curr_obj * 0.05
        alpha = 0.9995

        for it in range(max_iters):
            if time_limit and (time.time() - start_t > time_limit):
                break

            temp_sol = curr_sol.copy()
            q = random.randint(self.min_rem, self.max_rem)

            self._destroy_random(temp_sol, q)
            self._repair_fast(temp_sol)

            new_obj, feas = temp_sol.evaluate()

            delta = new_obj - curr_obj
            if delta < 0:
                curr_sol = temp_sol
                curr_obj = new_obj
                if new_obj < best_obj:
                    best_sol = temp_sol.copy()
                    best_obj = new_obj
                    print(f"    [Iter {it}] 新最优: {best_obj:.2f}")
            elif random.random() < math.exp(-delta / T):
                curr_sol = temp_sol
                curr_obj = new_obj

            if feas and new_obj < best_feas_obj:
                best_feas_sol = temp_sol.copy()
                best_feas_obj = new_obj

            T *= alpha

        if best_feas_sol is None:
            raise RuntimeError("搜索结束仍无可行解：请检查约束或数据。")

        return best_feas_sol.evaluate()[0], best_feas_sol

    def visualize(self, sol, path):
        plt.figure(figsize=(11, 9))
        lon_deg = np.degrees(self.inst.np_lon)
        lat_deg = np.degrees(self.inst.np_lat)

        depot_lon = lon_deg[self.inst.n:]
        depot_lat = lat_deg[self.inst.n:]
        demand_lon = lon_deg[:self.inst.n]
        demand_lat = lat_deg[:self.inst.n]

        plt.scatter(demand_lon, demand_lat, c='#B0BEC5', alpha=0.5, s=18, label='Demand')
        plt.scatter(depot_lon, depot_lat, c='#212121', marker='*', s=160, edgecolors='white', linewidths=0.6, label='Depot')

        cmap = get_safe_cmap('tab20')
        i = 0
        drone_id = 1
        for d, r_list in sol.routes.items():
            for r in r_list:
                if len(r) == 0:
                    continue
                color = cmap(i % 20)
                pts = [d] + list(r) + [d]
                px = lon_deg[pts]
                py = lat_deg[pts]
                plt.plot(px, py, c=color, alpha=0.9, linewidth=1.8)
                plt.scatter(lon_deg[r], lat_deg[r], c=[color], s=26, alpha=0.95)
                if len(r) > 0:
                    x0 = lon_deg[r[0]]
                    y0 = lat_deg[r[0]]
                    plt.text(x0, y0, f"D{drone_id}", fontsize=7, color=color)
                    drone_id += 1
                i += 1

        plt.title(f"Turbo ALNS | Cost: {sol.cost:.2f}")
        plt.xlabel('Longitude')
        plt.ylabel('Latitude')
        plt.legend(loc='best', frameon=False)
        plt.tight_layout()
        plt.savefig(path, dpi=200)
        plt.close()

# ==========================================
# 5. 运行逻辑
# ==========================================

def run_turbo_search_a5(data_dir, cases):
    if not os.path.exists(data_dir):
        return
    input_dir = os.path.join(data_dir, "case_input_data")
    if not os.path.exists(input_dir):
        input_dir = data_dir
    res_dir = os.path.join(data_dir, "Turbo_ALNS_Results")
    _ensure_dir(res_dir)

    summary_data = []

    print("=== 启动 Numba 极速版 ALNS (A5 4组算例) ===")

    for c in cases:
        supply_path = os.path.join(input_dir, f"supplyTable_{c}.csv")
        demand_path = os.path.join(input_dir, f"demand_{c}.csv")
        tag = f"A5_{c}"
        print(f"\n正在处理: {tag} ...")
        try:
            inst = MDVRPInstanceCSV(supply_path, demand_path)
            inst.load()

            solver = ALNSTurboSolver(inst)

            start_time = time.time()
            obj, best_sol = solver.solve(max_iters=50000, time_limit=180)
            end_time = time.time()
            duration = end_time - start_time

            route_records, total_routes = best_sol.get_route_records()
            total_distance = sum(r['distance_km'] for r in route_records)
            total_load = sum(r['load_kg'] for r in route_records)

            print(f"  > 最终结果: {obj:.2f} (耗时: {duration:.2f}s)")
            print(f"  > 载具: {inst.model_name} | 载重: {inst.max_payload}kg | 航程: {inst.max_range_km}km | 速度: {inst.speed_kmh}km/h")
            print(f"  > 每个供应点载具数量: {inst.max_vehicles_per_depot}")
            print(f"  > 使用无人机数量: {total_routes}")
            if inst.invalid_supply_rows or inst.invalid_demand_rows:
                print(f"  > 已跳过无效行: supply={inst.invalid_supply_rows}, demand={inst.invalid_demand_rows}")

            solver.visualize(best_sol, os.path.join(res_dir, f"{tag}_turbo.png"))
            summary_data.append((tag, obj, duration, inst.max_vehicles_per_depot, total_routes, total_distance, total_load))

            # 逐路线明细输出
            route_path = os.path.join(res_dir, f"{tag}_routes.csv")
            with open(route_path, 'w', encoding='utf-8-sig', newline='') as f_out:
                writer = csv.DictWriter(f_out, fieldnames=[
                    'instance', 'depot_idx', 'route_id', 'num_nodes', 'distance_km', 'load_kg',
                    'load_utilization', 'max_payload_kg', 'max_range_km', 'speed_kmh', 'travel_time_h',
                    'node_indices', 'node_demands'
                ])
                writer.writeheader()
                for r in route_records:
                    r['instance'] = tag
                    writer.writerow(r)

            # 汇总输出
            summary_case_path = os.path.join(res_dir, f"{tag}_summary.csv")
            with open(summary_case_path, 'w', encoding='utf-8-sig', newline='') as f_out:
                writer = csv.DictWriter(f_out, fieldnames=[
                    'instance', 'model', 'max_payload_kg', 'max_range_km', 'speed_kmh',
                    'vehicles_per_depot', 'vehicles_used', 'objective_cost', 'total_distance_km',
                    'total_load_kg', 'time_s'
                ])
                writer.writeheader()
                writer.writerow({
                    'instance': tag,
                    'model': inst.model_name,
                    'max_payload_kg': inst.max_payload,
                    'max_range_km': inst.max_range_km,
                    'speed_kmh': inst.speed_kmh,
                    'vehicles_per_depot': inst.max_vehicles_per_depot,
                    'vehicles_used': total_routes,
                    'objective_cost': obj,
                    'total_distance_km': total_distance,
                    'total_load_kg': total_load,
                    'time_s': duration
                })

        except Exception as e:
            print(f"Error: {e}")
            traceback.print_exc()
            summary_data.append((tag, -1.0, -1.0, -1, -1, -1.0, -1.0))

    print("\n" + "=" * 60)
    print(f"{'Instance':<15} {'Cost':<15} {'Time(s)':<15} {'Vehicles/Depot':<15} {'Vehicles':<12}")
    print("-" * 60)

    summary_path = os.path.join(res_dir, "A5_Turbo_ALNS_Summary.txt")
    with open(summary_path, 'w', encoding='utf-8') as f_out:
        header = f"{'Instance':<15} {'Cost':<15} {'Time(s)':<15} {'Vehicles/Depot':<15} {'Vehicles':<12}\n"
        f_out.write(header)
        f_out.write("-" * 60 + "\n")

        for item in summary_data:
            line = f"{item[0]:<15} {item[1]:<15.2f} {item[2]:<15.2f} {item[3]:<15} {item[4]:<12}"
            print(line)
            f_out.write(line + "\n")

    # 汇总 CSV
    summary_csv_path = os.path.join(res_dir, "A5_Turbo_ALNS_Summary.csv")
    with open(summary_csv_path, 'w', encoding='utf-8-sig', newline='') as f_out:
        writer = csv.DictWriter(f_out, fieldnames=[
            'instance', 'objective_cost', 'time_s', 'vehicles_per_depot', 'vehicles_used',
            'total_distance_km', 'total_load_kg'
        ])
        writer.writeheader()
        for item in summary_data:
            writer.writerow({
                'instance': item[0],
                'objective_cost': item[1],
                'time_s': item[2],
                'vehicles_per_depot': item[3],
                'vehicles_used': item[4],
                'total_distance_km': item[5],
                'total_load_kg': item[6]
            })

    print("=" * 60)
    print(f"总结报告已保存至: {summary_path}")
    print(f"汇总表已保存至: {summary_csv_path}")

if __name__ == "__main__":
    target_dir = os.path.dirname(os.path.abspath(__file__))
    run_turbo_search_a5(target_dir, ["L", "M", "MS", "S"])
