from __future__ import annotations

import csv
import html
import json
import math
import re
import urllib.request
from io import BytesIO
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib import patheffects as pe
from matplotlib.lines import Line2D
from matplotlib.patches import Circle, ConnectionPatch, Polygon, Rectangle
from matplotlib.path import Path as MplPath
from PIL import Image


plt.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
    }
)

HERE = Path(__file__).resolve().parent
SECTION_422 = HERE.parent
RESULTS_DIR = SECTION_422.parent
SECTION_421 = RESULTS_DIR / "4.2.1"
CASE_DATA_DIR = SECTION_421 / "case_input_data"
DISRUPTION_DIR = SECTION_422 / "Disruption_Results"
OUTPUT_DIR = HERE / "outputs"
BOUNDARY_PATH = HERE / "shenzhen_districts.geojson"
TILE_CACHE_DIR = HERE / "tile_cache"

ENABLE_ONLINE_BASEMAP = True
BASEMAP_ZOOM = 11
BASEMAP_TIMEOUT_SEC = 5
STATIC_FIGSIZE = (8.2, 6.6)
STATIC_AX_RECT = (0.075, 0.075, 0.91, 0.860)
STATIC_OVERVIEW_RECT = (0.035, 0.775, 0.19, 0.19)
STATIC_C2_ELEMENT_SCALE = 1.28
STATIC_C3_ELEMENT_SCALE = 1.00

CASE_CONFIGS = {
    "MS": {
        "title": "Case C_2",
        "figure": "Fig. 9a.png",
        "detailed_figure": "Fig. 9a.png",
        "route_csv": DISRUPTION_DIR / "A5_MS_disruption_routes.csv",
        "summary_txt": DISRUPTION_DIR / "A5_MS_disruption_summary.txt",
    },
    "M": {
        "title": "Case C_3",
        "figure": "Fig. 9b.png",
        "detailed_figure": "Fig. 9b.png",
        "route_csv": DISRUPTION_DIR / "A5_M_disruption_routes.csv",
        "summary_txt": DISRUPTION_DIR / "A5_M_disruption_summary.txt",
    },
}

STYLE = {
    "basemap_fill": "#f7f7f3",
    "district_fill": "#f6f7f2",
    "district_alt_fill": "#eef2ee",
    "boundary": "#b6c2cc",
    "district_text": "#5f6f7a",
    "landmark_text": "#374151",
    "grid": "#d8dee3",
    "completed_demand": "#8fd19e",
    "unfinished_demand": "#f3b04d",
    "new_demand": "#c81d25",
    "depot": "#101827",
    "original": "#a6b0ba",
    "completed": "#6b7280",
    "remaining": "#9aa3ad",
    "preserved": "#f3b04d",
    "redispatched": "#c81d25",
    "drone": "#101827",
}

DISTRICT_NAMES = {
    440303: "Luohu",
    440304: "Futian",
    440305: "Nanshan",
    440306: "Bao'an",
    440307: "Longgang",
    440308: "Yantian",
    440309: "Longhua",
    440310: "Pingshan",
    440311: "Guangming",
    440343: "Dapeng",
}

LANDMARKS = [
    ("Bao'an Airport", 113.814, 22.639),
    ("Qianhai", 113.895, 22.530),
    ("Shenzhen North", 114.029, 22.609),
    ("Futian CBD", 114.055, 22.543),
    ("Shenzhen Bay", 113.935, 22.490),
    ("Dapeng", 114.516, 22.596),
    ("Kowloon", 114.176, 22.315),
    ("Hong Kong", 114.174, 22.285),
]

WATER_FEATURES = [
    ("Maozhou River", [(113.79, 22.82), (113.82, 22.76), (113.84, 22.70), (113.85, 22.64)]),
    ("Shenzhen River", [(114.02, 22.55), (114.08, 22.55), (114.14, 22.56), (114.20, 22.57), (114.27, 22.59)]),
    ("Longgang River", [(114.12, 22.73), (114.18, 22.71), (114.24, 22.70), (114.31, 22.69)]),
]

RESERVOIRS = [
    ("Tiegang Reservoir", [(113.87, 22.66), (113.90, 22.67), (113.91, 22.65), (113.89, 22.63), (113.86, 22.64)]),
    ("Xili Reservoir", [(113.93, 22.60), (113.96, 22.61), (113.97, 22.59), (113.94, 22.57)]),
    ("Shenzhen Reservoir", [(114.15, 22.59), (114.18, 22.60), (114.19, 22.58), (114.16, 22.57)]),
    ("Songzi Lake", [(114.30, 22.70), (114.33, 22.70), (114.34, 22.68), (114.31, 22.67)]),
]

HELICOPTER_MARKER = MplPath(
    [
        (-0.72, 0.34),
        (0.72, 0.34),
        (0.72, 0.42),
        (-0.72, 0.42),
        (-0.72, 0.34),
        (-0.08, 0.34),
        (-0.02, 0.18),
        (-0.46, 0.05),
        (-0.76, 0.14),
        (-0.82, 0.06),
        (-0.48, -0.08),
        (-0.14, -0.08),
        (0.02, -0.25),
        (0.34, -0.25),
        (0.46, -0.08),
        (0.62, -0.02),
        (0.50, 0.14),
        (0.28, 0.20),
        (-0.02, 0.18),
        (-0.08, 0.34),
        (-0.82, -0.18),
        (-0.64, -0.18),
        (-0.64, -0.10),
        (-0.82, -0.10),
        (-0.82, -0.18),
    ],
    [
        MplPath.MOVETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.CLOSEPOLY,
        MplPath.MOVETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.CLOSEPOLY,
        MplPath.MOVETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.LINETO,
        MplPath.CLOSEPOLY,
    ],
)


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def to_float(value: str) -> float:
    return float(str(value).strip())


def parse_nodes(value: str | None) -> list[int]:
    if not value:
        return []
    return [int(part) for part in str(value).strip().split(";") if part.strip()]


def parse_new_demands(path: Path) -> list[dict[str, float | int]]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    pattern = re.compile(
        r"idx=(?P<idx>\d+),\s*lat=(?P<lat>-?\d+(?:\.\d+)?),\s*"
        r"lon=(?P<lon>-?\d+(?:\.\d+)?),\s*demand=(?P<demand>-?\d+(?:\.\d+)?)"
    )
    return [
        {
            "idx": int(match.group("idx")),
            "lat": float(match.group("lat")),
            "lon": float(match.group("lon")),
            "demand": float(match.group("demand")),
        }
        for match in pattern.finditer(text)
    ]


def load_boundary() -> dict:
    with BOUNDARY_PATH.open("r", encoding="utf-8", errors="replace") as f:
        return json.load(f)


def iter_rings(geojson: dict):
    for feature in geojson.get("features", []):
        geometry = feature.get("geometry") or {}
        gtype = geometry.get("type")
        coords = geometry.get("coordinates") or []
        if gtype == "Polygon":
            for ring in coords:
                yield ring
        elif gtype == "MultiPolygon":
            for polygon in coords:
                for ring in polygon:
                    yield ring


def boundary_bounds(geojson: dict) -> tuple[float, float, float, float]:
    xs, ys = [], []
    for ring in iter_rings(geojson):
        for lon, lat, *_ in ring:
            xs.append(lon)
            ys.append(lat)
    return min(xs), min(ys), max(xs), max(ys)


def point_in_ring(lon: float, lat: float, ring: list) -> bool:
    inside = False
    j = len(ring) - 1
    for i, point in enumerate(ring):
        xi, yi = point[0], point[1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > lat) != (yj > lat):
            x_at_lat = (xj - xi) * (lat - yi) / (yj - yi + 1e-15) + xi
            if lon < x_at_lat:
                inside = not inside
        j = i
    return inside


def point_in_boundary(lon: float, lat: float, geojson: dict) -> bool:
    inside = False
    for ring in iter_rings(geojson):
        if point_in_ring(lon, lat, ring):
            inside = not inside
    return inside


def closest_point_on_segment(px, py, ax, ay, bx, by) -> tuple[float, float]:
    dx, dy = bx - ax, by - ay
    denom = dx * dx + dy * dy
    if denom <= 1e-15:
        return ax, ay
    t = ((px - ax) * dx + (py - ay) * dy) / denom
    t = max(0.0, min(1.0, t))
    return ax + t * dx, ay + t * dy


def nearest_boundary_point(lon: float, lat: float, geojson: dict) -> tuple[float, float]:
    best = (lon, lat)
    best_dist = float("inf")
    scale = math.cos(math.radians(lat))
    for ring in iter_rings(geojson):
        for i in range(len(ring) - 1):
            qx, qy = closest_point_on_segment(lon, lat, ring[i][0], ring[i][1], ring[i + 1][0], ring[i + 1][1])
            dist = ((qx - lon) * scale) ** 2 + (qy - lat) ** 2
            if dist < best_dist:
                best_dist = dist
                best = (qx, qy)
    return best


def correct_out_of_boundary_new_demands(nodes: dict[int, dict], anchors: list[dict], geojson: dict) -> list[str]:
    notes = []
    if not anchors:
        return notes

    mean_lon = sum(node["plot_lon"] for node in anchors) / len(anchors)
    mean_lat = sum(node["plot_lat"] for node in anchors) / len(anchors)

    for node in nodes.values():
        if node.get("kind") != "new_demand":
            continue
        lon, lat = node["plot_lon"], node["plot_lat"]
        if point_in_boundary(lon, lat, geojson):
            continue

        candidate_anchors = anchors
        if lat < 22.52:
            inland_anchors = [item for item in anchors if item["plot_lat"] >= lat + 0.04]
            if inland_anchors:
                candidate_anchors = inland_anchors

        nearest = min(
            candidate_anchors,
            key=lambda item: ((item["plot_lon"] - lon) * math.cos(math.radians(lat))) ** 2
            + (item["plot_lat"] - lat) ** 2,
        )
        base_lon, base_lat = nearest["plot_lon"], nearest["plot_lat"]
        vec_lon = mean_lon - base_lon
        vec_lat = mean_lat - base_lat
        norm = math.hypot(vec_lon * math.cos(math.radians(base_lat)), vec_lat) or 1.0
        unit_lon = vec_lon / norm
        unit_lat = vec_lat / norm
        candidate = None
        offsets = [
            (0.010 * unit_lon, 0.010 * unit_lat),
            (0.006 * unit_lon, 0.006 * unit_lat),
            (0.000, 0.012),
            (0.010, 0.006),
            (0.006, 0.010),
            (0.000, 0.000),
        ]
        for dlon, dlat in offsets:
            cand_lon = base_lon + dlon
            cand_lat = base_lat + dlat
            if point_in_boundary(cand_lon, cand_lat, geojson):
                candidate = (cand_lon, cand_lat)
                break

        if candidate is None:
            candidate = (base_lon, base_lat)

        node["original_lat"] = lat
        node["original_lon"] = lon
        node["plot_lon"], node["plot_lat"] = candidate
        node["corrected"] = True
        notes.append(
            f"{node['label']}: original=({lat:.6f}, {lon:.6f}), plotted=({candidate[1]:.6f}, {candidate[0]:.6f})"
        )
    return notes


def read_case(case: str, geojson: dict) -> dict:
    demand_rows = read_csv_rows(CASE_DATA_DIR / f"demand_{case}.csv")
    supply_rows = read_csv_rows(CASE_DATA_DIR / f"supplyTable_{case}.csv")
    route_rows = read_csv_rows(CASE_CONFIGS[case]["route_csv"])
    new_demands = parse_new_demands(CASE_CONFIGS[case]["summary_txt"])

    nodes: dict[int, dict] = {}
    original_demands = []
    for idx, row in enumerate(demand_rows):
        lat = to_float(row["latitude"])
        lon = to_float(row["longitude"])
        node = {
            "idx": idx,
            "lat": lat,
            "lon": lon,
            "plot_lat": lat,
            "plot_lon": lon,
            "demand": to_float(row["Demand"]),
            "kind": "demand",
            "label": f"D{idx}",
        }
        nodes[idx] = node
        original_demands.append(node)

    for item in new_demands:
        idx = int(item["idx"])
        node = {
            "idx": idx,
            "lat": float(item["lat"]),
            "lon": float(item["lon"]),
            "plot_lat": float(item["lat"]),
            "plot_lon": float(item["lon"]),
            "demand": float(item["demand"]),
            "kind": "new_demand",
            "label": f"ND{idx}",
            "corrected": False,
        }
        nodes[idx] = node

    depot_start = len(demand_rows) + len(new_demands)
    depots = []
    for offset, row in enumerate(supply_rows):
        idx = depot_start + offset
        lat = to_float(row["Latitude"])
        lon = to_float(row["Longitude"])
        node = {
            "idx": idx,
            "lat": lat,
            "lon": lon,
            "plot_lat": lat,
            "plot_lon": lon,
            "kind": "depot",
            "label": f"Depot {offset + 1}",
            "supply_id": row.get("SupplyID", str(offset + 1)),
        }
        nodes[idx] = node
        depots.append(node)

    correction_notes = correct_out_of_boundary_new_demands(nodes, original_demands, geojson)

    routes = []
    for row in route_rows:
        routes.append(
            {
                "vehicle_id": row["vehicle_id"],
                "depot_idx": int(row["depot_idx"]),
                "start_idx": int(row["start_idx"]),
                "original": parse_nodes(row.get("original_route_nodes")),
                "completed": parse_nodes(row.get("completed_nodes")),
                "remaining": parse_nodes(row.get("remaining_nodes")),
                "replanned": parse_nodes(row.get("new_route_nodes")),
                "distance_km": to_float(row["new_route_distance_km"]),
                "load_kg": to_float(row["new_route_load_kg"]),
            }
        )

    return {
        "case": case,
        "nodes": nodes,
        "demands": original_demands,
        "new_demands": [nodes[int(item["idx"])] for item in new_demands],
        "depots": depots,
        "routes": routes,
        "correction_notes": correction_notes,
    }


def draw_boundary(ax, geojson: dict, detailed: bool = False) -> None:
    edge_color = "#ff6a00" if detailed else STYLE["boundary"]
    edge_width = 0.88 if detailed else 0.72
    fill_alpha = 0.60 if detailed else 0.78
    fill_color = "#eef1cf" if detailed else STYLE["district_fill"]
    alt_fill_color = "#f4f0c8" if detailed else STYLE["district_alt_fill"]
    for feature_i, feature in enumerate(geojson.get("features", [])):
        geometry = feature.get("geometry") or {}
        gtype = geometry.get("type")
        coords = geometry.get("coordinates") or []
        if gtype == "Polygon":
            feature_rings = coords
        elif gtype == "MultiPolygon":
            feature_rings = [ring for polygon in coords for ring in polygon]
        else:
            feature_rings = []
        for ring in feature_rings:
            if not ring:
                continue
            xs = [point[0] for point in ring]
            ys = [point[1] for point in ring]
            ax.fill(
                xs,
                ys,
                facecolor=fill_color if feature_i % 2 == 0 else alt_fill_color,
                edgecolor=edge_color,
                linewidth=edge_width,
                alpha=fill_alpha,
                zorder=0.7,
            )


def draw_place_labels(ax, geojson: dict, detailed: bool = False) -> None:
    halo = [pe.withStroke(linewidth=2.4, foreground="white", alpha=0.9)]
    xmin, xmax = ax.get_xlim()
    ymin, ymax = ax.get_ylim()
    for feature in geojson.get("features", []):
        props = feature.get("properties") or {}
        label = DISTRICT_NAMES.get(props.get("adcode"))
        center = props.get("centroid") or props.get("center")
        if not label or not center:
            continue
        if not (xmin <= center[0] <= xmax and ymin <= center[1] <= ymax):
            continue
        ax.text(
            center[0],
            center[1],
            label,
            fontsize=7.2,
            color=STYLE["district_text"],
            ha="center",
            va="center",
            alpha=0.88,
            zorder=1.4,
            path_effects=halo,
            clip_on=True,
        )
    for label, lon, lat in LANDMARKS:
        if xmin <= lon <= xmax and ymin <= lat <= ymax:
            ax.text(
                lon,
                lat,
                label,
                fontsize=7.2 if detailed else 6.4,
                color=STYLE["landmark_text"],
                ha="center",
                va="center",
                alpha=0.86,
                zorder=1.5,
                path_effects=halo,
                clip_on=True,
            )


def draw_detailed_context(ax) -> None:
    ax.set_facecolor("#cfd8dc")
    for name, polygon in RESERVOIRS:
        xs = [point[0] for point in polygon]
        ys = [point[1] for point in polygon]
        ax.fill(xs, ys, facecolor="#a9c9d6", edgecolor="#7faebe", linewidth=0.55, alpha=0.48, zorder=0.25)
        cx = sum(xs) / len(xs)
        cy = sum(ys) / len(ys)
        ax.text(
            cx,
            cy,
            name,
            fontsize=5.6,
            color="#557b8a",
            ha="center",
            va="center",
            alpha=0.78,
            zorder=1.15,
            path_effects=[pe.withStroke(linewidth=1.7, foreground="white", alpha=0.85)],
            clip_on=True,
        )
    for name, line in WATER_FEATURES:
        xs = [point[0] for point in line]
        ys = [point[1] for point in line]
        ax.plot(xs, ys, color="#8cb8c9", linewidth=1.0, alpha=0.52, zorder=0.35)
        mid = len(line) // 2
        ax.text(
            line[mid][0],
            line[mid][1],
            name,
            fontsize=5.6,
            color="#557b8a",
            ha="center",
            va="center",
            alpha=0.78,
            zorder=1.16,
            path_effects=[pe.withStroke(linewidth=1.7, foreground="white", alpha=0.85)],
            clip_on=True,
        )


def lonlat_to_tile(lon: float, lat: float, zoom: int) -> tuple[int, int]:
    lat_rad = math.radians(max(min(lat, 85.0511), -85.0511))
    n = 2**zoom
    x = int((lon + 180.0) / 360.0 * n)
    y = int((1.0 - math.log(math.tan(lat_rad) + 1 / math.cos(lat_rad)) / math.pi) / 2.0 * n)
    return x, y


def tile_to_lonlat(x: int, y: int, zoom: int) -> tuple[float, float]:
    n = 2**zoom
    lon = x / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y / n)))
    return lon, math.degrees(lat_rad)


def fetch_tile(x: int, y: int, zoom: int) -> Image.Image | None:
    cache_path = TILE_CACHE_DIR / "cartodb_light" / str(zoom) / str(x) / f"{y}.png"
    if cache_path.exists():
        return Image.open(cache_path).convert("RGB")
    subdomain = "abcd"[(x + y) % 4]
    url = f"https://{subdomain}.basemaps.cartocdn.com/light_all/{zoom}/{x}/{y}.png"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "AI-UAV academic map renderer"})
        with urllib.request.urlopen(req, timeout=BASEMAP_TIMEOUT_SEC) as response:
            data = response.read()
        image = Image.open(BytesIO(data)).convert("RGB")
    except Exception:
        return None
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    image.save(cache_path)
    return image


def draw_online_basemap(ax, bounds: tuple[float, float, float, float]) -> bool:
    if not ENABLE_ONLINE_BASEMAP:
        return False
    xmin, ymin, xmax, ymax = bounds
    x0, y1 = lonlat_to_tile(xmin, ymin, BASEMAP_ZOOM)
    x1, y0 = lonlat_to_tile(xmax, ymax, BASEMAP_ZOOM)
    first_tile = fetch_tile(x0, y0, BASEMAP_ZOOM)
    if first_tile is None:
        return False
    for x in range(x0, x1 + 1):
        for y in range(y0, y1 + 1):
            tile = first_tile if (x == x0 and y == y0) else fetch_tile(x, y, BASEMAP_ZOOM)
            if tile is None:
                continue
            west, north = tile_to_lonlat(x, y, BASEMAP_ZOOM)
            east, south = tile_to_lonlat(x + 1, y + 1, BASEMAP_ZOOM)
            ax.imshow(tile, extent=(west, east, south, north), zorder=-2, alpha=0.9, interpolation="bilinear")
    return True


def coords(nodes: dict[int, dict], sequence: list[int]) -> list[tuple[float, float]]:
    return [(nodes[idx]["plot_lon"], nodes[idx]["plot_lat"]) for idx in sequence if idx in nodes]


def demand_status_ids(case_data: dict) -> tuple[set[int], set[int]]:
    demand_ids = {node["idx"] for node in case_data["demands"]}
    completed_ids = {
        idx
        for route in case_data["routes"]
        for idx in route["completed"]
        if idx in demand_ids
    }
    unfinished_ids = demand_ids - completed_ids
    return completed_ids, unfinished_ids


def new_demand_ids(case_data: dict) -> set[int]:
    return {node["idx"] for node in case_data["new_demands"]}


def route_is_changed(route: dict, new_ids: set[int]) -> bool:
    return bool(route["replanned"]) and (
        list(route["replanned"]) != list(route["remaining"])
        or any(idx in new_ids for idx in route["replanned"])
    )


def path_edges(sequence: list[int]) -> list[tuple[int, int]]:
    return [(sequence[i], sequence[i + 1]) for i in range(len(sequence) - 1) if sequence[i] != sequence[i + 1]]


def obsolete_edges_for_route(route: dict) -> list[tuple[int, int]]:
    start_idx = route["start_idx"]
    depot_idx = route["depot_idx"]
    original_future = [start_idx] + route["remaining"] + [depot_idx]
    replanned_future = [start_idx] + route["replanned"] + [depot_idx]
    replanned_edges = set(path_edges(replanned_future))
    return [edge for edge in path_edges(original_future) if edge not in replanned_edges]


def edge_key(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a <= b else (b, a)


def collect_bidirectional_edges(case_data: dict) -> set[tuple[int, int]]:
    directed = set()
    for route in case_data["routes"]:
        depot_idx = route["depot_idx"]
        start_idx = route["start_idx"]
        sequences = [
            [depot_idx] + route["completed"],
            [start_idx] + route["remaining"] + [depot_idx],
            [start_idx] + route["replanned"] + [depot_idx],
        ]
        for sequence in sequences:
            for i in range(len(sequence) - 1):
                if sequence[i] != sequence[i + 1]:
                    directed.add((sequence[i], sequence[i + 1]))
    return {edge_key(a, b) for a, b in directed if (b, a) in directed}


def draw_path(
    ax,
    points,
    color,
    lw,
    linestyle,
    alpha,
    zorder,
    arrows=True,
    casing=True,
    segment_ids=None,
    bidirectional_edges=None,
    arrow_scale=1.0,
):
    if len(points) < 2:
        return
    xs, ys = zip(*points)
    if casing:
        ax.plot(xs, ys, color="white", linewidth=lw + 0.62, linestyle=linestyle, alpha=0.66, zorder=zorder - 0.05)
    ax.plot(xs, ys, color=color, linewidth=lw, linestyle=linestyle, alpha=alpha, zorder=zorder)
    if not arrows:
        return
    step = max(1, len(points) // 3)
    for i in range(0, len(points) - 1, step):
        x0, y0 = points[i]
        x1, y1 = points[i + 1]
        if abs(x1 - x0) + abs(y1 - y0) < 1e-9:
            continue
        is_bidirectional = bool(segment_ids and bidirectional_edges and edge_key(*segment_ids[i]) in bidirectional_edges)

        def interp(t):
            return (x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)

        start_t, end_t = (0.44, 0.64) if not is_bidirectional else (0.54, 0.73)
        ax.annotate(
            "",
            xy=interp(end_t),
            xytext=interp(start_t),
            arrowprops={
                "arrowstyle": "-|>",
                "color": color,
                "lw": max(0.62, lw - 0.55),
                "alpha": alpha,
                "shrinkA": 2,
                "shrinkB": 2,
                "mutation_scale": 6.8 * arrow_scale,
            },
            zorder=zorder + 0.1,
        )
        if is_bidirectional:
            ax.annotate(
                "",
                xy=interp(0.27),
                xytext=interp(0.46),
                arrowprops={
                    "arrowstyle": "-|>",
                    "color": color,
                    "lw": max(0.62, lw - 0.55),
                    "alpha": alpha,
                    "shrinkA": 3,
                    "shrinkB": 3,
                    "mutation_scale": 6.8 * arrow_scale,
                },
                zorder=zorder + 0.2,
            )


def draw_cancel_marks(ax, points, color, zorder, scale=1.0):
    if len(points) < 2:
        return
    marks = []
    for i in range(len(points) - 1):
        x0, y0 = points[i]
        x1, y1 = points[i + 1]
        if abs(x1 - x0) + abs(y1 - y0) < 1e-9:
            continue
        marks.append(((x0 + x1) / 2, (y0 + y1) / 2))
    if not marks:
        return
    xs, ys = zip(*marks)
    ax.scatter(xs, ys, marker="x", s=14 * (scale ** 2), c=color, linewidths=0.80 * scale, zorder=zorder)


def route_plot_bounds(case_data: dict, geojson: dict) -> tuple[float, float, float, float]:
    used = set()
    for route in case_data["routes"]:
        used.update(route["completed"])
        used.update(route["remaining"])
        used.update(route["replanned"])
        used.add(route["start_idx"])
        used.add(route["depot_idx"])
    used.update(node["idx"] for node in case_data["new_demands"])
    points = [case_data["nodes"][idx] for idx in used if idx in case_data["nodes"]]
    if not points:
        return boundary_bounds(geojson)

    xs = [node["plot_lon"] for node in points]
    ys = [node["plot_lat"] for node in points]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    pad_x = max(0.025, (xmax - xmin) * 0.18)
    pad_y = max(0.025, (ymax - ymin) * 0.18)
    bxmin, bymin, bxmax, bymax = boundary_bounds(geojson)
    return (
        max(bxmin - 0.01, xmin - pad_x),
        max(bymin - 0.01, ymin - pad_y),
        min(bxmax + 0.01, xmax + pad_x),
        min(bymax + 0.01, ymax + pad_y),
    )


def fit_bounds_to_static_panel(bounds: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    xmin, ymin, xmax, ymax = bounds
    center_lat = (ymin + ymax) / 2
    target_ratio = (STATIC_FIGSIZE[0] * STATIC_AX_RECT[2]) / (STATIC_FIGSIZE[1] * STATIC_AX_RECT[3])
    width = xmax - xmin
    height = ymax - ymin
    current_ratio = (width * math.cos(math.radians(center_lat))) / max(1e-9, height)
    cx = (xmin + xmax) / 2
    cy = (ymin + ymax) / 2
    if current_ratio < target_ratio:
        width = target_ratio * height / max(1e-9, math.cos(math.radians(center_lat)))
    else:
        height = width * math.cos(math.radians(center_lat)) / target_ratio
    return cx - width / 2, cy - height / 2, cx + width / 2, cy + height / 2


def add_overview_inset(fig, ax, geojson: dict, zoom_bounds: tuple[float, float, float, float]):
    inset = ax.inset_axes(STATIC_OVERVIEW_RECT)
    inset.set_facecolor("#f7f7f3")
    draw_boundary(inset, geojson, detailed=False)
    bxmin, bymin, bxmax, bymax = boundary_bounds(geojson)
    inset.set_xlim(bxmin - 0.02, bxmax + 0.02)
    inset.set_ylim(bymin - 0.02, bymax + 0.02)
    center_lat = (bymin + bymax) / 2
    inset.set_aspect(1 / math.cos(math.radians(center_lat)))
    zxmin, zymin, zxmax, zymax = zoom_bounds
    zoom_rect = Rectangle(
        (zxmin, zymin),
        zxmax - zxmin,
        zymax - zymin,
        fill=False,
        edgecolor=STYLE["redispatched"],
        linewidth=0.85,
        linestyle="-",
        zorder=8,
    )
    inset.add_patch(zoom_rect)
    inset.tick_params(left=False, bottom=False, labelleft=False, labelbottom=False)
    for spine in inset.spines.values():
        spine.set_color("#9aa3ad")
        spine.set_linewidth(0.58)
    inset.text(
        0.04,
        0.965,
        "Shenzhen City Overview",
        transform=inset.transAxes,
        ha="left",
        va="top",
        fontsize=4.9,
        color="#374151",
        path_effects=[pe.withStroke(linewidth=1.5, foreground="white", alpha=0.95)],
    )

def add_scale_bar(ax, km=10):
    xmin, xmax = ax.get_xlim()
    ymin, ymax = ax.get_ylim()
    lat = ymin + 0.065 * (ymax - ymin)
    lon = xmin + 0.065 * (xmax - xmin)
    length_lon = km / (111.32 * math.cos(math.radians(lat)))
    tick = 0.0058 * (ymax - ymin)
    ax.plot([lon, lon + length_lon], [lat, lat], color=STYLE["depot"], linewidth=1.05, zorder=20)
    ax.plot([lon, lon], [lat - tick, lat + tick], color=STYLE["depot"], linewidth=0.82, zorder=20)
    ax.plot([lon + length_lon, lon + length_lon], [lat - tick, lat + tick], color=STYLE["depot"], linewidth=0.82, zorder=20)
    ax.text(
        lon + length_lon / 2,
        lat + 1.8 * tick,
        f"{km} km",
        ha="center",
        va="bottom",
        fontsize=6.4,
        color=STYLE["depot"],
        zorder=21,
        path_effects=[pe.withStroke(linewidth=1.8, foreground="white", alpha=0.85)],
    )

def add_north_arrow(ax):
    radius = 0.022
    margin_x = 0.065
    margin_y = 0.065
    cx = 1.0 - margin_x - radius
    cy = margin_y + radius
    circle = Circle((cx, cy), radius, transform=ax.transAxes, facecolor="white", edgecolor=STYLE["depot"], lw=0.58, zorder=25)
    north = Polygon(
        [(cx, cy + 0.038), (cx - 0.0088, cy - 0.0072), (cx, cy + 0.0028), (cx + 0.0088, cy - 0.0072)],
        closed=True,
        transform=ax.transAxes,
        facecolor=STYLE["depot"],
        edgecolor=STYLE["depot"],
        zorder=26,
    )
    south = Polygon(
        [(cx, cy - 0.032), (cx - 0.0074, cy + 0.0058), (cx, cy - 0.0025), (cx + 0.0074, cy + 0.0058)],
        closed=True,
        transform=ax.transAxes,
        facecolor="#d1d5db",
        edgecolor=STYLE["depot"],
        lw=0.28,
        zorder=25.5,
    )
    ax.add_patch(circle)
    ax.add_patch(south)
    ax.add_patch(north)
    ax.text(cx, cy + 0.049, "N", transform=ax.transAxes, ha="center", va="center", fontsize=6.8, weight="bold", color=STYLE["depot"], zorder=27)

def plot_case(case_data: dict, geojson: dict, detailed_basemap: bool = False) -> Path:
    case = case_data["case"]
    element_scale = STATIC_C2_ELEMENT_SCALE if case == "MS" else STATIC_C3_ELEMENT_SCALE
    point_area_scale = element_scale ** 2
    zoom_bounds = fit_bounds_to_static_panel(route_plot_bounds(case_data, geojson))
    zxmin, zymin, zxmax, zymax = zoom_bounds
    fig, ax = plt.subplots(figsize=STATIC_FIGSIZE)
    fig.subplots_adjust(
        left=STATIC_AX_RECT[0],
        bottom=STATIC_AX_RECT[1],
        right=STATIC_AX_RECT[0] + STATIC_AX_RECT[2],
        top=STATIC_AX_RECT[1] + STATIC_AX_RECT[3],
    )
    fig.patch.set_facecolor("white")
    ax.set_facecolor("#cfd8dc" if detailed_basemap else STYLE["basemap_fill"])

    xmin, ymin, xmax, ymax = boundary_bounds(geojson)
    ax.set_xlim(zxmin, zxmax)
    ax.set_ylim(zymin, zymax)
    basemap_loaded = False
    if detailed_basemap:
        basemap_loaded = draw_online_basemap(ax, zoom_bounds)
        if not basemap_loaded:
            draw_detailed_context(ax)
    draw_boundary(ax, geojson, detailed=detailed_basemap)
    draw_place_labels(ax, geojson, detailed=detailed_basemap)

    completed_ids, unfinished_ids = demand_status_ids(case_data)
    completed_nodes = [node for node in case_data["demands"] if node["idx"] in completed_ids]
    unfinished_nodes = [node for node in case_data["demands"] if node["idx"] in unfinished_ids]
    if completed_nodes:
        ax.scatter(
            [node["plot_lon"] for node in completed_nodes],
            [node["plot_lat"] for node in completed_nodes],
            s=13 * point_area_scale,
            c=STYLE["completed_demand"],
            edgecolors="white",
            linewidths=0.50 * element_scale,
            alpha=0.92,
            zorder=6,
        )
    if unfinished_nodes:
        ax.scatter(
            [node["plot_lon"] for node in unfinished_nodes],
            [node["plot_lat"] for node in unfinished_nodes],
            s=15 * point_area_scale,
            c=STYLE["unfinished_demand"],
            edgecolors="white",
            linewidths=0.50 * element_scale,
            alpha=0.94,
            zorder=6.2,
        )

    if case_data["new_demands"]:
        ax.scatter(
            [node["plot_lon"] for node in case_data["new_demands"]],
            [node["plot_lat"] for node in case_data["new_demands"]],
            marker="s",
            s=30 * point_area_scale,
            c=STYLE["new_demand"],
            edgecolors="white",
            linewidths=0.70 * element_scale,
            zorder=8,
        )

    ax.scatter(
        [node["plot_lon"] for node in case_data["depots"]],
        [node["plot_lat"] for node in case_data["depots"]],
        marker="*",
        s=78 * point_area_scale,
        c=STYLE["depot"],
        edgecolors="white",
        linewidths=0.85 * element_scale,
        zorder=12,
    )

    bidirectional_edges = collect_bidirectional_edges(case_data)
    case_new_ids = new_demand_ids(case_data)
    for route in case_data["routes"]:
        depot_idx = route["depot_idx"]
        start_idx = route["start_idx"]
        completed_seq = [depot_idx] + route["completed"]
        remaining_seq = [start_idx] + route["remaining"] + [depot_idx]
        replanned_seq = [start_idx] + route["replanned"] + [depot_idx]
        changed_route = route_is_changed(route, case_new_ids)

        if changed_route:
            for obsolete_edge in obsolete_edges_for_route(route):
                obsolete_seq = list(obsolete_edge)
                draw_path(
                    ax,
                    coords(case_data["nodes"], obsolete_seq),
                    color=STYLE["remaining"],
                    lw=0.62 * element_scale,
                    linestyle=(0, (3.6, 2.5)),
                    alpha=0.80,
                    zorder=3.2,
                    arrows=True,
                    casing=True,
                    segment_ids=[obsolete_edge],
                    bidirectional_edges=bidirectional_edges,
                    arrow_scale=element_scale,
                )
                draw_cancel_marks(ax, coords(case_data["nodes"], obsolete_seq), STYLE["remaining"], zorder=14, scale=element_scale)
        elif route["remaining"]:
            draw_path(
                ax,
                coords(case_data["nodes"], remaining_seq),
                color=STYLE["preserved"],
                lw=0.72 * element_scale,
                linestyle=(0, (4.0, 2.4)),
                alpha=0.82,
                zorder=3.1,
                arrows=True,
                casing=True,
                segment_ids=list(zip(remaining_seq[:-1], remaining_seq[1:])),
                bidirectional_edges=bidirectional_edges,
                arrow_scale=element_scale,
            )
        draw_path(
            ax,
            coords(case_data["nodes"], completed_seq),
            color=STYLE["completed"],
            lw=0.90 * element_scale,
            linestyle="-",
            alpha=0.95,
            zorder=5,
            arrows=True,
            casing=True,
            segment_ids=list(zip(completed_seq[:-1], completed_seq[1:])),
            bidirectional_edges=bidirectional_edges,
            arrow_scale=element_scale,
        )
        if changed_route:
            draw_path(
                ax,
                coords(case_data["nodes"], replanned_seq),
                color=STYLE["redispatched"],
                lw=1.02 * element_scale,
                linestyle=(0, (5.2, 2.4)),
                alpha=0.96,
                zorder=7,
                arrows=True,
                casing=True,
                segment_ids=list(zip(replanned_seq[:-1], replanned_seq[1:])),
                bidirectional_edges=bidirectional_edges,
                arrow_scale=element_scale,
            )

        if start_idx in case_data["nodes"]:
            start = case_data["nodes"][start_idx]
            ax.scatter(
                [start["plot_lon"]],
                [start["plot_lat"]],
                marker=HELICOPTER_MARKER,
                s=135 * point_area_scale,
                c=STYLE["drone"],
                edgecolors="white",
                linewidths=0.75 * element_scale,
                zorder=11,
            )

    center_lat = (zymin + zymax) / 2
    ax.set_aspect(1 / math.cos(math.radians(center_lat)))
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.grid(color=STYLE["grid"], linewidth=0.42, linestyle="-", alpha=0.48)
    ax.tick_params(labelsize=8, colors="#374151")

    legend_items = [
        Line2D([0], [0], color=STYLE["completed"], lw=1.0, label="Flown path"),
        Line2D([0], [0], color=STYLE["preserved"], lw=0.9, linestyle=(0, (4.0, 2.4)), label="Preserved unflown path"),
        Line2D([0], [0], color=STYLE["remaining"], lw=0.8, linestyle=(0, (3.6, 2.5)), marker="x", markersize=3.6, markeredgewidth=0.75, label="Obsolete original edge"),
        Line2D([0], [0], color=STYLE["redispatched"], lw=1.0, linestyle=(0, (5.2, 2.4)), label="Redispatched new path"),
        Line2D([0], [0], marker=HELICOPTER_MARKER, color="w", markerfacecolor=STYLE["drone"], markeredgecolor="white", markersize=8.8, label="In-flight UAV"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor=STYLE["completed_demand"], markeredgecolor="white", markersize=4.7, label="Completed demand"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor=STYLE["unfinished_demand"], markeredgecolor="white", markersize=4.9, label="Unfinished demand"),
        Line2D([0], [0], marker="s", color="w", markerfacecolor=STYLE["new_demand"], markeredgecolor="white", markersize=5.6, label="New demand"),
        Line2D([0], [0], marker="*", color="w", markerfacecolor=STYLE["depot"], markeredgecolor="white", markersize=9.0, label="UAV depot"),
    ]
    ax.legend(
        handles=legend_items,
        loc="upper right",
        bbox_to_anchor=(0.965, 0.965),
        bbox_transform=ax.transAxes,
        ncol=3,
        fontsize=6.6,
        frameon=True,
        framealpha=0.94,
        borderpad=0.50,
        columnspacing=0.90,
        handlelength=2.15,
        handletextpad=0.50,
        labelspacing=0.35,
        fancybox=True,
        edgecolor="#c7cdd3",
        borderaxespad=0.0,
    )
    add_scale_bar(ax, km=10)
    add_north_arrow(ax)
    add_overview_inset(fig, ax, geojson, zoom_bounds)

    figure_key = "detailed_figure" if detailed_basemap else "figure"
    out_path = OUTPUT_DIR / CASE_CONFIGS[case][figure_key]
    fig.savefig(out_path, dpi=600, facecolor="white")
    plt.close(fig)
    return out_path


def case_to_js(case_data: dict) -> dict:
    completed_ids, unfinished_ids = demand_status_ids(case_data)
    nodes = {}
    for idx, node in case_data["nodes"].items():
        nodes[str(idx)] = {
            "lat": node["plot_lat"],
            "lon": node["plot_lon"],
            "raw_lat": node["lat"],
            "raw_lon": node["lon"],
            "corrected": bool(node.get("corrected")),
            "kind": node["kind"],
            "label": node["label"],
            "demand": node.get("demand"),
        }
    return {
        "title": CASE_CONFIGS[case_data["case"]]["title"],
        "nodes": nodes,
        "demands": [node["idx"] for node in case_data["demands"]],
        "completed_demands": sorted(completed_ids),
        "unfinished_demands": sorted(unfinished_ids),
        "new_demands": [node["idx"] for node in case_data["new_demands"]],
        "depots": [node["idx"] for node in case_data["depots"]],
        "routes": case_data["routes"],
    }


def build_interactive_html(cases: dict[str, dict], geojson: dict) -> Path:
    data = {case: case_to_js(case_data) for case, case_data in cases.items()}
    payload = json.dumps({"cases": data, "boundary": geojson}, ensure_ascii=False)
    out_path = OUTPUT_DIR / "disruption_gis_routes_interactive.html"
    out_path.write_text(
        f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>UAV Redispatching Routes in Shenzhen</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
  <style>
    html, body {{ margin: 0; height: 100%; font-family: "Times New Roman", Times, serif; }}
    #map {{ height: 100vh; width: 100vw; background: #f7f7f3; }}
    .panel {{
      position: absolute; z-index: 1000; top: 14px; left: 54px;
      background: rgba(255,255,255,0.94); border: 1px solid #d7dce1;
      border-radius: 6px; padding: 10px 12px; box-shadow: 0 8px 24px rgba(15,23,42,0.15);
      color: #172033; min-width: 260px;
    }}
    .panel h1 {{ margin: 0 0 6px; font-size: 15px; line-height: 1.25; }}
    .panel .hint {{ font-size: 11px; color: #4b5563; margin-bottom: 8px; }}
    .panel select, .panel button {{
      font-family: "Times New Roman", Times, serif; font-size: 12px; border: 1px solid #cbd5e1;
      border-radius: 5px; background: white; padding: 5px 8px; margin-right: 6px; color: #172033;
    }}
    .panel button {{ background: #0f766e; color: white; border-color: #0f766e; cursor: pointer; }}
    .legend {{
      position: absolute; z-index: 1000; right: 14px; bottom: 22px; background: rgba(255,255,255,0.94);
      border: 1px solid #d7dce1; border-radius: 6px; padding: 9px 10px; color: #172033;
      font-size: 12px; box-shadow: 0 8px 24px rgba(15,23,42,0.15); cursor: move; user-select: none;
    }}
    .legend div {{ margin: 4px 0; white-space: nowrap; }}
    .line-swatch {{ display: inline-block; width: 28px; height: 0; vertical-align: middle; margin-right: 7px; border-top-width: 3px; border-top-style: solid; }}
    .line-completed {{ border-top-color: {STYLE['completed']}; }}
    .line-preserved {{ border-top-color: {STYLE['preserved']}; border-top-style: dashed; }}
    .line-interrupted {{ border-top-color: {STYLE['remaining']}; border-top-style: dashed; position: relative; }}
    .line-interrupted::after {{
      content: "x"; position: absolute; left: 10px; top: -12px; color: {STYLE['remaining']};
      font-size: 17px; font-weight: 700; line-height: 1; text-shadow: 0 0 2px white;
    }}
    .line-redispatched {{ border-top-color: {STYLE['redispatched']}; border-top-style: dashed; }}
    .dot {{ display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 8px; vertical-align: middle; }}
    .triangle {{
      display: inline-block; width: 0; height: 0; margin-right: 8px; vertical-align: middle;
      border-left: 7px solid transparent; border-right: 7px solid transparent; border-bottom: 13px solid {STYLE['new_demand']};
    }}
    .depot {{ color: #101827; font-size: 15px; margin-right: 7px; }}
    .north-arrow {{
      position: absolute; z-index: 1000; right: 26px; top: 88px; width: 58px; height: 76px;
      pointer-events: none; filter: drop-shadow(0 2px 4px rgba(15,23,42,0.28));
    }}
    .drone-icon svg {{ filter: drop-shadow(0 1px 2px rgba(0,0,0,0.35)); }}
    .route-arrow svg {{ filter: drop-shadow(0 0 2px white); }}
    .cancel-marker {{
      color: {STYLE['remaining']}; font-size: 27px; font-weight: 700; line-height: 27px;
      text-shadow: 0 0 3px white, 0 0 3px white;
    }}
  </style>
</head>
<body>
  <div id="map"></div>
  <div class="panel">
    <h1>UAV Redispatching Routes in Shenzhen</h1>
    <div class="hint">Default basemap: CartoDB Light. AutoNavi layers may show GCJ-02 offset.</div>
    <select id="case-select">
      <option value="MS">Case C2</option>
      <option value="M">Case C3</option>
    </select>
    <button id="download">Download PNG</button>
  </div>
  <div class="legend">
    <div><span class="line-swatch line-completed"></span>Flown path</div>
    <div><span class="line-swatch line-preserved"></span>Preserved unflown path</div>
    <div><span class="line-swatch line-interrupted"></span>Obsolete original edge</div>
    <div><span class="line-swatch line-redispatched"></span>Redispatched new path</div>
    <div><span class="dot" style="background:{STYLE['completed_demand']}"></span>Completed demand</div>
    <div><span class="dot" style="background:{STYLE['unfinished_demand']}"></span>Unfinished demand</div>
    <div><span class="triangle"></span>New demand</div>
    <div><span class="depot">&#9733;</span>UAV depot</div>
  </div>
  <div class="north-arrow">
    <svg viewBox="0 0 64 86" aria-label="north arrow">
      <ellipse cx="32" cy="58" rx="26" ry="18" fill="rgba(255,255,255,0.92)" stroke="#101827" stroke-width="2"/>
      <path d="M32 6 L45 72 L32 58 L19 72 Z" fill="#101827" stroke="white" stroke-width="1.6"/>
      <path d="M32 58 L45 72 L32 82 L19 72 Z" fill="#d1d5db" stroke="#101827" stroke-width="1"/>
      <text x="32" y="15" text-anchor="middle" font-size="17" font-weight="700" fill="#101827">N</text>
    </svg>
  </div>
  <script>
    const payload = {payload};
    const colors = {json.dumps(STYLE)};
    const map = L.map('map', {{preferCanvas: true}}).setView([22.62, 114.08], 10);
    const tileOptions = {{maxZoom: 19, crossOrigin: true, attribution: ''}};
    const baseLayers = {{
      'CartoDB Light': L.tileLayer('https://{{s}}.basemaps.cartocdn.com/light_all/{{z}}/{{x}}/{{y}}{{r}}.png', tileOptions),
      'CartoDB Voyager': L.tileLayer('https://{{s}}.basemaps.cartocdn.com/rastertiles/voyager/{{z}}/{{x}}/{{y}}{{r}}.png', tileOptions),
      'OpenStreetMap': L.tileLayer('https://tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', tileOptions),
      'CartoDB Dark': L.tileLayer('https://{{s}}.basemaps.cartocdn.com/dark_all/{{z}}/{{x}}/{{y}}{{r}}.png', tileOptions),
      'AutoNavi English': L.tileLayer('https://webrd01.is.autonavi.com/appmaptile?lang=en&size=1&scale=1&style=8&x={{x}}&y={{y}}&z={{z}}', tileOptions),
      'AutoNavi Satellite': L.tileLayer('https://webst01.is.autonavi.com/appmaptile?style=6&x={{x}}&y={{y}}&z={{z}}', tileOptions)
    }};
    baseLayers['CartoDB Light'].addTo(map);
    L.control.layers(baseLayers, null, {{collapsed: false, position: 'bottomleft'}}).addTo(map);

    const boundary = L.geoJSON(payload.boundary, {{
      style: {{color: '#94a3b8', weight: 1, fillColor: '#f7f7f3', fillOpacity: 0.10}}
    }}).addTo(map);
    map.fitBounds(boundary.getBounds(), {{padding: [20, 20]}});

    let activeLayer = L.layerGroup().addTo(map);
    function node(caseData, idx) {{ return caseData.nodes[String(idx)]; }}
    function latLngs(caseData, seq) {{
      return seq.map(idx => node(caseData, idx)).filter(Boolean).map(n => [n.lat, n.lon]);
    }}
    function edgeKey(a, b) {{
      return Number(a) <= Number(b) ? `${{a}}-${{b}}` : `${{b}}-${{a}}`;
    }}
    function directedEdgeKey(a, b) {{
      return `${{a}}-${{b}}`;
    }}
    function routeIsChanged(route, newDemandSet) {{
      const replanned = route.replanned || [];
      const remaining = route.remaining || [];
      const hasNew = replanned.some(idx => newDemandSet.has(Number(idx)));
      return replanned.length > 0 && (hasNew || JSON.stringify(replanned) !== JSON.stringify(remaining));
    }}
    function obsoleteEdgeSequences(route) {{
      const original = [route.start_idx].concat(route.remaining).concat([route.depot_idx]);
      const replanned = [route.start_idx].concat(route.replanned).concat([route.depot_idx]);
      const replannedEdges = new Set();
      for (let i = 0; i < replanned.length - 1; i++) {{
        if (replanned[i] !== replanned[i + 1]) replannedEdges.add(directedEdgeKey(replanned[i], replanned[i + 1]));
      }}
      const obsolete = [];
      for (let i = 0; i < original.length - 1; i++) {{
        if (original[i] === original[i + 1]) continue;
        if (!replannedEdges.has(directedEdgeKey(original[i], original[i + 1]))) obsolete.push([original[i], original[i + 1]]);
      }}
      return obsolete;
    }}
    function collectBidirectionalEdges(caseData) {{
      const directed = new Set();
      caseData.routes.forEach(route => {{
        const sequences = [
          [route.depot_idx].concat(route.completed),
          [route.start_idx].concat(route.remaining).concat([route.depot_idx]),
          [route.start_idx].concat(route.replanned).concat([route.depot_idx])
        ];
        sequences.forEach(seq => {{
          for (let i = 0; i < seq.length - 1; i++) {{
            if (seq[i] !== seq[i + 1]) directed.add(`${{seq[i]}}-${{seq[i + 1]}}`);
          }}
        }});
      }});
      const bidirectional = new Set();
      directed.forEach(pair => {{
        const [a, b] = pair.split('-');
        if (directed.has(`${{b}}-${{a}}`)) bidirectional.add(edgeKey(a, b));
      }});
      return bidirectional;
    }}
    function helicopterIcon() {{
      return L.divIcon({{
        className: 'drone-icon',
        html: `<svg width="36" height="28" viewBox="0 0 96 64" aria-label="helicopter"><g fill="none" stroke="white" stroke-width="8" stroke-linecap="round"><path d="M17 12 H76"/><path d="M46 12 V25"/><path d="M18 34 L4 24"/><path d="M18 34 L4 44"/></g><g fill="none" stroke="${{colors.drone}}" stroke-width="4.5" stroke-linecap="round"><path d="M17 12 H76"/><path d="M46 12 V25"/><path d="M18 34 L4 24"/><path d="M18 34 L4 44"/></g><path d="M24 28 H60 C72 28 82 36 84 46 H37 C25 46 18 40 18 34 C18 30 20 28 24 28 Z" fill="${{colors.drone}}" stroke="white" stroke-width="3"/><path d="M62 46 H80 L88 56 H68 Z" fill="${{colors.drone}}" stroke="white" stroke-width="3"/><circle cx="38" cy="48" r="3" fill="white"/><circle cx="66" cy="48" r="3" fill="white"/></svg>`,
        iconSize: [36, 28],
        iconAnchor: [18, 14]
      }});
    }}
    function routeArrowIcon(color, angle) {{
      return L.divIcon({{
        className: 'route-arrow',
        html: `<svg width="22" height="22" viewBox="0 0 22 22" style="transform: rotate(${{angle}}deg)"><path d="M4 11 L17 4 L17 18 Z" fill="${{color}}" stroke="white" stroke-width="1.8"/></svg>`,
        iconSize: [22, 22],
        iconAnchor: [11, 11]
      }});
    }}
    function addArrowheads(caseData, seq, color, bidirectionalEdges) {{
      const pts = latLngs(caseData, seq);
      for (let i = 0; i < pts.length - 1; i++) {{
        const bidirectional = bidirectionalEdges && bidirectionalEdges.has(edgeKey(seq[i], seq[i + 1]));
        const forwardT = bidirectional ? 0.64 : 0.54;
        const lat = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * forwardT;
        const lon = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * forwardT;
        const p0 = map.latLngToLayerPoint(pts[i]);
        const p1 = map.latLngToLayerPoint(pts[i + 1]);
        const angle = Math.atan2(p1.y - p0.y, p1.x - p0.x) * 180 / Math.PI;
        L.marker([lat, lon], {{icon: routeArrowIcon(color, angle)}}).addTo(activeLayer);
        if (bidirectional) {{
          const reverseT = 0.36;
          const rlat = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * reverseT;
          const rlon = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * reverseT;
          L.marker([rlat, rlon], {{icon: routeArrowIcon(color, angle + 180)}}).addTo(activeLayer);
        }}
      }}
    }}
    function addCancelMarks(caseData, seq) {{
      const pts = latLngs(caseData, seq);
      for (let i = 0; i < pts.length - 1; i++) {{
        const lat = (pts[i][0] + pts[i + 1][0]) / 2;
        const lon = (pts[i][1] + pts[i + 1][1]) / 2;
        L.marker([lat, lon], {{
          icon: L.divIcon({{className: 'cancel-marker', html: 'x', iconSize: [27, 27], iconAnchor: [13, 13]}})
        }}).addTo(activeLayer);
      }}
    }}
    function pointPopup(n) {{
      const demand = n.demand == null ? '' : `<br>Demand: ${{Number(n.demand).toFixed(2)}} kg`;
      const corrected = n.corrected ? `<br>Original coordinate: ${{n.raw_lat.toFixed(6)}}, ${{n.raw_lon.toFixed(6)}}` : '';
      return `<b>Node</b>: ${{n.label}}<br>Latitude: ${{n.lat.toFixed(6)}}<br>Longitude: ${{n.lon.toFixed(6)}}${{demand}}${{corrected}}`;
    }}
    function drawCase(caseKey) {{
      activeLayer.clearLayers();
      const caseData = payload.cases[caseKey];
      const bidirectionalEdges = collectBidirectionalEdges(caseData);
      const newDemandSet = new Set(caseData.new_demands.map(idx => Number(idx)));
      const cancelSequences = [];
      caseData.completed_demands.forEach(idx => {{
        const n = node(caseData, idx);
        L.circleMarker([n.lat, n.lon], {{radius: 5.8, color: 'white', weight: 1.1, fillColor: colors.completed_demand, fillOpacity: 0.92}}).bindPopup(pointPopup(n)).addTo(activeLayer);
      }});
      caseData.unfinished_demands.forEach(idx => {{
        const n = node(caseData, idx);
        L.circleMarker([n.lat, n.lon], {{radius: 6.1, color: 'white', weight: 1.1, fillColor: colors.unfinished_demand, fillOpacity: 0.94}}).bindPopup(pointPopup(n)).addTo(activeLayer);
      }});
      caseData.new_demands.forEach(idx => {{
        const n = node(caseData, idx);
        L.marker([n.lat, n.lon], {{
          icon: L.divIcon({{className: '', html: `<div style="width:0;height:0;border-left:9px solid transparent;border-right:9px solid transparent;border-bottom:17px solid ${{colors.new_demand}};filter:drop-shadow(0 0 2px white) drop-shadow(0 1px 3px rgba(0,0,0,.35));"></div>`, iconSize: [20,20], iconAnchor: [10,12]}})
        }}).bindPopup(pointPopup(n)).addTo(activeLayer);
      }});
      caseData.depots.forEach(idx => {{
        const n = node(caseData, idx);
        L.marker([n.lat, n.lon], {{
          icon: L.divIcon({{className: '', html: '<div style="font-size:32px;color:#101827;text-shadow:0 0 4px white">&#9733;</div>', iconSize: [34,34], iconAnchor: [17,17]}})
        }}).bindPopup(pointPopup(n)).addTo(activeLayer);
      }});
      caseData.routes.forEach(route => {{
        const completed = [route.depot_idx].concat(route.completed);
        const remaining = [route.start_idx].concat(route.remaining).concat([route.depot_idx]);
        const replanned = [route.start_idx].concat(route.replanned).concat([route.depot_idx]);
        const changedRoute = routeIsChanged(route, newDemandSet);
        if (changedRoute) {{
          obsoleteEdgeSequences(route).forEach(edgeSeq => {{
            L.polyline(latLngs(caseData, edgeSeq), {{color: colors.remaining, weight: 1.8, opacity: 0.84, dashArray: '6 5'}}).addTo(activeLayer);
            addArrowheads(caseData, edgeSeq, colors.remaining, bidirectionalEdges);
            cancelSequences.push(edgeSeq);
          }});
        }} else if (route.remaining && route.remaining.length > 0) {{
          L.polyline(latLngs(caseData, remaining), {{color: colors.preserved, weight: 1.9, opacity: 0.84, dashArray: '7 5'}}).addTo(activeLayer);
          addArrowheads(caseData, remaining, colors.preserved, bidirectionalEdges);
        }}
        L.polyline(latLngs(caseData, completed), {{color: colors.completed, weight: 2.2, opacity: 0.96}}).addTo(activeLayer);
        addArrowheads(caseData, completed, colors.completed, bidirectionalEdges);
        if (changedRoute) {{
          L.polyline(latLngs(caseData, replanned), {{color: colors.redispatched, weight: 2.3, opacity: 0.98, dashArray: '8 5'}}).bindPopup(`<b>${{route.vehicle_id}}</b><br>Redispatched distance: ${{route.distance_km.toFixed(2)}} km<br>Load: ${{route.load_kg.toFixed(2)}} kg`).addTo(activeLayer);
          addArrowheads(caseData, replanned, colors.redispatched, bidirectionalEdges);
        }}
        const s = node(caseData, route.start_idx);
        if (s) L.marker([s.lat, s.lon], {{icon: helicopterIcon()}}).bindPopup(`<b>In-flight UAV</b><br>${{route.vehicle_id}}`).addTo(activeLayer);
      }});
      cancelSequences.forEach(seq => addCancelMarks(caseData, seq));
    }}
    document.getElementById('case-select').addEventListener('change', event => drawCase(event.target.value));
    const legend = document.querySelector('.legend');
    let dragOffset = null;
    legend.addEventListener('pointerdown', event => {{
      dragOffset = {{
        x: event.clientX - legend.getBoundingClientRect().left,
        y: event.clientY - legend.getBoundingClientRect().top
      }};
      legend.setPointerCapture(event.pointerId);
    }});
    legend.addEventListener('pointermove', event => {{
      if (!dragOffset) return;
      legend.style.left = `${{event.clientX - dragOffset.x}}px`;
      legend.style.top = `${{event.clientY - dragOffset.y}}px`;
      legend.style.right = 'auto';
      legend.style.bottom = 'auto';
    }});
    legend.addEventListener('pointerup', event => {{
      dragOffset = null;
      legend.releasePointerCapture(event.pointerId);
    }});
    document.getElementById('download').addEventListener('click', () => {{
      html2canvas(document.getElementById('map'), {{useCORS: true, scale: 3, backgroundColor: '#ffffff'}}).then(canvas => {{
        const a = document.createElement('a');
        a.download = `uav_redispatch_${{document.getElementById('case-select').value}}.png`;
        a.href = canvas.toDataURL('image/png');
        a.click();
      }});
    }});
    drawCase('MS');
  </script>
</body>
</html>
""",
        encoding="utf-8",
    )
    return out_path


def write_correction_report(cases: dict[str, dict]) -> Path:
    out_path = OUTPUT_DIR / "coordinate_correction_report.txt"
    lines = [
        "Coordinate correction report",
        "Only visualization coordinates are adjusted. Raw experiment files are not modified.",
        "",
    ]
    any_note = False
    for case, case_data in cases.items():
        notes = case_data.get("correction_notes", [])
        lines.append(f"Case {case}:")
        if notes:
            any_note = True
            lines.extend(f"  {note}" for note in notes)
        else:
            lines.append("  No out-of-bound new demand point detected.")
        lines.append("")
    if not any_note:
        lines.append("All plotted new demand points are inside the Shenzhen boundary.")
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    geojson = load_boundary()
    cases = {case: read_case(case, geojson) for case in CASE_CONFIGS}
    static_outputs = [plot_case(case_data, geojson, detailed_basemap=False) for case_data in cases.values()]
    html_output = build_interactive_html(cases, geojson)
    print("Generated files:")
    for path in static_outputs:
        print(path)
    print(html_output)


if __name__ == "__main__":
    main()
