import os
import math
import random
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple, Dict

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SECTION_422_DIR = Path(__file__).resolve().parent
SECTION_421_DIR = SECTION_422_DIR.parent / "4.2.1"
if str(SECTION_421_DIR) not in sys.path:
    sys.path.insert(0, str(SECTION_421_DIR))

from A5_Turbo_ALNS import (
    MDVRPInstanceCSV,
    ALNSTurboSolver,
    Solution,
    calc_dist_matrix_haversine,
)

# =============================
# 0. 参数区
# =============================
# 需要跑的算例列表（改这里做其他算例）
CASES = ["M", "MS", "S"]
DATA_DIR = str(SECTION_421_DIR / "case_input_data")
SAVED_ROUTES_DIR = str(SECTION_421_DIR / "Turbo_ALNS_Results")
OUTPUT_DIR = str(SECTION_422_DIR / "Disruption_Results")
SEED = 42
CUT_MIN = 15  # 扰动发生时间（分钟）做敏感性分析可改这里
NEW_DEMAND_NUM = 5
NEW_DEMAND_MAX = 20  # 新增需求点需求量上限（kg）

# 指定每个算例新增需求点数量（未指定则使用 NEW_DEMAND_NUM）
NEW_DEMAND_NUM_BY_CASE = {
    "M": 4,
    "MS": 2,
    "S": 1
}

# 是否读取已有求解结果（Turbo_ALNS_Results）
# True: 读取已保存的 routes 作为原定任务路径
# False: 现场重新求解原定任务路径
USE_SAVED_ROUTES = True

# 约束（与主模型一致）
MAX_PAYLOAD = 80.0
MAX_RANGE_KM = 45.0
SPEED_KMH = 54.0  # 15 m/s
MAX_VEHICLES_PER_DEPOT = 5

# =============================
# 1. 辅助函数
# =============================

def _ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def lighten_color(color, factor=0.55):
    r, g, b = color[0], color[1], color[2]
    return (1 - factor * (1 - r), 1 - factor * (1 - g), 1 - factor * (1 - b), 1.0)


def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dl / 2) ** 2
    c = 2 * math.asin(math.sqrt(a))
    return R * c


def route_distance_from(start_idx: int, route: List[int], depot_idx: int, dist_matrix: np.ndarray) -> float:
    if not route:
        return 0.0
    dist = dist_matrix[start_idx, route[0]]
    for i in range(len(route) - 1):
        dist += dist_matrix[route[i], route[i + 1]]
    dist += dist_matrix[route[-1], depot_idx]
    return float(dist)


def calc_delta(dist_matrix: np.ndarray, prev_node: int, next_node: int, target_node: int) -> float:
    return (
        dist_matrix[prev_node, target_node]
        + dist_matrix[target_node, next_node]
        - dist_matrix[prev_node, next_node]
    )


@dataclass
class VehicleState:
    vid: str
    depot_idx: int
    start_idx: int
    remaining_capacity: float
    remaining_range: float
    color: Tuple[float, float, float, float]
    new_route: List[int]
    new_route_dist: float = 0.0
    original_route: List[int] = None
    original_route_dist: float = 0.0
    completed_nodes: List[int] = None
    completed_dist: float = 0.0
    remaining_nodes: List[int] = None
    remaining_payload: float = 0.0


# =============================
# 2. 生成新增需求点
# =============================

def generate_new_demands(inst: MDVRPInstanceCSV, k: int, max_demand: float, seed: int):
    rng = random.Random(seed)
    lat_deg = np.degrees(inst.np_lat[:inst.n])
    lon_deg = np.degrees(inst.np_lon[:inst.n])
    dep_lat = np.degrees(inst.np_lat[inst.n:inst.n + inst.d])
    dep_lon = np.degrees(inst.np_lon[inst.n:inst.n + inst.d])

    lat_min, lat_max = float(lat_deg.min()), float(lat_deg.max())
    lon_min, lon_max = float(lon_deg.min()), float(lon_deg.max())

    new_points = []
    attempts = 0
    while len(new_points) < k and attempts < 5000:
        attempts += 1
        lat = rng.uniform(lat_min, lat_max)
        lon = rng.uniform(lon_min, lon_max)
        dem = rng.uniform(0, max_demand)

        # 最近供应点单程距离，确保往返不超过航程
        min_dist = 1e9
        for slat, slon in zip(dep_lat, dep_lon):
            d = haversine_km(lat, lon, slat, slon)
            if d < min_dist:
                min_dist = d
        if min_dist * 2 <= inst.D:
            new_points.append((lat, lon, dem))

    if len(new_points) < k:
        raise RuntimeError("无法生成满足航程约束的新需求点，请检查范围或航程设置。")

    return new_points


# =============================
# 3. 构建扩展实例
# =============================

class MDVRPInstanceAug:
    def __init__(self):
        self.supply_path = ""
        self.demand_path = ""
        self.model_name = "H880"
        self.max_payload = MAX_PAYLOAD
        self.max_range_km = MAX_RANGE_KM
        self.speed_kmh = SPEED_KMH

        self.m = 0
        self.n = 0
        self.d = 0
        self.D = 0.0
        self.Q = 0.0
        self.nodes = []
        self.np_lat = None
        self.np_lon = None
        self.np_demands = None
        self.np_services = None
        self.dist_matrix = None
        self.max_vehicles_per_depot = MAX_VEHICLES_PER_DEPOT
        self.invalid_supply_rows = 0
        self.invalid_demand_rows = 0


def build_augmented_instance(base_inst: MDVRPInstanceCSV, new_demands: List[Tuple[float, float, float]]):
    aug = MDVRPInstanceAug()
    aug.max_payload = base_inst.max_payload
    aug.max_range_km = base_inst.max_range_km
    aug.speed_kmh = base_inst.speed_kmh
    aug.Q = aug.max_payload
    aug.D = aug.max_range_km
    aug.d = base_inst.d
    aug.n = base_inst.n + len(new_demands)

    lat_list = list(np.degrees(base_inst.np_lat[:base_inst.n]))
    lon_list = list(np.degrees(base_inst.np_lon[:base_inst.n]))
    dem_list = list(base_inst.np_demands[:base_inst.n])

    for lat, lon, dem in new_demands:
        lat_list.append(lat)
        lon_list.append(lon)
        dem_list.append(dem)

    # 供应点
    dep_lat = np.degrees(base_inst.np_lat[base_inst.n:base_inst.n + base_inst.d])
    dep_lon = np.degrees(base_inst.np_lon[base_inst.n:base_inst.n + base_inst.d])
    for lat, lon in zip(dep_lat, dep_lon):
        lat_list.append(float(lat))
        lon_list.append(float(lon))
        dem_list.append(0.0)

    aug.nodes = [{"id": i, "idx": i} for i in range(len(lat_list))]
    aug.np_lat = np.radians(np.array(lat_list, dtype=np.float64))
    aug.np_lon = np.radians(np.array(lon_list, dtype=np.float64))
    aug.np_demands = np.array(dem_list, dtype=np.float64)
    aug.np_services = np.zeros_like(aug.np_demands)

    aug.dist_matrix = calc_dist_matrix_haversine(aug.np_lat, aug.np_lon, len(aug.nodes))
    return aug


# =============================
# 4. 路线截断逻辑
# =============================

def split_route_by_time(route: List[int], depot_idx: int, cut_h: float, speed_kmh: float, dist_matrix: np.ndarray):
    # 简化假设：扰动发生在最后一个已完成节点处；若在边上，当前位置取上一节点
    if not route:
        return [], [], depot_idx, 0.0

    path = [depot_idx] + route + [depot_idx]
    dist_acc = 0.0
    completed_dist = 0.0
    time_acc = 0.0
    completed = []

    for i in range(1, len(path)):
        seg = dist_matrix[path[i - 1], path[i]]
        seg_time = seg / speed_kmh
        if time_acc + seg_time <= cut_h:
            time_acc += seg_time
            dist_acc += seg
            # 到达需求点则记为完成（回到 depot 不计）
            if i < len(path) - 1:
                completed.append(path[i])
                completed_dist += seg
        else:
            # 扰动发生在该段中间
            remaining = [n for n in route if n not in completed]
            return completed, remaining, (path[i - 1]), completed_dist, dist_acc + (cut_h - time_acc) * speed_kmh

    # 全部完成
    return completed, [], depot_idx, completed_dist, dist_acc


# =============================
# 5. 重新规划（局部调优）
# =============================

def greedy_repair(unassigned: List[int], vehicles: List[VehicleState], inst: MDVRPInstanceAug):
    random.shuffle(unassigned)

    for node in list(unassigned):
        demand = inst.np_demands[node]
        best = None

        for v in vehicles:
            # 不受扰动影响且已完成的原路径，不参与重新规划
            if not (v.vid.startswith("N") or (v.remaining_nodes and len(v.remaining_nodes) > 0)):
                continue
            if demand > v.remaining_capacity:
                continue

            # 允许在当前位置为起点插入
            r = v.new_route
            if not r:
                delta = inst.dist_matrix[v.start_idx, node] + inst.dist_matrix[node, v.depot_idx]
                if delta <= v.remaining_range:
                    if best is None or delta < best[0]:
                        best = (delta, v, 0)
            else:
                # 插入位置
                for pos in range(len(r) + 1):
                    prev_node = v.start_idx if pos == 0 else r[pos - 1]
                    next_node = v.depot_idx if pos == len(r) else r[pos]
                    delta = calc_delta(inst.dist_matrix, prev_node, next_node, node)
                    if v.new_route_dist + delta <= v.remaining_range:
                        if best is None or delta < best[0]:
                            best = (delta, v, pos)

        if best is not None:
            delta, v, pos = best
            v.new_route.insert(pos, node)
            v.new_route_dist += delta
            v.remaining_capacity -= demand
            unassigned.remove(node)

    return unassigned


# =============================
# 6. 主流程
# =============================

def main():
    random.seed(SEED)
    np.random.seed(SEED)

    for case in CASES:
        supply_path = os.path.join(DATA_DIR, f"supplyTable_{case}.csv")
        demand_path = os.path.join(DATA_DIR, f"demand_{case}.csv")

        inst = MDVRPInstanceCSV(
            supply_path,
            demand_path,
            max_payload=MAX_PAYLOAD,
            max_range_km=MAX_RANGE_KM,
            speed_kmh=SPEED_KMH,
        )
        inst.load()

        if USE_SAVED_ROUTES:
            routes_path = os.path.join(SAVED_ROUTES_DIR, f"A5_{case}_routes.csv")
            if not os.path.exists(routes_path):
                raise FileNotFoundError(f"未找到已保存的路径文件: {routes_path}")

            # 构造 Solution 以承载已有路线
            best_sol = Solution(inst)
            best_sol.routes = {d: [] for d in range(inst.n, inst.n + inst.d)}

            with open(routes_path, "r", encoding="utf-8-sig", errors="ignore") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    depot_idx = int(row["depot_idx"])
                    route_id = int(row["route_id"])
                    nodes = [int(x) for x in str(row["node_indices"]).split(";") if x != ""]
                    while len(best_sol.routes[depot_idx]) <= route_id:
                        best_sol.routes[depot_idx].append(np.array([], dtype=np.int32))
                    best_sol.routes[depot_idx][route_id] = np.array(nodes, dtype=np.int32)
        else:
            solver = ALNSTurboSolver(inst)
            obj, best_sol = solver.solve(max_iters=50000, time_limit=180)

        # 生成新增需求点并构建扩展实例
        new_num = NEW_DEMAND_NUM_BY_CASE.get(case, NEW_DEMAND_NUM)
        new_demands = generate_new_demands(inst, new_num, NEW_DEMAND_MAX, SEED)
        aug = build_augmented_instance(inst, new_demands)

        # 原始路线（更新 depot 索引）
        new_n = aug.n
        depot_shift = new_num
        orig_routes = {}
        for old_depot_idx, routes in best_sol.routes.items():
            new_depot_idx = old_depot_idx + depot_shift
            orig_routes[new_depot_idx] = [r.copy() for r in routes]

        # 路线截断
        cut_h = CUT_MIN / 60.0
        truncated_routes = []
        unserved = []
        completed_segments = []
        unfinished_segments = []
        original_route_map = {}
        unchanged_routes = []
        route_color_map = {}

        colors = plt.cm.get_cmap('tab20')
        vehicle_states: List[VehicleState] = []
        vehicle_count = 0

        for depot_idx, routes in orig_routes.items():
            for ridx, r in enumerate(routes):
                route = [int(x) for x in r.tolist()]
                completed, remaining, current_pos, completed_dist, dist_traveled = split_route_by_time(
                    route, depot_idx, cut_h, aug.speed_kmh, aug.dist_matrix
                )
                original_route_map[(depot_idx, ridx)] = route

                # 记录可视化分段
                route_color_map[(depot_idx, ridx)] = colors(vehicle_count % 20)
                if remaining:
                    if completed:
                        completed_segments.append((depot_idx, ridx, completed))
                    unfinished_segments.append((depot_idx, ridx, current_pos, remaining))
                    truncated_routes.append((depot_idx, ridx))
                else:
                    unchanged_routes.append((depot_idx, ridx, route))

                # 空中无人机（保留未完成路径顺序）
                initial_load = float(np.sum(aug.np_demands[route]))
                delivered_load = float(np.sum(aug.np_demands[completed]))
                remaining_load = max(0.0, initial_load - delivered_load)
                remaining_range = max(0.0, aug.D - dist_traveled)
                original_route_dist = route_distance_from(depot_idx, route, depot_idx, aug.dist_matrix)
                remaining_capacity = max(0.0, aug.Q - remaining_load)
                remaining_route_dist = route_distance_from(current_pos, remaining, depot_idx, aug.dist_matrix) if remaining else 0.0

                v = VehicleState(
                    vid=f"D{depot_idx}_R{ridx}",
                    depot_idx=depot_idx,
                    start_idx=current_pos,
                    remaining_capacity=remaining_capacity,
                    remaining_range=remaining_range,
                    color=route_color_map[(depot_idx, ridx)],
                    new_route=list(remaining),
                    new_route_dist=remaining_route_dist,
                    original_route=route,
                    original_route_dist=original_route_dist,
                    completed_nodes=completed,
                    completed_dist=completed_dist,
                    remaining_nodes=remaining,
                    remaining_payload=remaining_load
                )
                vehicle_states.append(v)
                vehicle_count += 1

        # 新增需求点索引（仅新增点进入重规划，未完成原路径保持原顺序）
        new_nodes = list(range(inst.n, inst.n + new_num))
        unserved.extend(new_nodes)

        # 还未起飞的无人机：按每个 depot 的上限补齐
        used_per_depot = {d: len(r) for d, r in orig_routes.items()}
        for depot_idx in orig_routes.keys():
            remain = max(0, MAX_VEHICLES_PER_DEPOT - used_per_depot.get(depot_idx, 0))
            for i in range(remain):
                v = VehicleState(
                    vid=f"N{depot_idx}_{i}",
                    depot_idx=depot_idx,
                    start_idx=depot_idx,
                    remaining_capacity=aug.Q,
                    remaining_range=aug.D,
                    color=colors(vehicle_count % 20),
                    new_route=[],
                    original_route=[],
                    original_route_dist=0.0,
                    completed_nodes=[],
                    completed_dist=0.0,
                    remaining_nodes=[],
                    remaining_payload=0.0
                )
                vehicle_states.append(v)
                vehicle_count += 1

        # 局部调优（贪心修复）
        unassigned = greedy_repair(unserved, vehicle_states, aug)

        # =============================
        # 7. 输出与可视化
        # =============================
        res_dir = OUTPUT_DIR
        _ensure_dir(res_dir)

        # 文本输出
        summary_path = os.path.join(res_dir, f"A5_{case}_disruption_summary.txt")
        with open(summary_path, "w", encoding="utf-8") as f:
            f.write("=== 扰动分析说明 ===\n")
            f.write(f"扰动时间: {CUT_MIN} min\n")
            f.write(f"新增需求点数量: {new_num}\n")
            f.write("决策说明: \n")
            f.write("1) 扰动发生在最后一个已完成节点处，未完成节点进入重规划。\n")
            f.write("2) 空中无人机以剩余载重/航程参与重规划，若不可行则返回。\n")
            f.write("3) 新增无人机用前缀 N 标识，起点为 depot，能力为满载。\n")
            f.write("\n--- 新增需求点 ---\n")
            for i, (lat, lon, dem) in enumerate(new_demands):
                idx = inst.n + i
                f.write(f"idx={idx}, lat={lat:.6f}, lon={lon:.6f}, demand={dem:.6f}\n")
            f.write("\n--- 被截断的原有路线 ---\n")
            for d, r in truncated_routes:
                f.write(f"depot {d} route {r}\n")
            f.write("\n--- 未分配节点 ---\n")
            f.write(",".join(map(str, unassigned)) + "\n")

        # 详情 CSV
        detail_path = os.path.join(res_dir, f"A5_{case}_disruption_routes.csv")
        tmp_detail_path = detail_path + ".tmp"
        with open(tmp_detail_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=[
                "vehicle_id", "depot_idx", "start_idx",
                "original_route_nodes", "original_route_distance_km",
                "completed_nodes", "completed_distance_km",
                "remaining_nodes", "remaining_payload", "remaining_capacity", "remaining_range",
                "new_route_nodes", "new_route_distance_km", "new_route_load_kg"
            ])
            writer.writeheader()
            for v in vehicle_states:
                new_route_dist = route_distance_from(v.start_idx, v.new_route, v.depot_idx, aug.dist_matrix)
                new_route_load = float(np.sum(aug.np_demands[v.new_route])) if v.new_route else 0.0
                remaining_capacity = max(0.0, aug.Q - v.remaining_payload)
                writer.writerow({
                    "vehicle_id": v.vid,
                    "depot_idx": v.depot_idx,
                    "start_idx": v.start_idx,
                    "original_route_nodes": ";".join(str(x) for x in (v.original_route or [])),
                    "original_route_distance_km": round(v.original_route_dist, 6),
                    "completed_nodes": ";".join(str(x) for x in (v.completed_nodes or [])),
                    "completed_distance_km": round(v.completed_dist, 6),
                    "remaining_nodes": ";".join(str(x) for x in (v.remaining_nodes or [])),
                    "remaining_payload": round(v.remaining_payload, 6),
                    "remaining_capacity": round(remaining_capacity, 6),
                    "remaining_range": round(v.remaining_range, 6),
                    "new_route_nodes": ";".join(str(x) for x in v.new_route),
                    "new_route_distance_km": round(new_route_dist, 6),
                    "new_route_load_kg": round(new_route_load, 6)
                })
        try:
            os.replace(tmp_detail_path, detail_path)
        except PermissionError:
            # 若文件被占用，保留临时文件并提示
            detail_path = tmp_detail_path

        # 可视化
        plt.figure(figsize=(11, 9))
        lon_deg = np.degrees(aug.np_lon)
        lat_deg = np.degrees(aug.np_lat)

        depot_lon = lon_deg[aug.n:]
        depot_lat = lat_deg[aug.n:]
        demand_lon = lon_deg[:aug.n]
        demand_lat = lat_deg[:aug.n]

        completed_set = set()
        for _, _, nodes in completed_segments:
            completed_set.update(nodes)
        unfinished_set = set()
        for _, _, _, nodes in unfinished_segments:
            unfinished_set.update(nodes)
        new_set = set(new_nodes)

        all_original = set(range(inst.n))
        completed_only = completed_set & all_original
        unfinished_only = unfinished_set & all_original
        other_original = all_original - completed_only - unfinished_only

        if other_original:
            idx = sorted(other_original)
            plt.scatter(lon_deg[idx], lat_deg[idx], c='#B0BEC5', alpha=0.5, s=18, label='Original (other)')
        if completed_only:
            idx = sorted(completed_only)
            plt.scatter(lon_deg[idx], lat_deg[idx], c='#81C784', alpha=0.7, s=24, label='Completed')
        if unfinished_only:
            idx = sorted(unfinished_only)
            plt.scatter(lon_deg[idx], lat_deg[idx], c='#FFB74D', alpha=0.8, s=24, label='Unfinished')
        if new_set:
            idx = sorted(new_set)
            plt.scatter(lon_deg[idx], lat_deg[idx], c='#EF5350', alpha=0.9, s=36, marker='^', label='New Demand')

        plt.scatter(depot_lon, depot_lat, c='#212121', marker='*', s=160, edgecolors='white', linewidths=0.6, label='Depot')

        # 未受扰动路径：保留原有顺序（浅色实线）
        for depot_idx, ridx, nodes in unchanged_routes:
            pts = [depot_idx] + nodes + [depot_idx]
            base_color = route_color_map.get((depot_idx, ridx), (0.6, 0.6, 0.6, 1.0))
            plt.plot(lon_deg[pts], lat_deg[pts], linestyle='-', alpha=0.6, linewidth=1.5, color=lighten_color(base_color))

        # 识别截断但未因新增需求改变的路线（仍保持原有顺序）
        unchanged_truncated = set()
        for v in vehicle_states:
            if v.remaining_nodes:
                has_new = any(n in new_set for n in v.new_route)
                if not has_new and list(v.new_route) == list(v.remaining_nodes):
                    ridx = int(v.vid.split("_R")[-1])
                    unchanged_truncated.add((v.depot_idx, ridx))

        # 已完成原路径（浅色实线）
        for depot_idx, ridx, nodes in completed_segments:
            if (depot_idx, ridx) in unchanged_truncated:
                continue
            pts = [depot_idx] + nodes
            base_color = route_color_map.get((depot_idx, ridx), (0.6, 0.6, 0.6, 1.0))
            plt.plot(lon_deg[pts], lat_deg[pts], linestyle='-', alpha=0.6, linewidth=1.5, color=lighten_color(base_color))

        # 未完成原路径（浅色虚线）
        for depot_idx, ridx, start_idx, nodes in unfinished_segments:
            if (depot_idx, ridx) in unchanged_truncated:
                # 未受新增需求影响的截断路线：画原有顺序的完整路线
                original = original_route_map.get((depot_idx, ridx), [])
                if original:
                    full = [depot_idx] + original + [depot_idx]
                    base_color = route_color_map.get((depot_idx, ridx), (0.6, 0.6, 0.6, 1.0))
                    plt.plot(lon_deg[full], lat_deg[full], linestyle='-', alpha=0.6, linewidth=1.5, color=lighten_color(base_color))
                continue
            pts = [start_idx] + nodes + [depot_idx]
            base_color = route_color_map.get((depot_idx, ridx), (0.6, 0.6, 0.6, 1.0))
            plt.plot(lon_deg[pts], lat_deg[pts], linestyle='--', alpha=0.6, linewidth=1.5, color=lighten_color(base_color))

        # 仅对“下一服务点发生变化”的受扰动路线：
        # 1) 在“当前点 -> 原下一服务点”的路径上打叉号
        # 2) 用虚线箭头标出“当前点 -> 新的下一服务点”
        for v in vehicle_states:
            if not v.remaining_nodes:
                continue
            has_new = any(n in new_set for n in v.new_route)
            if not has_new and list(v.new_route) == list(v.remaining_nodes):
                continue

            original_next = v.remaining_nodes[0]
            new_next = v.new_route[0] if v.new_route else None
            if new_next is None or new_next == original_next:
                continue

            x0, y0 = lon_deg[v.start_idx], lat_deg[v.start_idx]
            x1, y1 = lon_deg[original_next], lat_deg[original_next]
            xm, ym = (x0 + x1) / 2.0, (y0 + y1) / 2.0

            plt.scatter([xm], [ym], marker='x', c=[v.color], s=70, linewidths=1.8)

            xn, yn = lon_deg[new_next], lat_deg[new_next]
            plt.annotate(
                "",
                xy=(xn, yn),
                xytext=(x0, y0),
                arrowprops=dict(arrowstyle="->", color=v.color, lw=1.4, linestyle='--')
            )

        # 新路线（深色虚线），新增无人机加箭头
        for v in vehicle_states:
            if not v.new_route:
                continue
            if v.remaining_nodes:
                has_new = any(n in new_set for n in v.new_route)
                if not has_new and list(v.new_route) == list(v.remaining_nodes):
                    # 未受新增需求影响的截断路线，不绘制“新路线”虚线
                    continue
            pts = [v.start_idx] + v.new_route + [v.depot_idx]
            plt.plot(lon_deg[pts], lat_deg[pts], linestyle='--', alpha=0.9, linewidth=1.8, color=v.color)

            if v.vid.startswith("N"):
                for i in range(len(pts) - 1):
                    x0, y0 = lon_deg[pts[i]], lat_deg[pts[i]]
                    x1, y1 = lon_deg[pts[i + 1]], lat_deg[pts[i + 1]]
                    plt.annotate(
                        "",
                        xy=(x1, y1),
                        xytext=(x0, y0),
                        arrowprops=dict(arrowstyle="->", color=v.color, lw=1.2, linestyle='--')
                    )

        plt.title(f"Disruption Analysis | A5_{case}")
        plt.xlabel('Longitude')
        plt.ylabel('Latitude')
        plt.legend(loc='best', frameon=False)
        plt.tight_layout()
        plt.savefig(os.path.join(res_dir, f"A5_{case}_disruption.png"), dpi=200)
        plt.close()

        print(f"结果已保存: {summary_path}")
        print(f"路线详情已保存: {detail_path}")


if __name__ == "__main__":
    main()
