# Model Prior Knowledge: Basic Model for UAV Emergency Logistics Network Optimization

## 1. Purpose

This file is used as **model prior knowledge** in a knowledge-driven Human–LLM interaction framework.


## 2. Problem Background

In the context of sudden disasters, multiple UAV bases are distributed within an emergency response area, and different affected demand points have deterministic demands for relief supplies. UAVs depart from their assigned bases and return to their original bases after completing delivery tasks. The system is subject to the following constraints:

- Each demand point must be served once;
- Each UAV must depart from its assigned base and return to the same base;
- The number of UAVs available at each base is limited;
- The payload capacity of each UAV is limited;
- The maximum mission duration or maximum flight distance of each UAV is limited;
- Customer subtours that are disconnected from any base must not appear in the routes.

The optimization objective is to minimize the total flight distance of all UAV routes.

## 3. Sets and Indices

- \(\mathcal{C}=\{1,2,\ldots,n\}\): set of affected demand points.
- \(\mathcal{B}=\{n+1,n+2,\ldots,n+t\}\): set of UAV bases, where \(t\) denotes the number of UAV bases.
- \(\mathcal{V}=\mathcal{C}\cup\mathcal{B}\): set of all logistics nodes.
- \(\mathcal{A}=\{(i,j)\mid i,j\in\mathcal{V},\ i\neq j\}\): set of allowable flight arcs.
- \(\mathcal{K}_b=\{1,2,\ldots,A_b\}\): set of UAVs available for dispatch from base \(b\).

## 4. Parameters

- \(d_{ij}\): distance from node \(i\) to node \(j\).
- \(q_i\): relief-supply demand of demand point \(i\), where \(q_i>0\).
- \(s_i\): service time at demand point \(i\).
- \(Q_b\): rated payload capacity of the UAVs assigned to base \(b\).
- \(T_b\): maximum route duration allowed for a single mission of a UAV assigned to base \(b\).
- \(A_b\): maximum number of available UAVs at base \(b\).
- The demand of each base node is set to 0.

## 5. Decision Variables

- \(x_{ij}^{bk}\in\{0,1\}\): equals 1 if the \(k\)-th UAV from base \(b\) flies directly from node \(i\) to node \(j\); otherwise, it equals 0.
- \(u_i^{bk}\in\mathbb{R}_{+}\): visiting order of demand point \(i\) by the \(k\)-th UAV from base \(b\), used for MTZ subtour elimination.

## 6. Objective Function

The objective is to minimize the total flight distance of all UAV missions:

\[
\min Z=
\sum_{b\in\mathcal{B}}
\sum_{k\in\mathcal{K}_b}
\sum_{\substack{(i,j)\in\mathcal{A}\\ i,j\in\mathcal{C}\cup\{b\}}}
d_{ij}x_{ij}^{bk}.
\]

## 7. Constraints

### 7.1 Unique Visit Constraint for Demand Points

Each demand point must be visited exactly once:

\[
\sum_{b\in\mathcal{B}}
\sum_{k\in\mathcal{K}_b}
\sum_{\substack{j\in\mathcal{C}\cup\{b\}\\ j\neq i}}
x_{ij}^{bk}
=1,
\quad \forall i\in\mathcal{C}.
\]

### 7.2 Route Flow Balance Constraint

After a UAV arrives at a demand point, it must leave that demand point:

\[
\sum_{\substack{j\in\mathcal{C}\cup\{b\}\\ j\neq i}}
x_{ji}^{bk}
-
\sum_{\substack{j\in\mathcal{C}\cup\{b\}\\ j\neq i}}
x_{ij}^{bk}
=0,
\quad \forall i\in\mathcal{C},\ b\in\mathcal{B},\ k\in\mathcal{K}_b.
\]

### 7.3 Base Departure Constraint

Each UAV may depart from its assigned base at most once:

\[
\sum_{j\in\mathcal{C}}x_{bj}^{bk}
\leq 1,
\quad \forall b\in\mathcal{B},\ k\in\mathcal{K}_b.
\]

### 7.4 Return-to-Assigned-Base Constraint

After completing its mission, each UAV must return to the same assigned base:

\[
\sum_{j\in\mathcal{C}}x_{bj}^{bk}
=
\sum_{i\in\mathcal{C}}x_{ib}^{bk},
\quad \forall b\in\mathcal{B},\ k\in\mathcal{K}_b.
\]

### 7.5 Payload Capacity Constraint

The total demand served by each UAV must not exceed its maximum payload capacity:

\[
\sum_{i\in\mathcal{C}}q_i
\sum_{\substack{j\in\mathcal{C}\cup\{b\}\\ j\neq i}}
x_{ij}^{bk}
\leq Q_b,
\quad \forall b\in\mathcal{B},\ k\in\mathcal{K}_b.
\]

### 7.6 Route Duration Constraint

The total mission duration of each UAV must not exceed the maximum route duration. The total mission duration includes flight distance and service time at demand points:

\[
\sum_{\substack{(i,j)\in\mathcal{A}\\ i,j\in\mathcal{C}\cup\{b\}}}
d_{ij}x_{ij}^{bk}
+
\sum_{i\in\mathcal{C}}s_i
\sum_{\substack{j\in\mathcal{C}\cup\{b\}\\ j\neq i}}
x_{ij}^{bk}
\leq T_b,
\quad \forall b\in\mathcal{B},\ k\in\mathcal{K}_b,\ T_b>0.
\]

If an instance does not consider the route-duration constraint, this constraint can be regarded as inactive; if service time is not considered, set \(s_i=0\).

### 7.7 MTZ Subtour Elimination Constraint

Customer subtours are eliminated through visiting-order variables:

\[
u_i^{bk}-u_j^{bk}
+
nx_{ij}^{bk}
\leq n-1,
\quad \forall i,j\in\mathcal{C},\ i\neq j,\ b\in\mathcal{B},\ k\in\mathcal{K}_b.
\]

### 7.8 Activation Range of Visiting-Order Variables

The visiting-order variable is activated only when the corresponding demand point is visited by the corresponding UAV:

\[
\sum_{\substack{j\in\mathcal{C}\cup\{b\}\\ j\neq i}}
x_{ij}^{bk}
\leq
u_i^{bk}
\leq
n
\sum_{\substack{j\in\mathcal{C}\cup\{b\}\\ j\neq i}}
x_{ij}^{bk},
\quad \forall i\in\mathcal{C},\ b\in\mathcal{B},\ k\in\mathcal{K}_b.
\]

### 7.9 Binary Variable Domain

\[
x_{ij}^{bk}\in\{0,1\},
\quad
\forall b\in\mathcal{B},\ k\in\mathcal{K}_b,\ (i,j)\in\mathcal{A},\ i,j\in\mathcal{C}\cup\{b\}.
\]

## 8. Key Modeling Logic

1. Each demand point must be served once.
2. Each UAV route must depart from its assigned base and return to the same base.
3. The actual number of UAVs used at each base is jointly limited by \(\mathcal{K}_b=\{1,2,\ldots,A_b\}\) and the base departure constraint, so no additional base-level UAV-count constraint is required.
4. The payload constraint ensures that the total demand served by each route does not exceed the UAV payload capacity.
5. The route-duration constraint ensures that the sum of flight distance and service time does not exceed the maximum mission duration.
6. The MTZ constraint is used to prevent subtours among demand points that are disconnected from any base.
7. The model output must be convertible into route-level solutions and subject to independent feasibility checks.
