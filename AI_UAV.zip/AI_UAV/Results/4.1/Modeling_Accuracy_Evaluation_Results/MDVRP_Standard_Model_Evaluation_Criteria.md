# MDVRP_Standard_Model_Evaluation_Criteria

## 1. General Evaluation Principle

The evaluated model should be judged by whether its mathematical structure is equivalent to the standard multi-depot vehicle routing problem (MDVRP) structure described below. The exact symbols, variable names, index names, and notation forms do not need to be identical. A model element should be regarded as correct if it expresses the same modeling logic and can support the same route-level feasibility requirements.

Equivalent formulations are acceptable, including but not limited to arc-flow formulations, vehicle-indexed formulations, depot-indexed formulations, or formulations using auxiliary assignment variables, provided that the essential MDVRP logic is preserved.

## 2. Standard Sets and Indices

A correct MDVRP model should include the following structural sets or their equivalent forms:

- A set of demand/customer nodes.
- A set of depots or UAV bases.
- A set of all nodes, usually composed of demand nodes and depot/base nodes.
- A set of feasible travel arcs or edges between nodes.
- A set of vehicles available at each depot/base, or an equivalent vehicle-capacity representation that limits the number of vehicles dispatched from each depot/base.

The symbols used for these sets may vary. The evaluation should focus on whether the sets support multi-depot routing, demand-node service, depot-specific vehicle dispatch, and route construction.

## 3. Standard Parameters

A correct MDVRP model should include the following parameters or their equivalent meanings:

- Travel distance, travel cost, or travel time between nodes.
- Demand quantity of each demand/customer node.
- Vehicle capacity or payload capacity.
- Number of available vehicles at each depot/base.
- Maximum route duration, maximum travel distance, or endurance limit, if the tested instance considers such a restriction.
- Service time at demand/customer nodes, if service time is considered in the tested instance.
- Zero demand for depot/base nodes, either explicitly stated or implicitly ensured by the formulation.

A parameter should be regarded as correct if its meaning is clear and it is used consistently in the objective function or constraints. The exact parameter symbol does not need to match this standard.

## 4. Standard Decision Variables

A correct MDVRP model should include the following decision-variable structures or equivalent alternatives:

- A binary routing variable indicating whether a vehicle travels directly from one node to another.
- A depot/base or vehicle association structure that ensures each vehicle route is linked to one specific depot/base.
- An auxiliary variable or equivalent mechanism for subtour elimination, such as MTZ order variables, flow-based variables, commodity-flow variables, cut-set constraints, or another valid subtour-elimination formulation.

A model may also include assignment variables, vehicle-use variables, load variables, arrival-time variables, or route-duration variables. These are acceptable when they are mathematically consistent and do not change the standard MDVRP structure.

## 5. Standard Objective Function

The standard objective is to minimize the total routing cost of all vehicle routes. In the basic benchmark setting, this is normally the total travel distance:

\[
\min Z = \sum \text{travel distance or travel cost of all selected arcs/routes}.
\]

An objective function should be regarded as correct if it minimizes the total distance, cost, or travel metric over all vehicles and all depots/bases. Minor notation differences are acceptable.

The following issues should be regarded as objective-function errors:

- Maximizing instead of minimizing the routing cost.
- Omitting travel distance or travel cost from the objective.
- Optimizing an unrelated objective that changes the standard MDVRP problem meaning.
- Double-counting or under-counting arcs in a way that changes route cost calculation.

## 6. Standard Constraints

### 6.1 Unique Service of Each Demand Node

Each demand/customer node must be served exactly once by one vehicle from one depot/base.

Correct equivalent forms may use incoming arcs, outgoing arcs, assignment variables, or route-selection variables. The key requirement is that every demand node is visited once and only once.

### 6.2 Route Flow Conservation at Demand Nodes

For each vehicle route, if the vehicle enters a demand/customer node, it must also leave that node.

Equivalent formulations are acceptable as long as they maintain continuous routes and prevent disconnected or incomplete customer visits.

### 6.3 Depot/Base Departure Constraint

Each used vehicle must depart from its assigned depot/base, and each vehicle should be dispatched at most once.

Equivalent formulations may use vehicle-use variables, depot-copy nodes, or route variables. The key requirement is that the number of routes dispatched from each depot/base does not exceed the number of available vehicles.

### 6.4 Return-to-Same-Depot/Base Constraint

Each vehicle route must return to the same depot/base from which it departed.

A formulation that allows a vehicle to start from one depot/base and return to another depot/base should be regarded as incorrect unless the problem is explicitly defined as an open or inter-depot routing variant.

### 6.5 Vehicle-Availability Constraint

The number of vehicles used at each depot/base must not exceed the available vehicle quantity at that depot/base.

This can be expressed directly through a depot-level vehicle-count constraint or indirectly by defining a fixed vehicle set for each depot/base and limiting each vehicle to at most one route.

### 6.6 Capacity Constraint

The total demand served by each vehicle route must not exceed the vehicle capacity or payload limit.

Equivalent formulations based on load accumulation, route assignment, or served-demand summation are acceptable.

### 6.7 Route-Duration or Endurance Constraint

If the tested instance includes a maximum route duration, maximum route length, or endurance limit, each vehicle route must satisfy that limit.

The route duration may include travel distance/time and service time where applicable. If the tested instance does not include service time, service time may be omitted or set to zero.

### 6.8 Subtour-Elimination Constraint

The model must prevent subtours among demand/customer nodes that are disconnected from any depot/base.

Acceptable approaches include MTZ constraints, single-commodity flow constraints, multi-commodity flow constraints, generalized subtour-elimination cuts, or other valid connectivity-enforcing constraints.

### 6.9 Variable-Domain Constraints

Routing decisions must be binary or otherwise restricted so that selected arcs/routes are unambiguous. Auxiliary variables should have appropriate domains, such as nonnegative continuous, integer, or order-domain restrictions, depending on their modeling role.

## 7. Evaluation Notes

When evaluating an LLM-generated model, do not require exact symbol matching. The assessment should focus on whether the model contains the correct MDVRP structure and whether the elements work together consistently.

A model element should be marked correct when:

- It has the same mathematical role as the standard element.
- It enforces the same feasibility requirement.
- It does not introduce contradictions with other parts of the model.
- It can be used to construct feasible route-level solutions.

A model element should be marked incorrect when:

- It omits a necessary MDVRP requirement.
- It changes the problem into a different VRP variant without justification.
- It allows infeasible routes, such as unserved customers, repeated service, capacity violation, excessive route duration, disconnected subtours, or vehicles returning to a different depot/base.
- It defines variables or parameters that are inconsistent with the objective function or constraints.

