# 4.1.4 File Manifest

This folder contains the certified evidence package for Section 4.1.4.

## Folder layout

- `code_used/`: scripts used to build and certify the five-algorithm experiment.
- `code_used/algorithm_assets/`: the five fixed algorithm assets.
- `benchmark_data/`: Cordeau MDVRP instances and BKS `.res` files used by the certification runner.
- `source_results_used/`: source result folders used in the final merge.
- `final_merged_results/`: final merged tables for paper analysis.

## Final source result folders

- `certified_5_algorithm_full33_gurobi_v3`
- `certified_5_algorithm_full33_non_gurobi`
- `certified_5_algorithm_full33_turbo_alns_swap_local_search_120s`

Historical Turbo ALNS records from `certified_5_algorithm_full33_non_gurobi` are excluded from the final merge and replaced by `certified_5_algorithm_full33_turbo_alns_swap_local_search_120s`.

## Main final tables

- `final_merged_results/combined_certified_solution_results.csv`
- `final_merged_results/combined_algorithm_statistics.csv`
- `final_merged_results/best_certified_by_instance.csv`
- `final_merged_results/per_instance_certification_matrix.csv`
- `final_merged_results/certified_scope_statistics.csv`
- `final_merged_results/p_series_turbo_alns_detail.csv`
- `final_merged_results/combined_uncertified_or_rejected_results.csv`
- `final_merged_results/rejection_category_summary.csv`

All final Gap values are computed after independent route-level validation.