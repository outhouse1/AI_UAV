# Certified 5-Algorithm MDVRP Experiment

## Configuration

- historical_root: packaged five-algorithm benchmark data
- data_dir: `benchmark_data/C-mdvrp`
- bks_dir: `benchmark_data/C-mdvrp-sol`
- output_root: `certified_5_algorithm_full33_non_gurobi`
- instances: `p01,p02,p03,p04,p05,p06,p07,p08,p09,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23,pr01,pr02,pr03,pr04,pr05,pr06,pr07,pr08,pr09,pr10`
- algorithms: `alns,constructive_sa,deep_alns,turbo_alns`
- time_limit: `60.0`
- deep_max_iters: `5000`
- turbo_max_iters: `5000`

## Original Summary Screening

| Algorithm | Summary records | Successful summaries | Invalid/sentinel | Below-BKS flags | Mean Gap* | Median Gap* |
|---|---:|---:|---:|---:|---:|---:|
| gurobi_model | 33 | 9 | 24 | 0 | 73.4686 | 13.3364 |
| alns | 33 | 33 | 0 | 0 | 5.9348 | 4.5974 |
| constructive_sa | 33 | 33 | 0 | 0 | 47.3915 | 48.1206 |
| deep_alns | 33 | 33 | 0 | 1 | 1.2319 | 0.9737 |
| turbo_alns | 33 | 33 | 0 | 9 | 1.8844 | 1.8295 |

*Original summary Gap values are screening values only. Certified statistics below are based on route-level validation.

## Route-Level Certified Statistics

| Algorithm | Audit records | Rerun success | Certified | Certified rate | Negative certified Gap | Mean certified Gap | Median certified Gap | Mean elapsed seconds |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| alns | 33 | 33 | 11 | 33.33% | 0 | 3.5846 | 1.5540 | 60.1207 |
| constructive_sa | 33 | 33 | 13 | 39.39% | 0 | 42.1872 | 42.9706 | 0.0665 |
| deep_alns | 33 | 33 | 26 | 78.79% | 0 | 2.7482 | 2.1391 | 1426.5400 |
| turbo_alns | 33 | 33 | 26 | 78.79% | 0 | 8.6158 | 5.9677 | 7.7230 |

Certified results are accepted only after independent customer-coverage, duplicate-service, vehicle-count, capacity, route-duration, route-distance, and objective-consistency checks.
