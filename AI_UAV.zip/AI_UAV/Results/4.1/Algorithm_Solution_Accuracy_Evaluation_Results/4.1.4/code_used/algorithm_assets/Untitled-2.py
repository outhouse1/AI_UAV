# 启发式进阶版-1-启发式算法 ALNS-MDVRP  自适应大邻域搜索 (Adaptive Large Neighborhood Search, ALNS)。

#核心策略
# Destroy 算子：随机移除、最差移除（移除成本最高的点）、肖氏移除（Shaw Removal，移除相似度高的点，关键）。

# Repair 算子：贪婪插入、后悔插入 (Regret-2, Regret-3)（关键，防止把难点留到最后）。

# 接受准则：模拟退火 (Simulated Annealing)。

import os
import time
import math
import json
import random
import copy
import traceback
import warnings
from datetime import datetime
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# ==========================================
# 1. 配置与兼容性
# ==========================================
warnings.filterwarnings("ignore")
try:
    matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
except:
    pass

def get_safe_cmap(name='tab20'):
    try:
        return matplotlib.colormaps[name]
    except AttributeError:
        return plt.cm.get_cmap(name)

# ==========================================
# 2. 数据结构
# ==========================================

class MDVRPInstance:
    def __init__(self, path):
        self.path = path
        self.filename = os.path.basename(path)
        self.m = 0; self.n = 0; self.d = 0
        self.D = 0; self.Q = 0
        self.depot_D = []
        self.depot_Q = []
        self.nodes = [] 
        self.dist_matrix = None

    def load(self):
        with open(self.path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        
        parts = lines[0].split()
        self.m = int(parts[1]); self.n = int(parts[2]); self.d = int(parts[3])
        self.depot_D = []
        self.depot_Q = []
        for line_idx in range(1, 1 + self.d):
            parts = lines[line_idx].split()
            self.depot_D.append(float(parts[0]))
            self.depot_Q.append(float(parts[1]))
        self.D = self.depot_D[0]
        self.Q = self.depot_Q[0]
        
        self.nodes = []
        start_idx = 1 + self.d
        count = 0
        total_nodes = self.n + self.d
        
        for i in range(start_idx, len(lines)):
            if count >= total_nodes: break
            p = lines[i].split()
            self.nodes.append({
                'id': int(p[0]), 'x': float(p[1]), 'y': float(p[2]),
                'service': float(p[3]), 'demand': float(p[4]),
                'is_depot': (count >= self.n), 'idx': count
            })
            count += 1
            
        self._calc_dist_matrix()

    def depot_index(self, depot_node_idx):
        return int(depot_node_idx) - self.n

    def depot_capacity(self, depot_node_idx):
        idx = self.depot_index(depot_node_idx)
        return self.depot_Q[idx]

    def depot_duration(self, depot_node_idx):
        idx = self.depot_index(depot_node_idx)
        return self.depot_D[idx]

    def _calc_dist_matrix(self):
        size = len(self.nodes)
        self.dist_matrix = np.zeros((size, size))
        for i in range(size):
            for j in range(size):
                if i != j:
                    d = math.sqrt((self.nodes[i]['x']-self.nodes[j]['x'])**2 + 
                                  (self.nodes[i]['y']-self.nodes[j]['y'])**2)
                    self.dist_matrix[i][j] = d

class Solution:
    def __init__(self, instance):
        self.inst = instance
        # routes[depot_idx] = [ [node_idx, ...], [node_idx, ...] ]
        self.routes = {d: [] for d in range(instance.n, instance.n + instance.d)}
        self.cost = 0.0
        self.unassigned = []

    def copy(self):
        new_sol = Solution(self.inst)
        new_sol.routes = copy.deepcopy(self.routes)
        new_sol.cost = self.cost
        new_sol.unassigned = list(self.unassigned)
        return new_sol

    def evaluate(self):
        """计算总成本，含惩罚项"""
        total_dist = 0
        penalty = 0
        
        for d_idx, d_routes in self.routes.items():
            for r in d_routes:
                if not r: continue
                
                load = 0
                dur = 0
                dist = 0
                curr = d_idx
                
                for node_idx in r:
                    d = self.inst.dist_matrix[curr][node_idx]
                    dist += d
                    dur += d + self.inst.nodes[node_idx]['service']
                    load += self.inst.nodes[node_idx]['demand']
                    curr = node_idx
                
                # 回程
                d_back = self.inst.dist_matrix[curr][d_idx]
                dist += d_back
                dur += d_back
                
                total_dist += dist
                
                # 软约束惩罚 (为了让搜索穿过不可行区域到达更好解)
                cap = self.inst.depot_capacity(d_idx)
                max_dur = self.inst.depot_duration(d_idx)
                if load > cap:
                    penalty += (load - cap) * 1000
                if max_dur > 0 and dur > max_dur:
                    penalty += (dur - max_dur) * 1000
            if len(d_routes) > self.inst.m:
                penalty += (len(d_routes) - self.inst.m) * 100000
        
        # 未分配惩罚
        penalty += len(self.unassigned) * 100000
        self.cost = total_dist + penalty
        return total_dist, penalty == 0 and len(self.unassigned) == 0

# ==========================================
# 3. ALNS 核心逻辑
# ==========================================

class ALNSSolver:
    def __init__(self, instance, seed=42):
        self.inst = instance
        random.seed(seed)
        np.random.seed(seed)
        
        # 参数配置
        self.sigma = [33, 9, 13] # 得分: [新最优, 更好, 接受]
        self.reaction_factor = 0.1
        self.min_remove = 1
        self.max_remove = min(40, int(instance.n * 0.4))
        
        # 算子集合
        self.destroy_ops = [self.random_removal, self.worst_removal, self.shaw_removal]
        self.repair_ops = [self.greedy_insertion, self.regret_2_insertion]
        
        # 权重
        self.d_weights = [1.0] * len(self.destroy_ops)
        self.r_weights = [1.0] * len(self.repair_ops)
        self.d_scores = [0.0] * len(self.destroy_ops)
        self.r_scores = [0.0] * len(self.repair_ops)
        self.d_counts = [0] * len(self.destroy_ops)
        self.r_counts = [0] * len(self.repair_ops)

    # --- 辅助函数 ---
    def check_insertion(self, route, node_idx, depot_idx, pos):
        """快速检查插入成本和可行性"""
        # 成本增量 = d(prev, node) + d(node, next) - d(prev, next)
        prev_node = depot_idx if pos == 0 else route[pos-1]
        next_node = depot_idx if pos == len(route) else route[pos]
        
        delta_dist = (self.inst.dist_matrix[prev_node][node_idx] + 
                      self.inst.dist_matrix[node_idx][next_node] - 
                      self.inst.dist_matrix[prev_node][next_node])
        
        # 检查约束
        node_dem = self.inst.nodes[node_idx]['demand']
        node_serv = self.inst.nodes[node_idx]['service']
        
        # 计算当前路线状态
        curr_load = sum(self.inst.nodes[n]['demand'] for n in route)
        
        if curr_load + node_dem > self.inst.depot_capacity(depot_idx):
            return float('inf'), False # 容量超标
            
        max_dur = self.inst.depot_duration(depot_idx)
        if max_dur > 0:
            # 简化的时长检查 (不完全准确但快速)
            # 完整检查需要遍历，太慢。这里假设仅增加 delta_dist + service
            curr_dur = 0 # 需要预存路线时长才能O(1)，这里为准确性做O(N)计算
            c = depot_idx
            for n in route:
                curr_dur += self.inst.dist_matrix[c][n] + self.inst.nodes[n]['service']
                c = n
            curr_dur += self.inst.dist_matrix[c][depot_idx]
            
            if curr_dur + delta_dist + node_serv > max_dur:
                return float('inf'), False

        return delta_dist, True

    # --- Destroy Operators ---
    
    def random_removal(self, sol, q):
        """随机移除 q 个点"""
        flattened = []
        for d, routes in sol.routes.items():
            for r_idx, r in enumerate(routes):
                for n in r:
                    flattened.append((d, r_idx, n))
        
        if not flattened: return sol
        
        removed = random.sample(flattened, min(q, len(flattened)))
        
        # 执行移除
        removed_nodes = []
        for d, r_idx, n in removed:
            sol.routes[d][r_idx].remove(n)
            removed_nodes.append(n)
        
        # 清理空路线
        for d in sol.routes:
            sol.routes[d] = [r for r in sol.routes[d] if r]
            
        sol.unassigned.extend(removed_nodes)
        return sol

    def worst_removal(self, sol, q):
        """移除成本增量最大的点"""
        costs = []
        for d, routes in sol.routes.items():
            for r_idx, r in enumerate(routes):
                for pos, n in enumerate(r):
                    prev_n = d if pos==0 else r[pos-1]
                    next_n = d if pos==len(r)-1 else r[pos+1]
                    # 省下的距离
                    saving = (self.inst.dist_matrix[prev_n][n] + 
                              self.inst.dist_matrix[n][next_n] - 
                              self.inst.dist_matrix[prev_n][next_n])
                    costs.append( (saving, d, r_idx, n) )
        
        # 排序，取最大的 q 个 (引入随机性)
        costs.sort(key=lambda x: x[0], reverse=True)
        
        removed_nodes = []
        # 随机选择 Top-L
        for _ in range(min(q, len(costs))):
            idx = int(random.random()**3 * len(costs)) # 偏向于前面
            if idx >= len(costs): idx = len(costs) - 1
            item = costs.pop(idx)
            
            # 从路线中删除 (注意：多次删除会改变索引，这里直接操作对象引用)
            d, r_idx, n = item[1], item[2], item[3]
            if n in sol.routes[d][r_idx]:
                sol.routes[d][r_idx].remove(n)
                removed_nodes.append(n)
        
        for d in sol.routes:
            sol.routes[d] = [r for r in sol.routes[d] if r]
            
        sol.unassigned.extend(removed_nodes)
        return sol

    def shaw_removal(self, sol, q):
        """Shaw Removal: 移除相似度高的点 (基于距离和需求)"""
        # 随机选一个种子点
        all_nodes = []
        for d, routes in sol.routes.items():
            for r in routes:
                all_nodes.extend(r)
        
        if not all_nodes: return self.random_removal(sol, q)
        
        seed = random.choice(all_nodes)
        removed = [seed]
        
        # 从sol中移除种子
        for d, routes in sol.routes.items():
            for r in routes:
                if seed in r: r.remove(seed)
        
        # 循环移除最相似的点
        while len(removed) < q and len(all_nodes) > len(removed):
            ref = random.choice(removed)
            # 计算相关性 R = dist + |demand_diff|
            relatedness = []
            
            # 需要遍历当前解中剩余的所有点
            current_nodes_info = []
            for d, routes in sol.routes.items():
                for r_idx, r in enumerate(routes):
                    for n in r:
                        dist = self.inst.dist_matrix[ref][n]
                        dem_diff = abs(self.inst.nodes[ref]['demand'] - self.inst.nodes[n]['demand'])
                        # R值越小越相关
                        R = dist + dem_diff 
                        current_nodes_info.append( (R, d, r_idx, n) )
            
            if not current_nodes_info: break
            
            current_nodes_info.sort(key=lambda x: x[0])
            
            idx = int(random.random()**4 * len(current_nodes_info))
            item = current_nodes_info[idx]
            n_remove = item[3]
            
            sol.routes[item[1]][item[2]].remove(n_remove)
            removed.append(n_remove)
        
        for d in sol.routes:
            sol.routes[d] = [r for r in sol.routes[d] if r]
            
        sol.unassigned.extend(removed)
        return sol

    # --- Repair Operators ---

    def greedy_insertion(self, sol):
        """贪婪插入：每次把最便宜的点插进去"""
        random.shuffle(sol.unassigned) # 随机打乱顺序
        
        while sol.unassigned:
            node = sol.unassigned.pop(0)
            best_cost = float('inf')
            best_pos = None # (depot, route_idx, insert_idx)
            
            # 遍历所有车场、所有路线、所有位置
            for d in sol.routes:
                # 尝试插入现有路线
                for r_idx, r in enumerate(sol.routes[d]):
                    for pos in range(len(r) + 1):
                        cost, feasible = self.check_insertion(r, node, d, pos)
                        if feasible and cost < best_cost:
                            best_cost = cost
                            best_pos = (d, r_idx, pos)
                
                # 尝试开启新路线
                cost, feasible = self.check_insertion([], node, d, 0)
                if feasible and len(sol.routes[d]) < self.inst.m and cost < best_cost:
                    best_cost = cost
                    best_pos = (d, -1, 0)
            
            if best_pos:
                d, r_idx, pos = best_pos
                if r_idx == -1:
                    sol.routes[d].append([node])
                else:
                    sol.routes[d][r_idx].insert(pos, node)
            else:
                # 无法插入 (极少数情况，放入惩罚池)
                # 实际上应该有惩罚，这里为了简化暂不处理
                pass 
                
        return sol

    def regret_2_insertion(self, sol):
        """Regret-2 插入：优先插入那些'如果不现在插，下次插就很贵'的点"""
        while sol.unassigned:
            # 计算每个未分配点的最佳和次佳插入位置
            regrets = []
            
            for node in sol.unassigned:
                insertion_costs = []
                
                for d in sol.routes:
                    # 现有路线
                    for r_idx, r in enumerate(sol.routes[d]):
                        for pos in range(len(r) + 1):
                            cost, feasible = self.check_insertion(r, node, d, pos)
                            if feasible:
                                insertion_costs.append( (cost, d, r_idx, pos) )
                    # 新路线
                    cost, feasible = self.check_insertion([], node, d, 0)
                    if feasible and len(sol.routes[d]) < self.inst.m:
                        insertion_costs.append( (cost, d, -1, 0) )
                
                insertion_costs.sort(key=lambda x: x[0])
                
                if not insertion_costs:
                    regrets.append( (-1, node, None) ) # 无法插入
                elif len(insertion_costs) == 1:
                    # 只有一个位置能插，后悔值无穷大 (必须优先)
                    regrets.append( (float('inf'), node, insertion_costs[0]) )
                else:
                    # 后悔值 = 次佳 - 最佳
                    regret_val = insertion_costs[1][0] - insertion_costs[0][0]
                    regrets.append( (regret_val, node, insertion_costs[0]) )
            
            # 选择后悔值最大的点
            regrets.sort(key=lambda x: x[0], reverse=True)
            
            best_regret = regrets[0]
            node = best_regret[1]
            move = best_regret[2]
            
            sol.unassigned.remove(node)
            
            if move:
                d, r_idx, pos = move[1], move[2], move[3]
                if r_idx == -1:
                    sol.routes[d].append([node])
                else:
                    sol.routes[d][r_idx].insert(pos, node)
            else:
                pass # 无法插入
        return sol

    # --- Main Loop ---
    
    def initial_solution(self):
        """生成初始解：聚类 + 简单贪婪"""
        sol = Solution(self.inst)
        # 1. 最近车场聚类
        clusters = {d: [] for d in sol.routes}
        for i in range(self.inst.n):
            best_d = -1
            min_dist = float('inf')
            for d in clusters:
                dist = self.inst.dist_matrix[i][d]
                if dist < min_dist:
                    min_dist = dist
                    best_d = d
            clusters[best_d].append(i)
        
        # 2. 简单插入
        failed_nodes = []
        for d, nodes in clusters.items():
            sol.unassigned = nodes
            # 临时借用greedy insertion
            # 为了能在initial阶段只对特定depot操作，这里手动简单写
            while sol.unassigned:
                n = sol.unassigned.pop(0)
                added = False
                for r in sol.routes[d]:
                    c, f = self.check_insertion(r, n, d, len(r))
                    if f:
                        r.append(n)
                        added = True
                        break
                if not added:
                    if len(sol.routes[d]) < self.inst.m:
                        sol.routes[d].append([n])
                    else:
                        failed_nodes.append(n)
        
        sol.unassigned = failed_nodes
        sol.evaluate()
        return sol

    def select_operator(self, weights):
        total = sum(weights)
        if total == 0: return random.randint(0, len(weights)-1)
        probs = [w/total for w in weights]
        return np.random.choice(len(weights), p=probs)

    def solve(self, time_limit=60):
        start_time = time.time()
        
        # 1. 初始解
        curr_sol = self.initial_solution()
        best_sol = curr_sol.copy()
        best_feasible_dist = float('inf')
        
        # 如果初始解可行
        dist, feasible = curr_sol.evaluate()
        if feasible: best_feasible_dist = dist
        
        # SA 参数
        T = dist * 0.05
        alpha = 0.995
        
        iter_count = 0
        
        print(f"  > ALNS Start: Initial Cost {dist:.2f}, Time Limit {time_limit}s")
        
        while time.time() - start_time < time_limit:
            iter_count += 1
            
            # 选择算子
            d_idx = self.select_operator(self.d_weights)
            r_idx = self.select_operator(self.r_weights)
            
            destroy = self.destroy_ops[d_idx]
            repair = self.repair_ops[r_idx]
            
            # 复制解
            temp_sol = curr_sol.copy()
            
            # 确定移除数量 (随机)
            q = random.randint(self.min_remove, self.max_remove)
            
            # 执行 Destroy-Repair
            temp_sol = destroy(temp_sol, q)
            temp_sol = repair(temp_sol)
            
            # 评估
            cost, is_feasible = temp_sol.evaluate()
            
            # 接受准则 (SA)
            delta = cost - curr_sol.cost
            accepted = False
            score = 0
            
            if delta < 0:
                accepted = True
                if cost < best_sol.cost:
                    # 发现全局新最优 (包含不可行解的最优)
                    best_sol = temp_sol.copy()
                    score = self.sigma[0]
                    if is_feasible and cost < best_feasible_dist:
                        best_feasible_dist = cost
                else:
                    score = self.sigma[1]
            elif random.random() < math.exp(-delta / T):
                accepted = True
                score = self.sigma[2]
            
            if accepted:
                curr_sol = temp_sol
                
            # 更新权重统计
            self.d_scores[d_idx] += score
            self.r_scores[r_idx] += score
            self.d_counts[d_idx] += 1
            self.r_counts[r_idx] += 1
            
            # 温度衰减
            T *= alpha
            
            # 定期更新权重 (每100次)
            if iter_count % 100 == 0:
                for i in range(len(self.d_weights)):
                    if self.d_counts[i] > 0:
                        self.d_weights[i] = self.d_weights[i]*(1-self.reaction_factor) + \
                                            self.reaction_factor*(self.d_scores[i]/self.d_counts[i])
                        self.d_scores[i] = 0; self.d_counts[i] = 0
                for i in range(len(self.r_weights)):
                    if self.r_counts[i] > 0:
                        self.r_weights[i] = self.r_weights[i]*(1-self.reaction_factor) + \
                                            self.reaction_factor*(self.r_scores[i]/self.r_counts[i])
                        self.r_scores[i] = 0; self.r_counts[i] = 0

        # 返回找到的最好的可行解
        final_dist, final_feas = best_sol.evaluate()
        
        # 整理输出格式
        routes_export = []
        veh_count = 0
        for d, routes in best_sol.routes.items():
            for r in routes:
                if r:
                    d_cost = 0 # 简单计算距离
                    curr = d
                    for n in r:
                        d_cost += self.inst.dist_matrix[curr][n]
                        curr = n
                    d_cost += self.inst.dist_matrix[curr][d]
                    
                    routes_export.append({
                        'depot': d,
                        'path': r,
                        'dist': d_cost
                    })
                    veh_count += 1
                    
        return {
            'obj': final_dist if final_feas else -1, # 如果最终都没可行解返回-1
            'gap': 0, # Gap需要对比BKS，这里暂不计算
            'routes': routes_export,
            'vehicles': veh_count,
            'time': time.time() - start_time
        }

    def visualize(self, result, output_path):
        if not result or result['obj'] == -1: return
        
        plt.figure(figsize=(12, 10))
        
        # 画车场
        dx = [self.inst.nodes[i]['x'] for i in range(self.inst.n, self.inst.n + self.inst.d)]
        dy = [self.inst.nodes[i]['y'] for i in range(self.inst.n, self.inst.n + self.inst.d)]
        plt.scatter(dx, dy, c='black', marker='s', s=200, zorder=10, label='车场')
        
        # 画客户
        cx = [self.inst.nodes[i]['x'] for i in range(self.inst.n)]
        cy = [self.inst.nodes[i]['y'] for i in range(self.inst.n)]
        plt.scatter(cx, cy, c='gray', alpha=0.3, s=20, label='客户')
        
        cmap = get_safe_cmap('tab20')
        
        for i, route in enumerate(result['routes']):
            depot = route['depot']
            path = [depot] + route['path'] + [depot]
            px = [self.inst.nodes[idx]['x'] for idx in path]
            py = [self.inst.nodes[idx]['y'] for idx in path]
            
            color = cmap(i % 20)
            plt.plot(px, py, color=color, linewidth=1.5, alpha=0.8)
            
        plt.title(f"ALNS Solution: Dist={result['obj']:.2f}, V={result['vehicles']}")
        plt.legend()
        plt.savefig(output_path)
        plt.close()

# ==========================================
# 4. 批量运行
# ==========================================

def run_meta_heuristic(data_dir):
    if not os.path.exists(data_dir): return
    
    res_dir = os.path.join(os.path.dirname(data_dir), "Certified_Rerun_Results", "ALNS_Results")
    if not os.path.exists(res_dir): os.makedirs(res_dir)
    
    files = sorted([f for f in os.listdir(data_dir) if (f.startswith('p') or f.startswith('pr')) and not f.endswith('.png')])
    
    summary = []
    print(f"=== 启动 MDVRP ALNS 深度优化 (共{len(files)}题) ===")
    
    for f in files:
        path = os.path.join(data_dir, f)
        print(f"\n正在处理: {f}")
        try:
            inst = MDVRPInstance(path)
            inst.load()
            
            # 动态时间: ALNS需要迭代次数，时间不能太短
            # 小算例30s，中算例60s，大算例90s
            limit = 30
            if inst.n > 100: limit = 60
            if inst.n > 250: limit = 120
            
            solver = ALNSSolver(inst)
            res = solver.solve(time_limit=limit)
            
            print(f"  > 最终结果: 距离 {res['obj']:.2f}, 车辆 {res['vehicles']}")
            
            if res['obj'] > 0:
                solver.visualize(res, os.path.join(res_dir, f"{f}_alns.png"))
            
            summary.append({'Instance': f, 'Cost': res['obj'], 'Veh': res['vehicles'], 'Time': res['time']})
            
        except Exception as e:
            print(f"Error: {e}")
            traceback.print_exc()

    # 保存
    with open(os.path.join(res_dir, "ALNS_Summary.txt"), 'w') as f:
        f.write(f"{'Instance':<15} {'Cost':<15} {'Veh':<10} {'Time':<10}\n")
        for s in summary:
            f.write(f"{s['Instance']:<15} {s['Cost']:<15.2f} {s['Veh']:<10} {s['Time']:<10.2f}\n")

if __name__ == "__main__":
    target_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "C-mdvrp")
    run_meta_heuristic(target_dir)
