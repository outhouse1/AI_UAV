# 启发式进阶版-2  元启发式算法 Deep Search ALNS 深度搜索优化 死磕最优
# 耗时大幅增加：每个算例可能需要运行 5分钟 到 30分钟 不等（取决于电脑性能）。
# CPU 满载：这是纯计算密集型任务。

import os
import time
import math
import json
import random
import copy
import traceback
import warnings
from datetime import datetime
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# ==========================================
# 1. 环境配置
# ==========================================
warnings.filterwarnings("ignore")
try:
    matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
except:
    pass

def get_safe_cmap(name='tab20'):
    try:
        return matplotlib.colormaps[name]
    except AttributeError:
        return plt.cm.get_cmap(name)

# ==========================================
# 2. 数据结构
# ==========================================

class MDVRPInstance:
    def __init__(self, path):
        self.path = path
        self.filename = os.path.basename(path)
        self.m = 0; self.n = 0; self.d = 0
        self.D = 0; self.Q = 0
        self.depot_D = []
        self.depot_Q = []
        self.nodes = [] 
        self.dist_matrix = None

    def load(self):
        with open(self.path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        
        parts = lines[0].split()
        self.m = int(parts[1]); self.n = int(parts[2]); self.d = int(parts[3])
        self.depot_D = []
        self.depot_Q = []
        for line_idx in range(1, 1 + self.d):
            parts = lines[line_idx].split()
            self.depot_D.append(float(parts[0]))
            self.depot_Q.append(float(parts[1]))
        self.D = self.depot_D[0]
        self.Q = self.depot_Q[0]
        
        self.nodes = []
        start_idx = 1 + self.d
        count = 0
        total_nodes = self.n + self.d
        
        for i in range(start_idx, len(lines)):
            if count >= total_nodes: break
            p = lines[i].split()
            self.nodes.append({
                'id': int(p[0]), 'x': float(p[1]), 'y': float(p[2]),
                'service': float(p[3]), 'demand': float(p[4]),
                'is_depot': (count >= self.n), 'idx': count
            })
            count += 1
        self._calc_dist_matrix()

    def depot_index(self, depot_node_idx):
        return int(depot_node_idx) - self.n

    def depot_capacity(self, depot_node_idx):
        return self.depot_Q[self.depot_index(depot_node_idx)]

    def depot_duration(self, depot_node_idx):
        return self.depot_D[self.depot_index(depot_node_idx)]

    def _calc_dist_matrix(self):
        size = len(self.nodes)
        self.dist_matrix = np.zeros((size, size))
        for i in range(size):
            for j in range(size):
                if i != j:
                    d = math.sqrt((self.nodes[i]['x']-self.nodes[j]['x'])**2 + 
                                  (self.nodes[i]['y']-self.nodes[j]['y'])**2)
                    self.dist_matrix[i][j] = d

class Solution:
    def __init__(self, instance):
        self.inst = instance
        self.routes = {d: [] for d in range(instance.n, instance.n + instance.d)}
        self.cost = 0.0
        self.unassigned = []

    def copy(self):
        new_sol = Solution(self.inst)
        new_sol.routes = copy.deepcopy(self.routes)
        new_sol.cost = self.cost
        new_sol.unassigned = list(self.unassigned)
        return new_sol

    def evaluate(self):
        total_dist = 0
        penalty = 0
        
        for d_idx, d_routes in self.routes.items():
            for r in d_routes:
                if not r: continue
                load = 0; dur = 0; dist = 0; curr = d_idx
                for node_idx in r:
                    d = self.inst.dist_matrix[curr][node_idx]
                    dist += d
                    dur += d + self.inst.nodes[node_idx]['service']
                    load += self.inst.nodes[node_idx]['demand']
                    curr = node_idx
                
                d_back = self.inst.dist_matrix[curr][d_idx]
                dist += d_back
                dur += d_back
                total_dist += dist
                
                # 强惩罚，迫使算法寻找可行解
                cap = self.inst.depot_capacity(d_idx)
                max_dur = self.inst.depot_duration(d_idx)
                if load > cap: penalty += (load - cap) * 5000
                if max_dur > 0 and dur > max_dur: penalty += (dur - max_dur) * 5000
            if len(d_routes) > self.inst.m:
                penalty += (len(d_routes) - self.inst.m) * 1000000
        
        penalty += len(self.unassigned) * 1000000
        self.cost = total_dist + penalty
        return total_dist, penalty == 0 and len(self.unassigned) == 0

# ==========================================
# 3. ALNS 深度搜索核心 (BKS Mode)
# ==========================================

class ALNSSolverDeep:
    def __init__(self, instance, seed=42):
        self.inst = instance
        random.seed(seed)
        np.random.seed(seed)
        
        # 深度搜索参数
        self.sigma = [50, 20, 5] # 加大奖励，鼓励创新
        self.reaction_factor = 0.05 # 降低反应速度，使学习更平滑
        self.min_remove = 1
        # 加大破坏力度，最大破坏45%的点
        self.max_remove = min(60, int(instance.n * 0.45)) 
        
        self.destroy_ops = [self.random_removal, self.worst_removal, self.shaw_removal]
        self.repair_ops = [self.greedy_insertion, self.regret_2_insertion, self.regret_3_insertion]
        
        self.d_weights = [1.0] * len(self.destroy_ops)
        self.r_weights = [1.0] * len(self.repair_ops)
        self.d_scores = [0.0] * len(self.destroy_ops)
        self.r_scores = [0.0] * len(self.repair_ops)
        self.d_counts = [0] * len(self.destroy_ops)
        self.r_counts = [0] * len(self.repair_ops)

    def check_insertion(self, route, node_idx, depot_idx, pos):
        prev_node = depot_idx if pos == 0 else route[pos-1]
        next_node = depot_idx if pos == len(route) else route[pos]
        
        delta_dist = (self.inst.dist_matrix[prev_node][node_idx] + 
                      self.inst.dist_matrix[node_idx][next_node] - 
                      self.inst.dist_matrix[prev_node][next_node])
        
        node_dem = self.inst.nodes[node_idx]['demand']
        curr_load = sum(self.inst.nodes[n]['demand'] for n in route)
        
        if curr_load + node_dem > self.inst.depot_capacity(depot_idx): return float('inf'), False
            
        max_dur = self.inst.depot_duration(depot_idx)
        if max_dur > 0:
            # 简化时长检查
            curr_dur = 0
            c = depot_idx
            for n in route:
                curr_dur += self.inst.dist_matrix[c][n] + self.inst.nodes[n]['service']
                c = n
            curr_dur += self.inst.dist_matrix[c][depot_idx]
            
            node_serv = self.inst.nodes[node_idx]['service']
            if curr_dur + delta_dist + node_serv > max_dur: return float('inf'), False

        return delta_dist, True

    # --- Operators ---
    def random_removal(self, sol, q):
        flattened = [(d, r_idx, n) for d, rs in sol.routes.items() for r_idx, r in enumerate(rs) for n in r]
        if not flattened: return sol
        removed = random.sample(flattened, min(q, len(flattened)))
        removed_nodes = []
        for d, r_idx, n in removed:
            sol.routes[d][r_idx].remove(n)
            removed_nodes.append(n)
        for d in sol.routes: sol.routes[d] = [r for r in sol.routes[d] if r]
        sol.unassigned.extend(removed_nodes)
        return sol

    def worst_removal(self, sol, q):
        costs = []
        for d, rs in sol.routes.items():
            for r_idx, r in enumerate(rs):
                for pos, n in enumerate(r):
                    prev_n = d if pos==0 else r[pos-1]
                    next_n = d if pos==len(r)-1 else r[pos+1]
                    saving = (self.inst.dist_matrix[prev_n][n] + self.inst.dist_matrix[n][next_n] - self.inst.dist_matrix[prev_n][next_n])
                    costs.append( (saving, d, r_idx, n) )
        costs.sort(key=lambda x: x[0], reverse=True)
        removed_nodes = []
        # 引入随机性避免陷入循环
        for _ in range(min(q, len(costs))):
            idx = int(random.random()**5 * len(costs)) 
            if idx >= len(costs): idx = len(costs)-1
            item = costs.pop(idx)
            if item[3] in sol.routes[item[1]][item[2]]:
                sol.routes[item[1]][item[2]].remove(item[3])
                removed_nodes.append(item[3])
        for d in sol.routes: sol.routes[d] = [r for r in sol.routes[d] if r]
        sol.unassigned.extend(removed_nodes)
        return sol

    def shaw_removal(self, sol, q):
        all_nodes = [n for rs in sol.routes.values() for r in rs for n in r]
        if not all_nodes: return self.random_removal(sol, q)
        seed = random.choice(all_nodes)
        removed = [seed]
        for d, rs in sol.routes.items():
            for r in rs:
                if seed in r: r.remove(seed)
        
        while len(removed) < q and len(all_nodes) > len(removed):
            ref = random.choice(removed)
            candidates = []
            for d, rs in sol.routes.items():
                for r_idx, r in enumerate(rs):
                    for n in r:
                        dist = self.inst.dist_matrix[ref][n]
                        dem_diff = abs(self.inst.nodes[ref]['demand'] - self.inst.nodes[n]['demand'])
                        candidates.append((dist + dem_diff, d, r_idx, n))
            if not candidates: break
            candidates.sort(key=lambda x: x[0])
            idx = int(random.random()**5 * len(candidates))
            item = candidates[idx]
            sol.routes[item[1]][item[2]].remove(item[3])
            removed.append(item[3])
            
        for d in sol.routes: sol.routes[d] = [r for r in sol.routes[d] if r]
        sol.unassigned.extend(removed)
        return sol

    def greedy_insertion(self, sol):
        random.shuffle(sol.unassigned)
        failed_nodes = []
        while sol.unassigned:
            node = sol.unassigned.pop(0)
            best_cost = float('inf'); best_pos = None
            for d in sol.routes:
                for r_idx, r in enumerate(sol.routes[d]):
                    for pos in range(len(r)+1):
                        cost, feas = self.check_insertion(r, node, d, pos)
                        if feas and cost < best_cost:
                            best_cost = cost; best_pos = (d, r_idx, pos)
                cost, feas = self.check_insertion([], node, d, 0)
                if feas and len(sol.routes[d]) < self.inst.m and cost < best_cost:
                    best_cost = cost; best_pos = (d, -1, 0)
            if best_pos:
                d, r_idx, pos = best_pos
                if r_idx == -1: sol.routes[d].append([node])
                else: sol.routes[d][r_idx].insert(pos, node)
            else:
                failed_nodes.append(node)
        sol.unassigned.extend(failed_nodes)
        return sol

    def regret_n_insertion(self, sol, n_depth):
        while sol.unassigned:
            regrets = []
            for node in sol.unassigned:
                costs = []
                for d in sol.routes:
                    for r_idx, r in enumerate(sol.routes[d]):
                        for pos in range(len(r)+1):
                            c, f = self.check_insertion(r, node, d, pos)
                            if f: costs.append((c, d, r_idx, pos))
                    c, f = self.check_insertion([], node, d, 0)
                    if f and len(sol.routes[d]) < self.inst.m: costs.append((c, d, -1, 0))
                
                costs.sort(key=lambda x: x[0])
                if not costs:
                    regrets.append((-1, node, None))
                elif len(costs) < n_depth:
                    regrets.append((float('inf'), node, costs[0]))
                else:
                    regret_val = sum(costs[i][0] - costs[0][0] for i in range(1, n_depth))
                    regrets.append((regret_val, node, costs[0]))
            
            regrets.sort(key=lambda x: x[0], reverse=True)
            if not regrets: break
            best = regrets[0]
            node = best[1]
            move = best[2]
            sol.unassigned.remove(node)
            if move:
                d, r_idx, pos = move[1], move[2], move[3]
                if r_idx == -1: sol.routes[d].append([node])
                else: sol.routes[d][r_idx].insert(pos, node)
            else:
                sol.unassigned.append(node)
                break
        return sol

    def regret_2_insertion(self, sol): return self.regret_n_insertion(sol, 2)
    def regret_3_insertion(self, sol): return self.regret_n_insertion(sol, 3)

    # --- Main Solve ---
    def solve_deep_search(self, max_iters=20000, max_stagnation=3000):
        """
        深度搜索模式：
        不限制时间，只限制迭代次数和停滞次数
        """
        start_time = time.time()
        
        # 1. 初始解
        curr_sol = Solution(self.inst)
        # 初始聚类 + 贪婪
        clusters = {d: [] for d in curr_sol.routes}
        for i in range(self.inst.n):
            bd = -1; md = float('inf')
            for d in clusters:
                dist = self.inst.dist_matrix[i][d]
                if dist < md: md = dist; bd = d
            clusters[bd].append(i)
        for d, ns in clusters.items():
            curr_sol.unassigned = ns
            curr_sol = self.greedy_insertion(curr_sol)
        
        curr_sol.evaluate()
        best_sol = curr_sol.copy()
        best_feasible_obj = float('inf')
        
        obj, feas = curr_sol.evaluate()
        if feas: best_feasible_obj = obj
        
        # 极慢的降温参数，允许长时间探索
        T = obj * 0.05
        alpha = 0.9995 
        
        print(f"  > 初始解: {obj:.2f} (Feasible: {feas})")
        print(f"  > 开启深度搜索: 最大迭代 {max_iters}, 停滞阈值 {max_stagnation}")
        
        stagnation_counter = 0
        
        for it in range(max_iters):
            # 提前收敛检查
            if stagnation_counter >= max_stagnation:
                print(f"  > 连续 {max_stagnation} 次迭代无改进，提前收敛。")
                break
                
            d_idx = self._roulette_select(self.d_weights)
            r_idx = self._roulette_select(self.r_weights)
            
            temp_sol = curr_sol.copy()
            q = random.randint(self.min_remove, self.max_remove)
            
            temp_sol = self.destroy_ops[d_idx](temp_sol, q)
            temp_sol = self.repair_ops[r_idx](temp_sol)
            
            obj, is_feas = temp_sol.evaluate()
            
            # SA 接受准则
            delta = obj - curr_sol.cost
            score = 0
            
            accepted = False
            if delta < 0:
                accepted = True
                if obj < best_sol.cost:
                    best_sol = temp_sol.copy()
                    stagnation_counter = 0 # 重置停滞计数
                    score = self.sigma[0]
                    if is_feas and obj < best_feasible_obj:
                        best_feasible_obj = obj
                        # 实时打印突破
                        print(f"    [Iter {it}] 新最优: {obj:.2f}")
                else:
                    stagnation_counter += 1
                    score = self.sigma[1]
            elif random.random() < math.exp(-delta / max(T, 1e-5)):
                accepted = True
                stagnation_counter += 1
                score = self.sigma[2]
            else:
                stagnation_counter += 1
            
            if accepted: curr_sol = temp_sol
            
            # 更新权重
            self.d_scores[d_idx] += score
            self.r_scores[r_idx] += score
            self.d_counts[d_idx] += 1
            self.r_counts[r_idx] += 1
            
            T *= alpha
            
            # 周期性更新权重
            if it % 200 == 0:
                self._update_weights()
                
        # 导出结果
        final_dist, final_feas = best_sol.evaluate()
        routes_export = []
        veh = 0
        for d, rs in best_sol.routes.items():
            for r in rs:
                if r:
                    routes_export.append({'depot': d, 'path': r})
                    veh += 1
        return {
            'obj': final_dist if final_feas else -1,
            'vehicles': veh,
            'routes': routes_export,
            'time': time.time() - start_time,
            'iters': it
        }

    def _roulette_select(self, weights):
        s = sum(weights)
        if s == 0: return random.randint(0, len(weights)-1)
        r = random.uniform(0, s)
        acc = 0
        for i, w in enumerate(weights):
            acc += w
            if r <= acc: return i
        return len(weights)-1

    def _update_weights(self):
        for i in range(len(self.d_weights)):
            if self.d_counts[i] > 0:
                self.d_weights[i] = self.d_weights[i]*(1-self.reaction_factor) + self.reaction_factor*(self.d_scores[i]/self.d_counts[i])
                self.d_scores[i]=0; self.d_counts[i]=0
        for i in range(len(self.r_weights)):
            if self.r_counts[i] > 0:
                self.r_weights[i] = self.r_weights[i]*(1-self.reaction_factor) + self.reaction_factor*(self.r_scores[i]/self.r_counts[i])
                self.r_scores[i]=0; self.r_counts[i]=0
    
    def visualize(self, result, output_path):
        if not result or result['obj'] == -1: return
        plt.figure(figsize=(12, 10))
        dx = [self.inst.nodes[i]['x'] for i in range(self.inst.n, self.inst.n + self.inst.d)]
        dy = [self.inst.nodes[i]['y'] for i in range(self.inst.n, self.inst.n + self.inst.d)]
        plt.scatter(dx, dy, c='black', marker='s', s=200, zorder=10)
        cx = [self.inst.nodes[i]['x'] for i in range(self.inst.n)]
        cy = [self.inst.nodes[i]['y'] for i in range(self.inst.n)]
        plt.scatter(cx, cy, c='gray', alpha=0.3, s=20)
        cmap = get_safe_cmap('tab20')
        for i, route in enumerate(result['routes']):
            path = [route['depot']] + route['path'] + [route['depot']]
            px = [self.inst.nodes[idx]['x'] for idx in path]
            py = [self.inst.nodes[idx]['y'] for idx in path]
            plt.plot(px, py, color=cmap(i%20), linewidth=1.5, alpha=0.8)
        plt.title(f"Deep ALNS: Dist={result['obj']:.2f}, V={result['vehicles']}")
        plt.savefig(output_path)
        plt.close()

# ==========================================
# 4. 批量执行 (BKS Pursuit Mode)
# ==========================================

def run_deep_search(data_dir):
    if not os.path.exists(data_dir): return
    res_dir = os.path.join(os.path.dirname(data_dir), "Certified_Rerun_Results", "Deep_ALNS_Results")
    if not os.path.exists(res_dir): os.makedirs(res_dir)
    
    files = sorted([f for f in os.listdir(data_dir) if (f.startswith('p') or f.startswith('pr')) and not f.endswith('.png')])
    summary = []
    
    print(f"=== 启动 MDVRP 深度搜索 (不限时间，追求 BKS) ===")
    print(f"注意：每个算例可能耗时较长，请耐心等待。\n")
    
    for f in files:
        path = os.path.join(data_dir, f)
        print(f"正在死磕算例: {f} ...")
        try:
            inst = MDVRPInstance(path)
            inst.load()
            
            # 动态设置迭代参数
            # N <= 100: 20000次迭代足够
            # N > 100: 50000次迭代
            # N > 300: 80000次迭代
            iters = 20000
            if inst.n > 100: iters = 50000
            if inst.n > 300: iters = 80000
            
            # 停滞阈值：迭代次数的 10%
            stag = int(iters * 0.1)
            
            solver = ALNSSolverDeep(inst)
            res = solver.solve_deep_search(max_iters=iters, max_stagnation=stag)
            
            print(f"  > 最终: 距离 {res['obj']:.2f}, 耗时 {res['time']/60:.1f} min")
            
            if res['obj'] > 0:
                solver.visualize(res, os.path.join(res_dir, f"{f}_deep.png"))
            
            summary.append({'Instance': f, 'Cost': res['obj'], 'Veh': res['vehicles'], 'Time': res['time']})
            
        except Exception as e:
            print(f"Error: {e}")
            traceback.print_exc()

    # 保存
    with open(os.path.join(res_dir, "Deep_Summary.txt"), 'w') as f:
        f.write(f"{'Instance':<15} {'Cost':<15} {'Veh':<10} {'Time(s)':<10}\n")
        for s in summary:
            f.write(f"{s['Instance']:<15} {s['Cost']:<15.2f} {s['Veh']:<10} {s['Time']:<10.2f}\n")

if __name__ == "__main__":
    target_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "C-mdvrp")
    run_deep_search(target_dir)
