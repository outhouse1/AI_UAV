import os
import time
import math
import random
import traceback
import warnings
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from numba import jit

# ==========================================
# 1. 环境配置
# ==========================================
warnings.filterwarnings("ignore")
try:
    matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
except:
    pass

def get_safe_cmap(name='tab20'):
    try:
        return matplotlib.colormaps[name]
    except AttributeError:
        return plt.cm.get_cmap(name)

# ==========================================
# 2. Numba 加速核心函数 (极速版)
# ==========================================

@jit(nopython=True)
def calc_dist_matrix_numba(x, y, size):
    """预计算距离矩阵"""
    matrix = np.zeros((size, size), dtype=np.float64)
    for i in range(size):
        for j in range(size):
            matrix[i, j] = np.sqrt((x[i]-x[j])**2 + (y[i]-y[j])**2)
    return matrix

@jit(nopython=True)
def calc_delta_dist(dist_matrix, prev_node, next_node, target_node):
    """
    O(1) 计算插入一个节点带来的距离增量
    Delta = D(prev, target) + D(target, next) - D(prev, next)
    """
    return (dist_matrix[prev_node, target_node] + 
            dist_matrix[target_node, next_node] - 
            dist_matrix[prev_node, next_node])

@jit(nopython=True)
def calc_route_cost_numba(route, depot_idx, dist_matrix):
    """计算单条路线总距离"""
    cost = 0.0
    curr = depot_idx
    for i in range(len(route)):
        n = route[i]
        cost += dist_matrix[curr, n]
        curr = n
    cost += dist_matrix[curr, depot_idx]
    return cost

# ==========================================
# 3. 数据结构
# ==========================================

class MDVRPInstance:
    def __init__(self, path):
        self.path = path
        self.filename = os.path.basename(path)
        self.m = 0; self.n = 0; self.d = 0
        self.D = 0; self.Q = 0
        self.depot_D = []
        self.depot_Q = []
        self.nodes = [] 
        self.np_x = None
        self.np_y = None
        self.np_demands = None
        self.np_services = None
        self.dist_matrix = None

    def load(self):
        with open(self.path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        
        parts = lines[0].split()
        self.m = int(parts[1]); self.n = int(parts[2]); self.d = int(parts[3])
        self.depot_D = []
        self.depot_Q = []
        for line_idx in range(1, 1 + self.d):
            parts = lines[line_idx].split()
            self.depot_D.append(float(parts[0]))
            self.depot_Q.append(float(parts[1]))
        self.D = self.depot_D[0]
        self.Q = self.depot_Q[0]
        
        self.nodes = []
        x_list, y_list, dem_list, serv_list = [], [], [], []
        
        start_idx = 1 + self.d
        count = 0
        total_nodes = self.n + self.d
        
        for i in range(start_idx, len(lines)):
            if count >= total_nodes: break
            p = lines[i].split()
            x, y, s, dem = float(p[1]), float(p[2]), float(p[3]), float(p[4])
            self.nodes.append({'id': int(p[0]), 'idx': count})
            x_list.append(x); y_list.append(y)
            dem_list.append(dem); serv_list.append(s)
            count += 1
            
        self.np_x = np.array(x_list, dtype=np.float64)
        self.np_y = np.array(y_list, dtype=np.float64)
        self.np_demands = np.array(dem_list, dtype=np.float64)
        self.np_services = np.array(serv_list, dtype=np.float64)
        
        # Numba 加速矩阵计算
        self.dist_matrix = calc_dist_matrix_numba(self.np_x, self.np_y, len(self.nodes))

    def depot_index(self, depot_node_idx):
        return int(depot_node_idx) - self.n

    def depot_capacity(self, depot_node_idx):
        return self.depot_Q[self.depot_index(depot_node_idx)]

    def depot_duration(self, depot_node_idx):
        return self.depot_D[self.depot_index(depot_node_idx)]

class Solution:
    def __init__(self, instance):
        self.inst = instance
        # routes: {depot_idx: [np.array(customer_indices), ...]}
        self.routes = {d: [] for d in range(instance.n, instance.n + instance.d)}
        self.cost = 0.0
        self.unassigned = []

    def copy(self):
        new_sol = Solution(self.inst)
        new_routes = {}
        for d, r_list in self.routes.items():
            new_routes[d] = [r.copy() for r in r_list]
        new_sol.routes = new_routes
        new_sol.cost = self.cost
        new_sol.unassigned = list(self.unassigned)
        return new_sol

    def evaluate(self):
        total_dist = 0.0
        penalty = 0.0
        
        for d_idx, d_routes in self.routes.items():
            for r in d_routes:
                if len(r) == 0: continue
                # 使用 Numba 加速路线距离计算
                dist = calc_route_cost_numba(r, d_idx, self.inst.dist_matrix)
                total_dist += dist
                
                # 容量检查
                load = np.sum(self.inst.np_demands[r])
                cap = self.inst.depot_capacity(d_idx)
                if load > cap: 
                    penalty += (load - cap) * 10000
                
                # 时长检查 (如果有)
                max_dur = self.inst.depot_duration(d_idx)
                if max_dur > 0:
                    dur = dist + np.sum(self.inst.np_services[r])
                    if dur > max_dur:
                        penalty += (dur - max_dur) * 10000
            if len(d_routes) > self.inst.m:
                penalty += (len(d_routes) - self.inst.m) * 1000000
                        
        penalty += len(self.unassigned) * 1e8
        self.cost = total_dist + penalty
        return total_dist, penalty == 0 and len(self.unassigned) == 0

# ==========================================
# 4. ALNS Turbo Solver (深度优化版)
# ==========================================

class ALNSTurboSolver:
    def __init__(self, instance, seed=42):
        self.inst = instance
        random.seed(seed)
        np.random.seed(seed)
        
        # SA 参数
        self.sigma = [30, 15, 5] 
        self.reaction = 0.1
        self.min_rem = 1
        self.max_rem = min(80, max(10, int(instance.n * 0.3)))
        
        # 权重系统 (简化以提升速度)
        self.ops_d = ['random'] 
        self.ops_r = ['greedy'] # 实际上我们在 repair 内部实现了 greedy/regret 逻辑
        self.w_d = [1.0]; self.s_d = [0.0]; self.c_d = [0]
        self.w_r = [1.0]; self.s_r = [0.0]; self.c_r = [0]

    def _destroy_random(self, sol, q):
        # 优化：避免 numpy 转换，直接操作列表逻辑
        routes_list = []
        for d, r_list in sol.routes.items():
            for r_idx, r in enumerate(r_list):
                for n in r:
                    routes_list.append((d, r_idx, n))
        
        if not routes_list: return
        
        targets = random.sample(routes_list, min(q, len(routes_list)))
        removed_nodes = set()
        
        # 转换为 list 操作
        temp_routes = {d: [list(r) for r in rs] for d, rs in sol.routes.items()}
        
        for d, r_idx, n in targets:
            if n not in removed_nodes:
                try:
                    temp_routes[d][r_idx].remove(n)
                    removed_nodes.add(n)
                except ValueError:
                    pass
        
        # 回写
        for d in temp_routes:
            sol.routes[d] = [np.array(r, dtype=np.int32) for r in temp_routes[d] if len(r) > 0]
        
        sol.unassigned.extend(list(removed_nodes))

    def _destroy_worst(self, sol, q):
        candidates = []
        for d, r_list in sol.routes.items():
            for r_idx, r in enumerate(r_list):
                route = list(r)
                for pos, node in enumerate(route):
                    prev_node = d if pos == 0 else route[pos - 1]
                    next_node = d if pos == len(route) - 1 else route[pos + 1]
                    saving = (
                        self.inst.dist_matrix[prev_node, node]
                        + self.inst.dist_matrix[node, next_node]
                        - self.inst.dist_matrix[prev_node, next_node]
                    )
                    candidates.append((float(saving), d, r_idx, int(node)))
        if not candidates:
            return

        candidates.sort(reverse=True, key=lambda x: x[0])
        selected = candidates[: min(q, len(candidates))]
        removed_nodes = set()
        temp_routes = {d: [list(r) for r in rs] for d, rs in sol.routes.items()}
        for _, d, r_idx, node in selected:
            if node in removed_nodes:
                continue
            try:
                temp_routes[d][r_idx].remove(node)
                removed_nodes.add(node)
            except (IndexError, ValueError):
                pass

        for d in temp_routes:
            sol.routes[d] = [np.array(r, dtype=np.int32) for r in temp_routes[d] if len(r) > 0]
        sol.unassigned.extend(list(removed_nodes))

    def _repair_fast(self, sol):
        """
        极速修复算子：
        1. 使用 Python List 进行动态操作
        2. 缓存 route_loads 进行 O(1) 容量检查
        3. 使用 Numba 进行 O(1) 距离增量计算
        """
        # 1. 数据准备：转 list 并计算当前载重
        working_routes = {} 
        route_loads = {}
        route_durations = {}
        
        for d, r_list in sol.routes.items():
            working_routes[d] = [list(r) for r in r_list]
            loads = []
            durations = []
            for r in r_list:
                loads.append(np.sum(self.inst.np_demands[r]) if len(r) > 0 else 0)
                if len(r) > 0:
                    route_dist = calc_route_cost_numba(r, d, self.inst.dist_matrix)
                    durations.append(route_dist + np.sum(self.inst.np_services[r]))
                else:
                    durations.append(0.0)
            route_loads[d] = loads
            route_durations[d] = durations

        random.shuffle(sol.unassigned)
        
        # 缓存频繁访问的对象
        dist_matrix = self.inst.dist_matrix
        demands = self.inst.np_demands
        failed_nodes = []
        
        while sol.unassigned:
            node = sol.unassigned.pop()
            node_dem = demands[node]
            
            best_delta = 1e9
            best_move = None # (d, r_idx, pos)
            
            # 遍历所有可能的插入位置
            for d, r_list in working_routes.items():
                capacity = self.inst.depot_capacity(d)
                max_dur = self.inst.depot_duration(d)
                for r_idx, r in enumerate(r_list):
                    
                    # --- 优化1: O(1) 容量预检查 ---
                    if route_loads[d][r_idx] + node_dem > capacity:
                        continue
                        
                    # --- 优化2: 距离增量计算 ---
                    if not r: # 空路线
                        delta = calc_delta_dist(dist_matrix, d, d, node)
                        if delta < best_delta:
                            # 时长检查 (仅当有更优解时才做耗时检查)
                            if max_dur > 0 and (delta + self.inst.np_services[node] > max_dur):
                                continue
                            best_delta = delta
                            best_move = (d, r_idx, 0)
                    else:
                        # 遍历路线中的每个位置
                        len_r = len(r)
                        # Depot -> node -> first customer
                        delta = calc_delta_dist(dist_matrix, d, r[0], node)
                        if delta < best_delta:
                             # 粗略时长检查 (省略全路线计算，假设可行，依靠后续罚函数兜底或严格检查)
                             if max_dur > 0 and (route_durations[d][r_idx] + delta + self.inst.np_services[node] > max_dur + 1e-9):
                                 pass
                             else:
                                 best_delta = delta
                                 best_move = (d, r_idx, 0)

                        # Previous customer -> node -> next customer
                        for i in range(len_r - 1):
                            delta = calc_delta_dist(dist_matrix, r[i], r[i+1], node)
                            if delta < best_delta:
                                if max_dur > 0 and (route_durations[d][r_idx] + delta + self.inst.np_services[node] > max_dur + 1e-9):
                                    continue
                                best_delta = delta
                                best_move = (d, r_idx, i+1)
                                
                        # Last customer -> node -> depot
                        delta = calc_delta_dist(dist_matrix, r[-1], d, node)
                        if delta < best_delta:
                            if max_dur > 0 and (route_durations[d][r_idx] + delta + self.inst.np_services[node] > max_dur + 1e-9):
                                continue
                            best_delta = delta
                            best_move = (d, r_idx, len_r)
                            
                # 尝试新路线
                if node_dem <= capacity and len(working_routes[d]) < self.inst.m:
                    delta = calc_delta_dist(dist_matrix, d, d, node)
                    if delta < best_delta:
                        if max_dur > 0 and (delta + self.inst.np_services[node] > max_dur + 1e-9):
                            continue
                        best_delta = delta
                        best_move = (d, -1, 0)
            
            # 执行最佳插入
            if best_move:
                d, r_idx, pos = best_move
                if r_idx == -1:
                    working_routes[d].append([node])
                    route_loads[d].append(node_dem)
                    route_durations[d].append(best_delta + self.inst.np_services[node])
                else:
                    working_routes[d][r_idx].insert(pos, node)
                    route_loads[d][r_idx] += node_dem
                    route_durations[d][r_idx] += best_delta + self.inst.np_services[node]
            else:
                failed_nodes.append(node)

        # 回写结果
        for d in working_routes:
            sol.routes[d] = [np.array(r, dtype=np.int32) for r in working_routes[d] if len(r)>0]
        sol.unassigned.extend(failed_nodes)

    def _route_distance(self, route, depot_idx):
        if len(route) == 0:
            return 0.0
        return float(calc_route_cost_numba(np.array(route, dtype=np.int32), depot_idx, self.inst.dist_matrix))

    def _route_load(self, route):
        if len(route) == 0:
            return 0.0
        return float(np.sum(self.inst.np_demands[np.array(route, dtype=np.int32)]))

    def _route_duration(self, route, depot_idx):
        if len(route) == 0:
            return 0.0
        arr = np.array(route, dtype=np.int32)
        return float(calc_route_cost_numba(arr, depot_idx, self.inst.dist_matrix) + np.sum(self.inst.np_services[arr]))

    def _route_feasible(self, route, depot_idx):
        if len(route) == 0:
            return True
        if self._route_load(route) > self.inst.depot_capacity(depot_idx) + 1e-9:
            return False
        max_dur = self.inst.depot_duration(depot_idx)
        if max_dur > 0 and self._route_duration(route, depot_idx) > max_dur + 1e-9:
            return False
        return True

    def _two_opt_route(self, route, depot_idx):
        if len(route) < 4:
            return list(route)
        best = list(route)
        improved = True
        while improved:
            improved = False
            base = self._route_distance(best, depot_idx)
            n = len(best)
            for i in range(n - 2):
                for j in range(i + 2, n):
                    candidate = best[:i + 1] + list(reversed(best[i + 1:j + 1])) + best[j + 1:]
                    if self._route_distance(candidate, depot_idx) + 1e-9 < base:
                        best = candidate
                        improved = True
                        break
                if improved:
                    break
        return best

    def _find_best_swap(self, routes):
        best_move = None
        best_delta = -1e-9
        refs = []
        for d, r_list in routes.items():
            for r_idx, route in enumerate(r_list):
                if route:
                    refs.append((d, r_idx, route))

        for left in range(len(refs)):
            d_a, r_a_idx, route_a = refs[left]
            old_a = self._route_distance(route_a, d_a)
            for right in range(left + 1, len(refs)):
                d_b, r_b_idx, route_b = refs[right]
                old_b = self._route_distance(route_b, d_b)
                for pos_a, node_a in enumerate(route_a):
                    for pos_b, node_b in enumerate(route_b):
                        cand_a = list(route_a)
                        cand_b = list(route_b)
                        cand_a[pos_a] = node_b
                        cand_b[pos_b] = node_a
                        if not self._route_feasible(cand_a, d_a):
                            continue
                        if not self._route_feasible(cand_b, d_b):
                            continue
                        new_a = self._route_distance(cand_a, d_a)
                        new_b = self._route_distance(cand_b, d_b)
                        delta = (new_a + new_b) - (old_a + old_b)
                        if delta < best_delta:
                            best_delta = delta
                            best_move = (d_a, r_a_idx, pos_a, d_b, r_b_idx, pos_b)
        return best_move

    def _local_improve(self, sol, max_passes=3):
        routes = {d: [list(r) for r in r_list if len(r) > 0] for d, r_list in sol.routes.items()}

        for d, r_list in routes.items():
            for idx, route in enumerate(r_list):
                r_list[idx] = self._two_opt_route(route, d)

        for _ in range(max_passes):
            best_move = None
            best_delta = -1e-9
            for d_from, from_routes in routes.items():
                for r_from_idx, from_route in enumerate(from_routes):
                    if not from_route:
                        continue
                    old_from_dist = self._route_distance(from_route, d_from)
                    for node_pos, node in enumerate(list(from_route)):
                        reduced_from = from_route[:node_pos] + from_route[node_pos + 1:]
                        new_from_dist = self._route_distance(reduced_from, d_from)
                        for d_to, to_routes in routes.items():
                            for r_to_idx, to_route in enumerate(to_routes):
                                if d_from == d_to and r_from_idx == r_to_idx:
                                    continue
                                if self._route_load(to_route) + self.inst.np_demands[node] > self.inst.depot_capacity(d_to) + 1e-9:
                                    continue
                                old_to_dist = self._route_distance(to_route, d_to)
                                for insert_pos in range(len(to_route) + 1):
                                    expanded_to = to_route[:insert_pos] + [node] + to_route[insert_pos:]
                                    if not self._route_feasible(expanded_to, d_to):
                                        continue
                                    new_to_dist = self._route_distance(expanded_to, d_to)
                                    delta = (new_from_dist + new_to_dist) - (old_from_dist + old_to_dist)
                                    if delta < best_delta:
                                        best_delta = delta
                                        best_move = (d_from, r_from_idx, node_pos, d_to, r_to_idx, insert_pos)

            if best_move is None:
                swap_move = self._find_best_swap(routes)
                if swap_move is None:
                    break
                d_a, r_a_idx, pos_a, d_b, r_b_idx, pos_b = swap_move
                routes[d_a][r_a_idx][pos_a], routes[d_b][r_b_idx][pos_b] = (
                    routes[d_b][r_b_idx][pos_b],
                    routes[d_a][r_a_idx][pos_a],
                )
                routes[d_a][r_a_idx] = self._two_opt_route(routes[d_a][r_a_idx], d_a)
                routes[d_b][r_b_idx] = self._two_opt_route(routes[d_b][r_b_idx], d_b)
                continue

            d_from, r_from_idx, node_pos, d_to, r_to_idx, insert_pos = best_move
            node = routes[d_from][r_from_idx].pop(node_pos)
            if not routes[d_from][r_from_idx]:
                del routes[d_from][r_from_idx]
                if d_from == d_to and r_from_idx < r_to_idx:
                    r_to_idx -= 1
            routes[d_to][r_to_idx].insert(insert_pos, node)
            routes[d_to][r_to_idx] = self._two_opt_route(routes[d_to][r_to_idx], d_to)

        for d in routes:
            sol.routes[d] = [np.array(r, dtype=np.int32) for r in routes[d] if len(r) > 0]
        return sol

    def solve(self, max_iters=50000, time_limit=None):
        start_t = time.time()
        
        # 初始解
        curr_sol = None
        curr_dist = float("inf")
        curr_feas = False
        curr_obj = float("inf")
        for _ in range(4):
            candidate = Solution(self.inst)
            candidate.unassigned = list(range(self.inst.n))
            self._repair_fast(candidate)
            self._local_improve(candidate, max_passes=2)
            cand_dist, cand_feas = candidate.evaluate()
            if candidate.cost < curr_obj:
                curr_sol = candidate
                curr_dist = cand_dist
                curr_feas = cand_feas
                curr_obj = candidate.cost
        if curr_sol is None:
            curr_sol = Solution(self.inst)
            curr_sol.unassigned = list(range(self.inst.n))
            curr_dist, curr_feas = curr_sol.evaluate()
            curr_obj = curr_sol.cost
        best_sol = curr_sol.copy()
        best_obj = curr_obj
        
        print(f"  > 初始解: {curr_dist:.2f} (Feasible: {curr_feas})")
        
        T = max(curr_obj * 0.05, 1.0)
        alpha = 0.9995
        
        for it in range(max_iters):
            if time_limit and (time.time() - start_t > time_limit): break
            
            temp_sol = curr_sol.copy()
            q = random.randint(self.min_rem, self.max_rem)
            
            # Removal step
            if random.random() < 0.55:
                self._destroy_worst(temp_sol, q)
            else:
                self._destroy_random(temp_sol, q)
            
            # Repair (极速版)
            self._repair_fast(temp_sol)
            
            new_dist, feas = temp_sol.evaluate()
            new_obj = temp_sol.cost
            
            # SA 接受准则
            delta = new_obj - curr_obj
            if delta < 0:
                if feas and new_obj < best_obj:
                    self._local_improve(temp_sol, max_passes=2)
                    new_dist, feas = temp_sol.evaluate()
                    new_obj = temp_sol.cost
                curr_sol = temp_sol
                curr_obj = new_obj
                if new_obj < best_obj:
                    best_sol = temp_sol.copy()
                    best_obj = new_obj
                    print(f"    [Iter {it}] 新最优: {best_obj:.2f}")
            elif random.random() < math.exp(-delta / T):
                curr_sol = temp_sol
                curr_obj = new_obj
            
            T *= alpha
            
        self._local_improve(best_sol, max_passes=8)
        final_dist, final_feas = best_sol.evaluate()
        return (final_dist if final_feas else -1.0), best_sol

    def visualize(self, sol, path):
        plt.figure(figsize=(10, 8))
        dx = self.inst.np_x[self.inst.n:]
        dy = self.inst.np_y[self.inst.n:]
        plt.scatter(dx, dy, c='k', marker='s', s=100)
        cx = self.inst.np_x[:self.inst.n]
        cy = self.inst.np_y[:self.inst.n]
        plt.scatter(cx, cy, c='gray', alpha=0.5, s=20)
        
        cmap = get_safe_cmap('tab20')
        i = 0
        for d, r_list in sol.routes.items():
            for r in r_list:
                if len(r) == 0: continue
                pts = [d] + list(r) + [d]
                px = self.inst.np_x[pts]
                py = self.inst.np_y[pts]
                plt.plot(px, py, c=cmap(i%20), alpha=0.8)
                i += 1
        plt.title(f"Turbo ALNS: {sol.cost:.2f}")
        plt.savefig(path)
        plt.close()

# ==========================================
# 5. 运行逻辑
# ==========================================

def run_turbo_search(data_dir):
    if not os.path.exists(data_dir): return
    res_dir = os.path.join(os.path.dirname(data_dir), "Certified_Rerun_Results", "Turbo_ALNS_Results")
    if not os.path.exists(res_dir): os.makedirs(res_dir)
    
    files = sorted([f for f in os.listdir(data_dir) if (f.startswith('p') or f.startswith('pr')) and not f.endswith('.png')])
    summary_data = [] 
    
    print(f"=== 启动 Numba 极速版 ALNS (目标: BKS) ===")
    
    for f in files:
        print(f"\n正在处理: {f} ...")
        try:
            inst = MDVRPInstance(os.path.join(data_dir, f))
            inst.load()
            
            solver = ALNSTurboSolver(inst)
            
            # 记录开始时间
            start_time = time.time()
            
            # 执行 50,000 次迭代 (由于优化，这会非常快)
            # 对于大规模算例，可适当增加迭代数或设置 time_limit
            obj, best_sol = solver.solve(max_iters=50000, time_limit=180) 
            
            # 记录结束时间
            end_time = time.time()
            duration = end_time - start_time
            
            print(f"  > 最终结果: {obj:.2f} (耗时: {duration:.2f}s)")
            
            solver.visualize(best_sol, os.path.join(res_dir, f"{f}_turbo.png"))
            summary_data.append((f, obj, duration))
            
        except Exception as e:
            print(f"Error: {e}")
            traceback.print_exc()
            summary_data.append((f, -1.0, -1.0))

    # 生成总结报告
    print("\n" + "="*50)
    print(f"{'Instance':<15} {'Cost':<15} {'Time(s)':<15}")
    print("-" * 50)
    
    summary_path = os.path.join(res_dir, "Untitled-5_Summary.txt")
    with open(summary_path, 'w', encoding='utf-8') as f_out:
        header = f"{'Instance':<15} {'Cost':<15} {'Time(s)':<15}\n"
        f_out.write(header)
        f_out.write("-" * 50 + "\n")
        
        for item in summary_data:
            line = f"{item[0]:<15} {item[1]:<15.2f} {item[2]:<15.2f}"
            print(line)
            f_out.write(line + "\n")
            
    print("="*50)
    print(f"总结报告已保存至: {summary_path}")

if __name__ == "__main__":
    target_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "C-mdvrp")
    run_turbo_search(target_dir)
