# Gurobi求解方案

import os
import time
import math
import json
import traceback
import warnings
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import gurobipy as gp
from gurobipy import GRB

# ==========================================
# 1. 环境配置
# ==========================================
warnings.filterwarnings("ignore")
try:
    matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
except:
    pass

def get_safe_cmap(name='tab20'):
    try:
        return matplotlib.colormaps[name]
    except AttributeError:
        return plt.cm.get_cmap(name)

class MDVRPSolver:
    """
    Cordeau MDVRP 标准格式求解器 (Gurobi)
    """
    def __init__(self, instance_path):
        self.instance_path = instance_path
        self.filename = os.path.basename(instance_path)
        
        # 全局参数
        self.type = 0
        self.m = 0  # 每个车场的车辆数 (Cordeau定义 m = number of vehicles, MDVRP中通常指 per depot)
        self.n = 0  # 客户数
        self.t = 0  # 车场数
        
        # 车场约束 (列表，对应 t 个车场)
        self.depot_specs = [] # [{'D': float, 'Q': float}, ...]
        
        # 节点数据
        # 索引 0 到 n-1 为客户
        # 索引 n 到 n+t-1 为车场
        self.nodes = [] 
        self.distances = None
        
    def read_instance(self):
        """严格按照 Cordeau 格式描述读取数据"""
        if not os.path.exists(self.instance_path):
            raise FileNotFoundError(f"文件不存在: {self.instance_path}")
            
        with open(self.instance_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
            
        if not lines:
            raise ValueError("文件为空")

        # --- Line 1: type m n t ---
        # m: number of vehicles (per depot for MDVRP usually)
        # n: number of customers
        # t: number of depots
        parts = lines[0].split()
        self.type = int(parts[0])
        self.m = int(parts[1])
        self.n = int(parts[2])
        self.t = int(parts[3])
        
        current_line = 1
        
        # --- Next t lines: D Q (Depot parameters) ---
        self.depot_specs = []
        for _ in range(self.t):
            parts = lines[current_line].split()
            # D: max duration, Q: max load
            self.depot_specs.append({
                'D': float(parts[0]),
                'Q': float(parts[1])
            })
            current_line += 1
            
        # --- Next n + t lines: Node Data ---
        # i x y d q f a list e l
        # 格式说明：
        # i: id, x: x-coord, y: y-coord, d: service duration, q: demand
        # 后面 f, a, list, e, l 在 MDVRP (type 2) 中通常不重要或为0，但我们需要正确解析前几列
        
        self.nodes = []
        expected_nodes = self.n + self.t
        
        for _ in range(expected_nodes):
            if current_line >= len(lines): break
            parts = lines[current_line].split()
            
            # 解析基础数据
            node = {
                'id': int(parts[0]),
                'x': float(parts[1]),
                'y': float(parts[2]),
                'service_duration': float(parts[3]),
                'demand': float(parts[4]),
                # MDVRP 忽略后面频率、时间窗等参数
            }
            self.nodes.append(node)
            current_line += 1
            
        # 验证读取是否完整
        if len(self.nodes) != self.n + self.t:
            print(f"[Warning] 节点数量不匹配: 预期 {self.n + self.t}, 实际 {len(self.nodes)}")

        print(f"  > 算例读取成功: {self.filename}")
        print(f"    类型: {self.type}, 客户: {self.n}, 车场: {self.t}, 车辆/车场: {self.m}")
        
        # 计算距离矩阵
        self._calculate_distance_matrix()

    def _calculate_distance_matrix(self):
        count = len(self.nodes)
        self.distances = np.zeros((count, count))
        for i in range(count):
            for j in range(count):
                if i != j:
                    d = math.sqrt((self.nodes[i]['x'] - self.nodes[j]['x'])**2 + 
                                  (self.nodes[i]['y'] - self.nodes[j]['y'])**2)
                    self.distances[i][j] = d

    def solve(self, time_limit=300):
        """Gurobi 建模求解"""
        # 索引划分
        # 客户: 0 ... n-1
        # 车场: n ... n+t-1
        customers = list(range(self.n))
        depots = list(range(self.n, self.n + self.t))
        all_nodes = customers + depots
        
        # 车辆集合
        # 为了简化，我们创建总车辆池，令 K = m * t
        # 实际上我们需要强制：车辆 k 如果被使用，必须属于且仅属于一个车场
        total_vehicles = self.m * self.t
        vehicles = list(range(total_vehicles))
        
        # 为了方便约束，我们可以预先分配：前 m 辆属于车场 0，次 m 辆属于车场 1...
        # 这样写约束更简单，也防止“车辆未返回出发仓库”的问题
        vehicle_depot_map = {} # k -> depot_index
        for d_idx, d_node_idx in enumerate(depots):
            for k_offset in range(self.m):
                v_idx = d_idx * self.m + k_offset
                vehicle_depot_map[v_idx] = d_node_idx

        print(f"  > 开始建模求解 (限时 {time_limit}s)...")
        start_time = time.time()
        
        try:
            model = gp.Model("MDVRP")
            model.setParam('TimeLimit', time_limit)
            model.setParam('OutputFlag', 0) # 静默模式
            model.setParam('MIPGap', 0.01)  # 1% Gap
            
            # --- 变量 ---
            # x[i,j,k]: 车辆 k 从 i 到 j
            x = {}
            # 优化：只创建可行的边
            # 1. 客户之间
            # 2. 车场 -> 客户 (仅限车辆 k 归属的车场)
            # 3. 客户 -> 车场 (仅限车辆 k 归属的车场)
            
            for k in vehicles:
                home_depot = vehicle_depot_map[k]
                
                # 客户到客户
                for i in customers:
                    for j in customers:
                        if i != j:
                            x[i,j,k] = model.addVar(vtype=GRB.BINARY)
                
                # 车场 <-> 客户
                for i in customers:
                    # 只能从自家车场出发
                    x[home_depot, i, k] = model.addVar(vtype=GRB.BINARY)
                    # 只能回自家车场
                    x[i, home_depot, k] = model.addVar(vtype=GRB.BINARY)

            # y[i,k]: 车辆 k 服务客户 i
            y = {}
            for k in vehicles:
                for i in customers:
                    y[i,k] = model.addVar(vtype=GRB.BINARY)
            
            # u[i,k]: MTZ 消除子回路。必须按车辆定义，避免不同车辆路线共享同一顺序变量。
            u = {}
            for k in vehicles:
                for i in customers:
                    u[i,k] = model.addVar(vtype=GRB.CONTINUOUS, lb=1, ub=self.n)

            model.update()
            
            # --- 目标函数: 最小化总距离 ---
            obj_terms = []
            for k in vehicles:
                home_depot = vehicle_depot_map[k]
                
                # Cust -> Cust
                for i in customers:
                    for j in customers:
                        if i != j:
                            obj_terms.append(self.distances[i][j] * x[i,j,k])
                
                # Depot <-> Cust
                for i in customers:
                    obj_terms.append(self.distances[home_depot][i] * x[home_depot,i,k])
                    obj_terms.append(self.distances[i][home_depot] * x[i,home_depot,k])
            
            model.setObjective(gp.quicksum(obj_terms), GRB.MINIMIZE)
            
            # --- 约束条件 ---
            
            # 1. 访问约束: 每个客户被访问一次
            for i in customers:
                model.addConstr(gp.quicksum(y[i,k] for k in vehicles) == 1, name=f"Visit_{i}")
            
            # 2. 流平衡 & 车辆使用
            for k in vehicles:
                home_depot = vehicle_depot_map[k]
                
                # 2.1 客户节点的流平衡
                for i in customers:
                    # 流入 i
                    flow_in = gp.quicksum(x[j,i,k] for j in customers if j!=i) + x[home_depot,i,k]
                    # 流出 i
                    flow_out = gp.quicksum(x[i,j,k] for j in customers if j!=i) + x[i,home_depot,k]
                    
                    model.addConstr(flow_in == y[i,k], name=f"In_{i}_{k}")
                    model.addConstr(flow_out == y[i,k], name=f"Out_{i}_{k}")
                
                # 2.2 车场节点的流平衡 (确保闭环：从家出发，必回流家)
                # 离开车场次数 <= 1 (如果不使用该车，则为0)
                start_flow = gp.quicksum(x[home_depot, j, k] for j in customers)
                end_flow = gp.quicksum(x[i, home_depot, k] for i in customers)
                
                model.addConstr(start_flow <= 1, name=f"Start_{k}")
                model.addConstr(start_flow == end_flow, name=f"Return_{k}")

            # 3. 容量约束
            # 注意：每个车场可能有不同的 Q，需根据 vehicle_depot_map[k] 获取对应车场的 specs
            for k in vehicles:
                home_depot = vehicle_depot_map[k]
                # 计算该车场在 depot_specs 里的索引 (home_depot 是全局索引 n ~ n+t-1)
                spec_idx = home_depot - self.n 
                Q_k = self.depot_specs[spec_idx]['Q']
                
                model.addConstr(gp.quicksum(self.nodes[i]['demand'] * y[i,k] for i in customers) <= Q_k, name=f"Cap_{k}")

            # 4. 时长约束 (如果有)
            for k in vehicles:
                home_depot = vehicle_depot_map[k]
                spec_idx = home_depot - self.n
                D_k = self.depot_specs[spec_idx]['D']
                
                if D_k > 0: # 只有当 D > 0 时才添加
                    # 行驶时间
                    trav_cost = 0
                    for i in customers:
                        for j in customers:
                            if i != j:
                                trav_cost += self.distances[i][j] * x[i,j,k]
                    for i in customers:
                        trav_cost += self.distances[home_depot][i] * x[home_depot,i,k]
                        trav_cost += self.distances[i][home_depot] * x[i,home_depot,k]
                    
                    # 服务时间
                    serv_cost = gp.quicksum(self.nodes[i]['service_duration'] * y[i,k] for i in customers)
                    
                    model.addConstr(trav_cost + serv_cost <= D_k, name=f"Dur_{k}")

            # 5. MTZ 消除子回路
            for k in vehicles:
                for i in customers:
                    for j in customers:
                        if i != j:
                            model.addConstr(u[i,k] - u[j,k] + self.n * x[i,j,k] <= self.n - 1)

            # --- 求解 ---
            model.optimize()
            
            # --- 结果提取 ---
            res = {
                'obj': float('inf'),
                'routes': [],
                'time': time.time() - start_time,
                'status': model.Status
            }
            
            if model.SolCount > 0:
                res['obj'] = model.ObjVal
                
                for k in vehicles:
                    home_depot = vehicle_depot_map[k]
                    # 找起点
                    start_cust = None
                    for j in customers:
                        if x[home_depot, j, k].X > 0.5:
                            start_cust = j
                            break
                    
                    if start_cust is not None:
                        # 重建路径
                        route = [home_depot, start_cust]
                        curr = start_cust
                        dist = self.distances[home_depot][start_cust]
                        load = self.nodes[start_cust]['demand']
                        
                        while True:
                            # 找下一跳
                            next_node = None
                            # 试探去客户
                            for j in customers:
                                if curr != j and x[curr, j, k].X > 0.5:
                                    next_node = j
                                    break
                            
                            # 试探回车场
                            if next_node is None:
                                if x[curr, home_depot, k].X > 0.5:
                                    next_node = home_depot
                            
                            if next_node is not None:
                                dist += self.distances[curr][next_node]
                                route.append(next_node)
                                if next_node < self.n: # 是客户
                                    load += self.nodes[next_node]['demand']
                                curr = next_node
                                if curr == home_depot:
                                    break
                            else:
                                break # 断路异常
                        
                        res['routes'].append({
                            'vehicle': k,
                            'path': route,
                            'dist': dist,
                            'load': load
                        })
            
            return res

        except Exception as e:
            print(f"  [Error] Gurobi 求解异常: {e}")
            traceback.print_exc()
            return None

    def visualize(self, res, save_path):
        """可视化结果"""
        if not res or not res['routes']: return
        
        plt.figure(figsize=(10, 8))
        
        # 画车场
        depot_indices = range(self.n, self.n + self.t)
        dx = [self.nodes[i]['x'] for i in depot_indices]
        dy = [self.nodes[i]['y'] for i in depot_indices]
        plt.scatter(dx, dy, c='red', marker='s', s=200, label='Depot', zorder=5)
        
        # 画客户
        cust_indices = range(self.n)
        cx = [self.nodes[i]['x'] for i in cust_indices]
        cy = [self.nodes[i]['y'] for i in cust_indices]
        plt.scatter(cx, cy, c='gray', s=30, alpha=0.6, label='Customer')
        
        cmap = get_safe_cmap('tab20')
        
        for i, r in enumerate(res['routes']):
            path = r['path']
            px = [self.nodes[n]['x'] for n in path]
            py = [self.nodes[n]['y'] for n in path]
            plt.plot(px, py, color=cmap(i % 20), linewidth=1.5, alpha=0.8)
            
        plt.title(f"MDVRP Solution: Cost={res['obj']:.2f}")
        plt.legend()
        plt.savefig(save_path)
        plt.close()

# ==========================================
# 2. 批量运行逻辑
# ==========================================
def run_batch(data_dir):
    res_dir = os.path.join(os.path.dirname(data_dir), "Certified_Rerun_Results", "Gurobi_Corrected_Results")
    if not os.path.exists(res_dir): os.makedirs(res_dir)
    
    files = [f for f in os.listdir(data_dir) if (f.startswith('p') or f.startswith('pr')) and not f.endswith('.png')]
    files.sort()
    
    summary = []
    
    print(f"=== Gurobi MDVRP 修正版求解启动 ===")
    
    for f in files:
        path = os.path.join(data_dir, f)
        print(f"\n正在处理: {f} ...")
        
        try:
            solver = MDVRPSolver(path)
            solver.read_instance()
            
            # 根据规模动态调整时间
            limit = 600
            if solver.n <= 50: limit = 180
            elif solver.n > 100: limit = 1200
            
            res = solver.solve(time_limit=limit)
            
            if res and res['obj'] != float('inf'):
                print(f"  > 成功: Cost {res['obj']:.2f}")
                solver.visualize(res, os.path.join(res_dir, f"{f}.png"))
                summary.append((f, res['obj'], res['time']))
            else:
                print("  > 无可行解或超时")
                summary.append((f, -1, limit))
                
        except Exception as e:
            print(f"  > 错误: {e}")
            
    # 保存汇总
    with open(os.path.join(res_dir, "Summary.txt"), 'w') as f:
        f.write("Instance\tCost\tTime\n")
        for item in summary:
            f.write(f"{item[0]}\t{item[1]:.2f}\t{item[2]:.2f}\n")

if __name__ == "__main__":
    target_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "C-mdvrp")
    run_batch(target_dir)
