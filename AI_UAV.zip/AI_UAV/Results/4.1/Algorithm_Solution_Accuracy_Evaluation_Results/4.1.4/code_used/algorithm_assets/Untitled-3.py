# 最简单的启发式算法指令 启发式 0
# 经典的 “两阶段启发式算法框架 (Two-Stage Heuristic)”：

# 第一阶段（聚类，Cluster）： 基于距离将客户分配给最近的车场（转化为多个独立的 CVRP 问题）。

# 第二阶段（路由，Route）： 对每个车场内部使用 模拟退火算法 (Simulated Annealing, SA) 结合 2-opt (局部优化) 进行路径规划。

import os
import time
import math
import json
import random
import copy
import traceback
import warnings
from datetime import datetime
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# ==========================================
# 1. 配置与兼容性
# ==========================================
warnings.filterwarnings("ignore")
try:
    matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Heiti TC', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
except:
    pass

def get_safe_cmap(name='tab20'):
    try:
        return matplotlib.colormaps[name]
    except AttributeError:
        return plt.cm.get_cmap(name)

# ==========================================
# 2. 数据结构与模型定义
# ==========================================

class MDVRPInstance:
    """标准 MDVRP 算例读取类"""
    def __init__(self, path):
        self.path = path
        self.filename = os.path.basename(path)
        self.m = 0  # 每个车场的车辆数
        self.n = 0  # 客户数
        self.d = 0  # 车场数
        self.D = 0  # 最大时长 (Duration constraint)
        self.Q = 0  # 车辆容量 (Capacity constraint)
        self.depot_D = []
        self.depot_Q = []
        self.nodes = [] # 0~n-1: 客户, n~n+d-1: 车场
        self.dist_matrix = None

    def load(self):
        with open(self.path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        
        # Line 0: type m n t
        parts = lines[0].split()
        self.m = int(parts[1])
        self.n = int(parts[2])
        self.d = int(parts[3])
        
        # Next d lines: depot-level D Q
        self.depot_D = []
        self.depot_Q = []
        for line_idx in range(1, 1 + self.d):
            parts = lines[line_idx].split()
            self.depot_D.append(float(parts[0]))
            self.depot_Q.append(float(parts[1]))
        self.D = self.depot_D[0]
        self.Q = self.depot_Q[0]
        
        # Nodes
        self.nodes = []
        start_idx = 1 + self.d
        count = 0
        total_nodes = self.n + self.d
        
        for i in range(start_idx, len(lines)):
            if count >= total_nodes: break
            p = lines[i].split()
            self.nodes.append({
                'id': int(p[0]),
                'x': float(p[1]),
                'y': float(p[2]),
                'service': float(p[3]),
                'demand': float(p[4]),
                'is_depot': (count >= self.n),
                'original_idx': count
            })
            count += 1
            
        self._calc_dist_matrix()
        print(f"  > 算例 {self.filename} 加载完毕: 客户{self.n}, 车场{self.d}, 容量{self.Q}, 最大时长{self.D}")

    def depot_index(self, depot_node_idx):
        return int(depot_node_idx) - self.n

    def depot_capacity(self, depot_node_idx):
        return self.depot_Q[self.depot_index(depot_node_idx)]

    def depot_duration(self, depot_node_idx):
        return self.depot_D[self.depot_index(depot_node_idx)]

    def _calc_dist_matrix(self):
        size = len(self.nodes)
        self.dist_matrix = np.zeros((size, size))
        for i in range(size):
            for j in range(size):
                if i != j:
                    d = math.sqrt((self.nodes[i]['x']-self.nodes[j]['x'])**2 + 
                                  (self.nodes[i]['y']-self.nodes[j]['y'])**2)
                    self.dist_matrix[i][j] = d

# ==========================================
# 3. 启发式算法核心 (聚类 + 模拟退火)
# ==========================================

class HeuristicSolver:
    def __init__(self, instance: MDVRPInstance):
        self.inst = instance
        self.best_solution = None
        self.best_cost = float('inf')
        
    def calculate_route_cost(self, route, depot_idx):
        """计算单条路径的成本和约束违规情况"""
        dist = 0
        load = 0
        duration = 0
        
        curr = depot_idx
        for node_idx in route:
            # 距离
            d = self.inst.dist_matrix[curr][node_idx]
            dist += d
            duration += d
            
            # 服务
            node = self.inst.nodes[node_idx]
            load += node['demand']
            duration += node['service']
            
            curr = node_idx
            
        # 回到车场
        d_back = self.inst.dist_matrix[curr][depot_idx]
        dist += d_back
        duration += d_back
        
        is_feasible = True
        if load > self.inst.depot_capacity(depot_idx): is_feasible = False
        max_duration = self.inst.depot_duration(depot_idx)
        if max_duration > 0 and duration > max_duration: is_feasible = False
        
        return dist, is_feasible, load, duration

    def initial_clustering(self):
        """
        阶段1: 聚类
        将每个客户分配给距离最近的车场
        """
        clusters = {d_idx: [] for d_idx in range(self.inst.n, self.inst.n + self.inst.d)}
        
        for i in range(self.inst.n): # 遍历所有客户
            min_dist = float('inf')
            best_depot = -1
            
            # 找最近车场
            for d_idx in range(self.inst.n, self.inst.n + self.inst.d):
                d = self.inst.dist_matrix[i][d_idx]
                if d < min_dist:
                    min_dist = d
                    best_depot = d_idx
            
            clusters[best_depot].append(i)
        return clusters

    def solve_subproblem_sa(self, customers, depot_idx, max_time=5):
        """
        阶段2: 对单个车场的客户集运行模拟退火 (Simulated Annealing)
        """
        if not customers:
            return []
            
        # 1. 生成初始解 (最近邻法 Greedy)
        routes = []
        unvisited = set(customers)
        
        while unvisited:
            curr_route = []
            curr_load = 0
            curr_dur = 0
            curr_node = depot_idx
            
            while True:
                # 寻找最近的可行邻居
                nearest = None
                min_d = float('inf')
                
                for cand in unvisited:
                    d = self.inst.dist_matrix[curr_node][cand]
                    node_data = self.inst.nodes[cand]
                    
                    # 预检查约束
                    new_load = curr_load + node_data['demand']
                    # 估算时长: 当前累积 + 去程 + 服务 + 回程
                    d_back = self.inst.dist_matrix[cand][depot_idx]
                    new_dur = curr_dur + d + node_data['service'] + d_back - self.inst.dist_matrix[curr_node][depot_idx] # 这是一个估算增量逻辑，简化处理
                    
                    # 严格检查
                    # 实际行走时间增加: dist(curr, cand)
                    # 实际回程时间改变: dist(cand, depot) - dist(curr, depot) (如果是第一个点，curr是depot)
                    # 简单逻辑：
                    # 尝试加入
                    
                    if new_load <= self.inst.Q:
                        # 如果有时间限制，这里需要更严格检查，为简化贪婪，暂时只考虑距离优先
                         if d < min_d:
                            min_d = d
                            nearest = cand
                
                if nearest is not None:
                    # 再次确认时间约束 (如果有)
                    # 构建临时路线测算
                    temp_route = curr_route + [nearest]
                    _, feas, _, _ = self.calculate_route_cost(temp_route, depot_idx)
                    
                    if feas:
                        curr_route.append(nearest)
                        curr_load += self.inst.nodes[nearest]['demand']
                        unvisited.remove(nearest)
                        curr_node = nearest
                    else:
                        break # 这个点加不进去了，结束这条路
                else:
                    break # 没有点能加进去了
            
            if not curr_route:
                # 极端情况：有点剩余但无法加入任何新路线（甚至空路线），通常是因为单个点需求>容量(不可能)或时间不够
                # 强制加入一个点开启新路线
                pop_node = unvisited.pop()
                routes.append([pop_node])
            else:
                routes.append(curr_route)

        # 2. 模拟退火优化
        current_routes = copy.deepcopy(routes)
        best_local_routes = copy.deepcopy(routes)
        
        # 计算初始成本
        def get_total_cost(r_list):
            c = 0
            for r in r_list:
                dist, feasible, _, _ = self.calculate_route_cost(r, depot_idx)
                c += dist
                if not feasible: c += 10000 # 惩罚
            return c

        curr_cost = get_total_cost(current_routes)
        best_local_cost = curr_cost
        
        T = 100.0
        alpha = 0.98
        end_time = time.time() + max_time
        
        while time.time() < end_time and T > 0.1:
            # 算子选择: 0: Swap(两点交换), 1: Relocate(移点), 2: 2-opt(路线内翻转)
            op = random.randint(0, 2)
            new_routes = copy.deepcopy(current_routes)
            
            # 随机选择路线和点
            if not new_routes: break
            
            r_idx1 = random.randint(0, len(new_routes)-1)
            if not new_routes[r_idx1]: continue
            
            if op == 0: # Swap (Inter-route or Intra-route)
                r_idx2 = random.randint(0, len(new_routes)-1)
                if not new_routes[r_idx2]: continue
                
                p1 = random.randint(0, len(new_routes[r_idx1])-1)
                p2 = random.randint(0, len(new_routes[r_idx2])-1)
                
                # 交换
                new_routes[r_idx1][p1], new_routes[r_idx2][p2] = new_routes[r_idx2][p2], new_routes[r_idx1][p1]
                
            elif op == 1: # Relocate
                r_idx2 = random.randint(0, len(new_routes)-1)
                
                p1 = random.randint(0, len(new_routes[r_idx1])-1)
                cust = new_routes[r_idx1].pop(p1)
                
                if not new_routes[r_idx1]: # 如果路线空了，删除
                    new_routes.pop(r_idx1)
                    if r_idx2 >= r_idx1: r_idx2 -= 1
                
                if not new_routes: # 如果全空了(不可能，但防卫)
                     new_routes.append([cust])
                else:
                    if r_idx2 >= len(new_routes): r_idx2 = 0
                    p2 = random.randint(0, len(new_routes[r_idx2]))
                    new_routes[r_idx2].insert(p2, cust)
                    
            elif op == 2: # 2-opt (Intra-route only)
                if len(new_routes[r_idx1]) > 2:
                    i, j = sorted(random.sample(range(len(new_routes[r_idx1])), 2))
                    # 翻转片段
                    new_routes[r_idx1][i:j+1] = reversed(new_routes[r_idx1][i:j+1])

            # 评估
            new_cost = get_total_cost(new_routes)
            delta = new_cost - curr_cost
            
            if delta < 0 or random.random() < math.exp(-delta / T):
                current_routes = new_routes
                curr_cost = new_cost
                if curr_cost < best_local_cost:
                    best_local_cost = curr_cost
                    best_local_routes = copy.deepcopy(current_routes)
            
            T *= alpha
            
        return best_local_routes

    def solve(self, time_limit=60):
        start_time = time.time()
        
        # 1. 聚类
        clusters = self.initial_clustering()
        
        # 2. 对每个车场并行(串行模拟)优化
        final_solution = []
        
        # 根据总时间分配给每个车场的时间
        # 简单策略：按客户数量比例分配，或者每个车场给几秒
        # 这里为了演示，每个车场给 time_limit / 车场数
        sub_time = max(2, time_limit / self.inst.d)
        
        print(f"  > 聚类完成，开始优化 {self.inst.d} 个子问题 (每个限时 {sub_time:.1f}s)...")
        
        total_dist = 0
        total_vehicles = 0
        all_feasible = True
        
        for d_idx, customers in clusters.items():
            if not customers:
                continue
            
            routes = self.solve_subproblem_sa(customers, d_idx, max_time=sub_time)
            if len(routes) > self.inst.m:
                all_feasible = False
            
            for r in routes:
                d, feas, _, _ = self.calculate_route_cost(r, d_idx)
                if not feas:
                    all_feasible = False
                final_solution.append({
                    'depot': d_idx,
                    'path': r,
                    'dist': d,
                    'feasible': feas
                })
                total_dist += d
                total_vehicles += 1
                
        self.best_solution = final_solution
        self.best_cost = total_dist
        
        return {
            'obj': total_dist if all_feasible else -1,
            'routes': final_solution,
            'vehicles': total_vehicles,
            'time': time.time() - start_time
        }

    def visualize(self, output_path):
        if not self.best_solution: return
        
        plt.figure(figsize=(12, 10))
        
        # 画车场
        dx = [self.inst.nodes[i]['x'] for i in range(self.inst.n, self.inst.n + self.inst.d)]
        dy = [self.inst.nodes[i]['y'] for i in range(self.inst.n, self.inst.n + self.inst.d)]
        plt.scatter(dx, dy, c='black', marker='s', s=200, zorder=10, label='车场 (Depot)')
        
        # 画客户
        cx = [self.inst.nodes[i]['x'] for i in range(self.inst.n)]
        cy = [self.inst.nodes[i]['y'] for i in range(self.inst.n)]
        plt.scatter(cx, cy, c='gray', alpha=0.3, s=20, label='客户 (Customer)')
        
        cmap = get_safe_cmap('tab20')
        
        for i, route in enumerate(self.best_solution):
            depot = route['depot']
            path_indices = route['path']
            
            # 完整坐标序列: Depot -> c1 -> c2 ... -> Depot
            full_path = [depot] + path_indices + [depot]
            px = [self.inst.nodes[idx]['x'] for idx in full_path]
            py = [self.inst.nodes[idx]['y'] for idx in full_path]
            
            color = cmap(i % 20)
            plt.plot(px, py, color=color, linewidth=1.5, alpha=0.8)
            
            # 画箭头
            # plt.arrow(...) # 为保持整洁省略大量箭头
            
        plt.title(f"{self.inst.filename}: SA-Heuristic Cost={self.best_cost:.2f}, V={len(self.best_solution)}")
        plt.legend()
        plt.savefig(output_path)
        plt.close()

# ==========================================
# 4. 批量执行逻辑
# ==========================================

def run_batch_heuristic(data_dir):
    if not os.path.exists(data_dir):
        print("目录不存在")
        return
        
    res_dir = os.path.join(os.path.dirname(data_dir), "Certified_Rerun_Results", "Heuristic_Results")
    if not os.path.exists(res_dir): os.makedirs(res_dir)
    
    files = sorted([f for f in os.listdir(data_dir) if (f.startswith('p') or f.startswith('pr')) and not f.endswith('.png')])
    
    summary = []
    
    print(f"=== 启动 MDVRP 启发式求解 (共{len(files)}题) ===")
    
    for f in files:
        path = os.path.join(data_dir, f)
        print(f"\n正在处理: {f}")
        try:
            instance = MDVRPInstance(path)
            instance.load()
            
            # 根据规模动态调整时间
            # 小规模给10秒，大规模给30-60秒足矣，因为SA收敛很快
            limit = 15 if instance.n <= 100 else 45
            if instance.n > 200: limit = 90
            
            solver = HeuristicSolver(instance)
            res = solver.solve(time_limit=limit)
            
            print(f"  > 结果: 距离 {res['obj']:.2f}, 车辆 {res['vehicles']}, 耗时 {res['time']:.2f}s")
            
            solver.visualize(os.path.join(res_dir, f"{f}_plot.png"))
            
            summary.append({
                'Instance': f,
                'Cost': res['obj'],
                'Vehicles': res['vehicles'],
                'Time': res['time']
            })
            
        except Exception as e:
            print(f"  > 出错: {e}")
            traceback.print_exc()

    # 保存汇总
    with open(os.path.join(res_dir, "Heuristic_Summary.txt"), 'w') as f:
        f.write(f"{'Instance':<15} {'Cost':<15} {'Vehicles':<10} {'Time':<10}\n")
        for s in summary:
            f.write(f"{s['Instance']:<15} {s['Cost']:<15.2f} {s['Vehicles']:<10} {s['Time']:<10.2f}\n")
    print("\n所有算例处理完成！")

if __name__ == "__main__":
    target_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "C-mdvrp")
    
    run_batch_heuristic(target_dir)
