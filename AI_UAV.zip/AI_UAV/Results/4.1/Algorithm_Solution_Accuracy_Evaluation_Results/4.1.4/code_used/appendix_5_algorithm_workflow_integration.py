#!/usr/bin/env python
"""Appendix integration for the historical 33-instance / 5-algorithm MDVRP run.

This script treats the five historical LLM-assisted algorithm programs as fixed
workflow assets, not as prompt prior knowledge.  The default mode does not rerun
the algorithms.  It validates that the source files are syntactically compilable,
parses their existing summary files, compares the full 33 Cordeau BKS records
when the .res directory is available, and writes an auditable workflow manifest
for appendix reporting.

Optional smoke execution is available through --run-smoke.  Smoke execution
copies one benchmark instance into a temporary output folder and calls the
registered batch function of selected assets, so the hard-coded __main__ paths in
the old scripts are not used.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import py_compile
import re
import shutil
import statistics
import sys
import time
import traceback
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


CODE_DIR = Path(__file__).resolve().parent
SECTION_DIR = CODE_DIR.parent
DEFAULT_HISTORICAL_ROOT = CODE_DIR / "algorithm_assets"
DEFAULT_OUTPUT_ROOT = Path("appendix_5_algorithm_workflow_outputs")
DEFAULT_DATA_DIR = SECTION_DIR / "benchmark_data" / "C-mdvrp"
DEFAULT_BKS_FILE = Path("")
DEFAULT_BKS_DIR = SECTION_DIR / "benchmark_data" / "C-mdvrp-sol"
BKS_DECIMAL_PLACES: Dict[str, int] = {}


@dataclass(frozen=True)
class AlgorithmAsset:
    algorithm_id: str
    display_name: str
    family: str
    script_name: str
    batch_function: str
    result_dir_name: str
    summary_name: str
    appendix_role: str


@dataclass
class SummaryRecord:
    algorithm_id: str
    algorithm_name: str
    instance: str
    cost: Optional[float]
    vehicles: Optional[int]
    time_seconds: Optional[float]
    valid_summary_solution: bool
    bks: Optional[float] = None
    gap_percent: Optional[float] = None
    below_bks_flag: bool = False
    needs_constraint_audit: bool = False


@dataclass
class RouteAuditRecord:
    algorithm_id: str
    algorithm_name: str
    instance: str
    rerun_ok: bool
    route_level_certified: bool
    objective: Optional[float]
    bks: Optional[float]
    gap_percent: Optional[float]
    route_count: int
    constraint_violations: str
    warning: str
    elapsed_seconds: Optional[float]
    solution_text_path: str
    error: str = ""


ASSETS: List[AlgorithmAsset] = [
    AlgorithmAsset(
        algorithm_id="gurobi_model",
        display_name="Gurobi direct model",
        family="exact_or_mip",
        script_name="Untitled-1.py",
        batch_function="run_batch",
        result_dir_name="Untitled-1：MDVRP_Results_Batch",
        summary_name="Summary.txt",
        appendix_role="Baseline exact-model attempt; useful for compile/run coverage and timeout discussion.",
    ),
    AlgorithmAsset(
        algorithm_id="alns",
        display_name="ALNS",
        family="metaheuristic",
        script_name="Untitled-2.py",
        batch_function="run_meta_heuristic",
        result_dir_name="Untitled-2：ALNS_Results",
        summary_name="ALNS_Summary.txt",
        appendix_role="Historical multi-turn LLM algorithm asset with full 33-instance coverage.",
    ),
    AlgorithmAsset(
        algorithm_id="constructive_sa",
        display_name="Constructive heuristic + SA",
        family="heuristic",
        script_name="Untitled-3.py",
        batch_function="run_batch_heuristic",
        result_dir_name="Untitled-3：Heuristic_Results",
        summary_name="Heuristic_Summary.txt",
        appendix_role="Fast constructive baseline for appendix robustness discussion.",
    ),
    AlgorithmAsset(
        algorithm_id="deep_alns",
        display_name="Deep ALNS",
        family="metaheuristic",
        script_name="Untitled-4.py",
        batch_function="run_deep_search",
        result_dir_name="Untitled-4：Deep_ALNS_Results",
        summary_name="Deep_Summary.txt",
        appendix_role="High-quality historical asset; must be discussed with constraint-audit caveat.",
    ),
    AlgorithmAsset(
        algorithm_id="turbo_alns",
        display_name="Turbo ALNS",
        family="metaheuristic",
        script_name="Untitled-5.py",
        batch_function="run_turbo_search",
        result_dir_name="Untitled-5：Turbo_ALNS_Results",
        summary_name="_Summary.txt",
        appendix_role="High-quality historical asset; below-BKS cases are negative evidence for feedback validation.",
    ),
]


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_float(value: str) -> Optional[float]:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def parse_int(value: str) -> Optional[int]:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def decimal_places_from_token(value: str) -> int:
    token = str(value).strip().split()[0]
    token = token.split("e", 1)[0].split("E", 1)[0]
    if "." not in token:
        return 0
    return len(token.rsplit(".", 1)[1])


def normalized_gap_percent(objective: Optional[float], bks: Optional[float], instance: str) -> Optional[float]:
    if objective is None or bks is None or bks <= 0:
        return None
    decimals = BKS_DECIMAL_PLACES.get(instance)
    if decimals is not None and f"{objective:.{decimals}f}" == f"{bks:.{decimals}f}":
        return 0.0
    return 100.0 * (objective - bks) / bks


def is_below_bks(objective: Optional[float], bks: Optional[float], instance: str, tolerance: float) -> bool:
    if objective is None or bks is None or bks <= 0:
        return False
    decimals = BKS_DECIMAL_PLACES.get(instance)
    if decimals is not None and f"{objective:.{decimals}f}" == f"{bks:.{decimals}f}":
        return False
    return objective < bks - tolerance


def compile_script(script_path: Path, cache_dir: Path) -> Tuple[bool, str]:
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha1(str(script_path).encode("utf-8")).hexdigest()[:10]
        cfile = cache_dir / f"{script_path.stem}_{digest}.pyc"
        py_compile.compile(str(script_path), cfile=str(cfile), doraise=True)
        return True, ""
    except Exception as exc:  # noqa: BLE001 - report exact compiler failure.
        return False, f"{type(exc).__name__}: {exc}"


def parse_summary_file(asset: AlgorithmAsset, summary_path: Path) -> List[SummaryRecord]:
    records: List[SummaryRecord] = []
    if not summary_path.exists():
        return records

    for raw_line in summary_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("-"):
            continue

        parts = re.split(r"\s+", line)
        if len(parts) < 3:
            continue
        if parts[0].lower() == "instance":
            continue
        if not re.match(r"^(p|pr)\d+$", parts[0], flags=re.IGNORECASE):
            continue

        instance = parts[0]
        cost = parse_float(parts[1])
        vehicles: Optional[int] = None
        time_seconds: Optional[float] = None
        if len(parts) >= 4:
            vehicles = parse_int(parts[2])
            time_seconds = parse_float(parts[3])
        else:
            time_seconds = parse_float(parts[2])

        records.append(
            SummaryRecord(
                algorithm_id=asset.algorithm_id,
                algorithm_name=asset.display_name,
                instance=instance,
                cost=cost,
                vehicles=vehicles,
                time_seconds=time_seconds,
                valid_summary_solution=cost is not None and cost > 0,
            )
        )
    return records


def parse_bks_file(path: Path) -> Dict[str, float]:
    if not path.exists():
        return {}

    bks: Dict[str, float] = {}
    current: Optional[str] = None
    inside_code_block = False
    waiting_for_value = False
    header_re = re.compile(r"^##\s+([A-Za-z0-9_-]+)\s+BKS", re.IGNORECASE)

    for raw_line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw_line.strip()
        header = header_re.match(line)
        if header:
            current = header.group(1)
            waiting_for_value = True
            inside_code_block = False
            continue

        if line.startswith("```"):
            inside_code_block = not inside_code_block
            continue

        if current and waiting_for_value and inside_code_block:
            token = line.split()[0] if line.split() else ""
            value = parse_float(token)
            if value is not None:
                bks[current] = value
                BKS_DECIMAL_PLACES[current] = decimal_places_from_token(token)
                current = None
                waiting_for_value = False

    return bks


def parse_bks_dir(path: Path) -> Dict[str, float]:
    """Parse Cordeau .res files whose first non-empty line is the BKS value."""
    if not path.exists():
        return {}

    bks: Dict[str, float] = {}
    for result_file in sorted(path.glob("*.res")):
        for raw_line in result_file.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw_line.strip()
            if not line:
                continue
            value = parse_float(line.split()[0])
            if value is not None:
                bks[result_file.stem] = value
                BKS_DECIMAL_PLACES[result_file.stem] = decimal_places_from_token(line.split()[0])
            break
    return bks


def load_bks_reference(bks_dir: Path, bks_file: Path) -> Dict[str, float]:
    """Prefer the complete benchmark .res directory; fall back to legacy Markdown."""
    bks = parse_bks_dir(bks_dir)
    if bks:
        return bks
    return parse_bks_file(bks_file)


def enrich_with_bks(records: List[SummaryRecord], bks: Dict[str, float], tolerance: float) -> None:
    for record in records:
        if record.cost is None or record.cost <= 0:
            continue
        value = bks.get(record.instance)
        if value is None or value <= 0:
            continue
        record.bks = value
        record.gap_percent = normalized_gap_percent(record.cost, value, record.instance)
        record.below_bks_flag = is_below_bks(record.cost, value, record.instance, tolerance)
        # A summary file alone cannot prove route feasibility.  Below-BKS values
        # are treated as audit triggers, not as superior solutions.
        record.needs_constraint_audit = record.below_bks_flag


def group_records(records: Iterable[SummaryRecord]) -> Dict[str, List[SummaryRecord]]:
    grouped: Dict[str, List[SummaryRecord]] = {}
    for record in records:
        grouped.setdefault(record.algorithm_id, []).append(record)
    return grouped


def mean(values: Sequence[float]) -> Optional[float]:
    return statistics.fmean(values) if values else None


def median(values: Sequence[float]) -> Optional[float]:
    return statistics.median(values) if values else None


def summarize_asset(asset: AlgorithmAsset, records: List[SummaryRecord], compile_ok: bool, compile_error: str) -> Dict[str, Any]:
    successful = [r for r in records if r.valid_summary_solution]
    with_bks = [r for r in records if r.gap_percent is not None]
    gaps = [r.gap_percent for r in with_bks if r.gap_percent is not None and not r.below_bks_flag]
    below_bks = [r for r in records if r.below_bks_flag]
    invalid = [r for r in records if not r.valid_summary_solution]
    cost_groups: Dict[str, List[str]] = {}
    for record in successful:
        if record.cost is not None:
            cost_groups.setdefault(f"{record.cost:.2f}", []).append(record.instance)
    repeated_cost_groups = {cost: instances for cost, instances in cost_groups.items() if len(instances) >= 3}
    total = len(records)
    return {
        "algorithm_id": asset.algorithm_id,
        "display_name": asset.display_name,
        "family": asset.family,
        "script_name": asset.script_name,
        "batch_function": asset.batch_function,
        "compile_ok": compile_ok,
        "compile_error": compile_error,
        "summary_records": total,
        "successful_summary_records": len(successful),
        "invalid_or_sentinel_records": len(invalid),
        "summary_success_rate": (len(successful) / total) if total else 0.0,
        "bks_comparable_records": len(with_bks),
        "below_bks_count": len(below_bks),
        "below_bks_instances": ",".join(r.instance for r in below_bks),
        "mean_gap_excluding_below_bks": mean(gaps),
        "median_gap_excluding_below_bks": median(gaps),
        "min_gap_excluding_below_bks": min(gaps) if gaps else None,
        "max_gap_excluding_below_bks": max(gaps) if gaps else None,
        "mean_cpu_seconds": mean([r.time_seconds for r in records if r.time_seconds is not None and r.time_seconds >= 0]),
        "repeated_cost_groups": json.dumps(repeated_cost_groups, ensure_ascii=False),
        "appendix_role": asset.appendix_role,
    }


def workflow_manifest(historical_root: Path, data_dir: Path, bks_dir: Path, bks_file: Path, assets: Sequence[AlgorithmAsset]) -> Dict[str, Any]:
    return {
        "integration_policy": {
            "recommended_role": "fixed_algorithm_asset_node",
            "not_recommended_role": "prompt_prior_knowledge_node",
            "reason": (
                "The five programs are concrete historical code artifacts from manual multi-turn "
                "Human-LLM interaction.  They should be executed and audited as tools.  Using them "
                "as prompt prior knowledge would leak implementation defects into generated code "
                "and would confound the main no-feedback versus feedback comparison."
            ),
        },
        "paths": {
            "historical_root": str(historical_root),
            "benchmark_data_dir": str(data_dir),
            "bks_res_dir_for_full_evaluation": str(bks_dir),
            "bks_file_for_hidden_evaluation": str(bks_file),
        },
        "nodes": [
            {
                "node_id": "historical_algorithm_registry",
                "node_type": "fixed_asset_registry",
                "output": "algorithm id, script path, callable batch function, historical result path",
            },
            {
                "node_id": "syntax_compilation_checker",
                "node_type": "static_validation",
                "input": "registered script paths",
                "output": "compile_ok, compile_error",
            },
            {
                "node_id": "existing_result_parser",
                "node_type": "result_extraction",
                "input": "historical summary files",
                "output": "long-format algorithm-instance-cost table marked as summary_only_uncertified",
            },
            {
                "node_id": "structured_algorithm_rerunner",
                "node_type": "fixed_asset_execution",
                "input": "algorithm asset, benchmark instance, runtime budget",
                "output": "raw algorithm result object",
            },
            {
                "node_id": "route_export_adapter",
                "node_type": "result_normalization",
                "input": "raw algorithm result object",
                "output": "controller-format route-level solution text",
            },
            {
                "node_id": "hidden_bks_evaluator",
                "node_type": "controller_only_evaluator",
                "input": "full 33-instance BKS reference set when available",
                "output": "gap and below-BKS audit flags",
            },
            {
                "node_id": "result_reverse_validation_audit",
                "node_type": "feedback_validation",
                "input": "controller-format route-level text, gap table, below-BKS flags, repeated-cost groups",
                "output": "route_level_certified result, invalid result, or human-audit caveat",
            },
            {
                "node_id": "appendix_report_writer",
                "node_type": "paper_evidence_packager",
                "output": "appendix tables, manifest, methodological interpretation",
            },
        ],
        "edges": [
            ["historical_algorithm_registry", "syntax_compilation_checker"],
            ["historical_algorithm_registry", "existing_result_parser"],
            ["historical_algorithm_registry", "structured_algorithm_rerunner"],
            ["structured_algorithm_rerunner", "route_export_adapter"],
            ["route_export_adapter", "result_reverse_validation_audit"],
            ["existing_result_parser", "hidden_bks_evaluator"],
            ["hidden_bks_evaluator", "result_reverse_validation_audit"],
            ["syntax_compilation_checker", "appendix_report_writer"],
            ["result_reverse_validation_audit", "appendix_report_writer"],
        ],
        "assets": [asdict(asset) for asset in assets],
    }


def write_records_csv(path: Path, records: Sequence[SummaryRecord]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "algorithm_id",
        "algorithm_name",
        "instance",
        "cost",
        "vehicles",
        "time_seconds",
        "valid_summary_solution",
        "bks",
        "gap_percent",
        "below_bks_flag",
        "needs_constraint_audit",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            writer.writerow(asdict(record))


def write_summary_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def summarize_route_audit(records: Sequence[RouteAuditRecord]) -> List[Dict[str, Any]]:
    grouped: Dict[str, List[RouteAuditRecord]] = {}
    for record in records:
        grouped.setdefault(record.algorithm_id, []).append(record)

    rows: List[Dict[str, Any]] = []
    for algorithm_id, items in grouped.items():
        certified = [r for r in items if r.route_level_certified]
        gaps = [r.gap_percent for r in certified if r.gap_percent is not None and r.gap_percent >= 0.0]
        negative = [r for r in certified if r.gap_percent is not None and r.gap_percent < 0.0]
        rows.append(
            {
                "algorithm_id": algorithm_id,
                "algorithm_name": items[0].algorithm_name if items else algorithm_id,
                "route_audit_records": len(items),
                "rerun_success_count": sum(1 for r in items if r.rerun_ok),
                "route_level_certified_count": len(certified),
                "route_level_certified_rate": (len(certified) / len(items)) if items else 0.0,
                "negative_gap_after_route_audit_count": len(negative),
                "mean_gap_certified_nonnegative": mean(gaps),
                "median_gap_certified_nonnegative": median(gaps),
                "mean_elapsed_seconds": mean([r.elapsed_seconds for r in items if r.elapsed_seconds is not None]),
            }
        )
    return rows


def format_pct(value: Optional[float]) -> str:
    if value is None:
        return "N/A"
    return f"{value:.2f}%"


def write_report(path: Path, summaries: Sequence[Dict[str, Any]], records: Sequence[SummaryRecord], bks: Dict[str, float]) -> None:
    lines: List[str] = []
    lines.append("# Appendix Workflow Integration: 33 Instances / 5 Algorithms")
    lines.append("")
    lines.append("## Methodological Position")
    lines.append("")
    lines.append(
        "The historical five algorithm programs should be integrated as fixed algorithm asset nodes, "
        "not as LLM prompt prior knowledge.  They are executable artifacts produced through prior "
        "manual Human-LLM interaction, so their scientific role is appendix evidence for algorithm "
        "expansion and for the necessity of feedback validation."
    )
    lines.append("")
    lines.append("Recommended paper use:")
    lines.append("")
    lines.append("- Main Section 4.3: keep the controlled structured_no_feedback vs structured comparison on the representative solver branch.")
    lines.append("- Section 4.1.4: report the 33-instance / 5-algorithm expansion as historical multi-algorithm workflow assets.")
    lines.append("- Constraint caveat: any result below BKS or repeated across structurally different instances is not treated as a better solution unless route-level feasibility is independently verified.")
    lines.append("")
    lines.append("## Asset Summary")
    lines.append("")
    lines.append("| Algorithm | Compile | Records | Valid summary | Invalid/sentinel | BKS comparable | Below-BKS flags | Mean gap* | Median gap* | Mean CPU/s |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for row in summaries:
        lines.append(
            "| {name} | {compile_ok} | {records} | {success_n} | {invalid_n} | {bks_n} | {below} | {mean_gap} | {median_gap} | {cpu} |".format(
                name=row["display_name"],
                compile_ok="yes" if row["compile_ok"] else "no",
                records=row["summary_records"],
                success_n=row["successful_summary_records"],
                invalid_n=row["invalid_or_sentinel_records"],
                bks_n=row["bks_comparable_records"],
                below=row["below_bks_count"],
                mean_gap=format_pct(row["mean_gap_excluding_below_bks"]),
                median_gap=format_pct(row["median_gap_excluding_below_bks"]),
                cpu="N/A" if row["mean_cpu_seconds"] is None else f"{row['mean_cpu_seconds']:.2f}",
            )
        )
    lines.append("")
    lines.append("*Gap statistics exclude below-BKS records because these are constraint-audit triggers, not validated improvements.")
    lines.append("")
    lines.append("## Below-BKS Audit Flags")
    lines.append("")
    flagged = [r for r in records if r.below_bks_flag]
    if not flagged:
        lines.append("No below-BKS records were found in the available BKS reference set.")
    else:
        lines.append("| Algorithm | Instance | Cost | BKS | Gap | Interpretation |")
        lines.append("|---|---:|---:|---:|---:|---|")
        for r in flagged:
            lines.append(
                f"| {r.algorithm_name} | {r.instance} | {r.cost:.2f} | {r.bks:.2f} | {r.gap_percent:.2f}% | requires route-level constraint audit |"
            )
    lines.append("")
    lines.append("## Repeated-Cost Audit Flags")
    lines.append("")
    repeated_rows = [row for row in summaries if row.get("repeated_cost_groups") not in {None, "", "{}"}]
    if not repeated_rows:
        lines.append("No repeated objective groups with at least three instances were found.")
    else:
        lines.append("| Algorithm | Repeated objective groups | Interpretation |")
        lines.append("|---|---|---|")
        for row in repeated_rows:
            lines.append(
                f"| {row['display_name']} | `{row['repeated_cost_groups']}` | requires route-level or rerun audit before objective comparison |"
            )
    lines.append("")
    lines.append("## Available BKS Reference Set")
    lines.append("")
    lines.append(", ".join(sorted(bks)) if bks else "No BKS values parsed.")
    lines.append("")
    lines.append("## Suggested Appendix Framing")
    lines.append("")
    lines.append(
        "These results should not replace the controlled 4.3 experiment.  They can be used to show "
        "that the workflow can register and invoke multiple algorithm assets, while also showing why "
        "feedback validation is necessary: strong-looking objective values may be invalid when the "
        "generated code omits or weakens constraints."
    )
    lines.append("")
    write_text(path, "\n".join(lines) + "\n")


def import_module_from_path(module_name: str, script_path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(module_name, script_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot create module spec for {script_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def load_controller_module() -> Any:
    controller_path = Path(__file__).with_name("mdvrp_structured_workflow_experiment.py")
    if not controller_path.exists():
        raise FileNotFoundError(f"Controller validator not found: {controller_path}")
    return import_module_from_path("appendix_controller_validator", controller_path)


def normalize_instance_list(value: str, data_dir: Path) -> List[str]:
    if value.strip().lower() in {"", "all"}:
        return sorted(p.name for p in data_dir.iterdir() if p.is_file() and re.match(r"^(p|pr)\d+$", p.name, flags=re.IGNORECASE))
    return [item.strip() for item in value.split(",") if item.strip()]


def internal_customer_id(node: Any, customer_ids: Sequence[int]) -> Optional[int]:
    try:
        idx = int(node)
    except Exception:
        return None
    if 0 <= idx < len(customer_ids):
        return customer_ids[idx]
    if idx in customer_ids:
        return idx
    return None


def depot_sequence(depot_value: Any, customer_count: int, depot_ids: Sequence[int]) -> Optional[int]:
    try:
        idx = int(depot_value)
    except Exception:
        return None
    if customer_count <= idx < customer_count + len(depot_ids):
        return idx - customer_count + 1
    if 0 <= idx < len(depot_ids):
        return idx + 1
    if idx in depot_ids:
        return depot_ids.index(idx) + 1
    return None


def route_entries_from_result(asset: AlgorithmAsset, result: Any) -> List[Dict[str, Any]]:
    if result is None:
        return []
    if asset.algorithm_id == "gurobi_model" and isinstance(result, dict):
        entries: List[Dict[str, Any]] = []
        for route in result.get("routes") or []:
            path = list(route.get("path") or [])
            if not path:
                continue
            depot = route.get("depot", path[0])
            # Gurobi returns internal paths as [home_depot, customer..., home_depot].
            # The controller exporter expects customer nodes only in path.
            customer_path = [node for node in path if node != depot]
            entries.append({"depot": depot, "path": customer_path})
        return entries
    if asset.algorithm_id == "turbo_alns" and hasattr(result, "routes"):
        entries: List[Dict[str, Any]] = []
        for depot, route_list in result.routes.items():
            for route in route_list:
                if len(route):
                    entries.append({"depot": depot, "path": list(route)})
        return entries
    if isinstance(result, dict):
        return list(result.get("routes") or [])
    return []


def build_controller_solution_text(instance_name: str, entries: Sequence[Dict[str, Any]], controller: Any, data_dir: Path) -> Tuple[str, float, int]:
    data = controller.load_cordeau_instance(data_dir / instance_name)
    route_lines: List[str] = []
    objective = 0.0
    route_id = 1
    customer_count = len(data.customer_ids)
    for entry in entries:
        depot_seq = depot_sequence(entry.get("depot"), customer_count, data.depot_ids)
        if depot_seq is None:
            continue
        depot_id = data.depot_ids[depot_seq - 1]
        raw_path = list(entry.get("path") or [])
        customers: List[int] = []
        for raw_node in raw_path:
            customer_id = internal_customer_id(raw_node, data.customer_ids)
            if customer_id is not None:
                customers.append(customer_id)
        if not customers:
            continue

        distance = 0.0
        previous = depot_id
        for customer in customers:
            distance += controller.euclidean(data, previous, customer)
            previous = customer
        distance += controller.euclidean(data, previous, depot_id)
        load = sum(data.customer_demand[c] for c in customers if c in data.customer_demand)
        objective += distance
        customer_text = " ".join(str(c) for c in customers)
        route_lines.append(f"{depot_seq} {route_id} {distance:.6f} {load:.6f} 0 {customer_text} 0")
        route_id += 1

    text = f"{objective:.6f}\n" + "\n".join(route_lines) + ("\n" if route_lines else "")
    return text, objective, len(route_lines)


def run_asset_for_route_audit(
    asset: AlgorithmAsset,
    module: Any,
    instance_path: Path,
    time_limit: float,
    deep_max_iters: int,
    turbo_max_iters: int,
) -> Any:
    if asset.algorithm_id == "gurobi_model":
        solver = module.MDVRPSolver(str(instance_path))
        solver.read_instance()
        return solver.solve(time_limit=time_limit)
    if asset.algorithm_id == "alns":
        inst = module.MDVRPInstance(str(instance_path))
        inst.load()
        solver = module.ALNSSolver(inst)
        return solver.solve(time_limit=time_limit)
    if asset.algorithm_id == "constructive_sa":
        inst = module.MDVRPInstance(str(instance_path))
        inst.load()
        solver = module.HeuristicSolver(inst)
        return solver.solve(time_limit=time_limit)
    if asset.algorithm_id == "deep_alns":
        inst = module.MDVRPInstance(str(instance_path))
        inst.load()
        solver = module.ALNSSolverDeep(inst)
        return solver.solve_deep_search(max_iters=deep_max_iters)
    if asset.algorithm_id == "turbo_alns":
        inst = module.MDVRPInstance(str(instance_path))
        inst.load()
        solver = module.ALNSTurboSolver(inst)
        _, best_solution = solver.solve(max_iters=turbo_max_iters, time_limit=time_limit)
        return best_solution
    raise ValueError(f"No route-audit adapter for {asset.algorithm_id}")


def run_route_level_audit(
    selected_assets: Sequence[AlgorithmAsset],
    historical_root: Path,
    data_dir: Path,
    output_root: Path,
    bks: Dict[str, float],
    instances: Sequence[str],
    time_limit: float,
    deep_max_iters: int,
    turbo_max_iters: int,
) -> List[RouteAuditRecord]:
    controller = load_controller_module()
    audit_root = output_root / "route_level_audit"
    audit_root.mkdir(parents=True, exist_ok=True)
    records: List[RouteAuditRecord] = []

    for asset in selected_assets:
        script_path = historical_root / asset.script_name
        try:
            module = import_module_from_path(f"appendix_route_audit_{asset.algorithm_id}", script_path)
        except Exception as exc:  # noqa: BLE001
            for instance in instances:
                records.append(
                    RouteAuditRecord(
                        algorithm_id=asset.algorithm_id,
                        algorithm_name=asset.display_name,
                        instance=instance,
                        rerun_ok=False,
                        route_level_certified=False,
                        objective=None,
                        bks=bks.get(instance),
                        gap_percent=None,
                        route_count=0,
                        constraint_violations="",
                        warning="module_import_failed",
                        elapsed_seconds=None,
                        solution_text_path="",
                        error=f"{type(exc).__name__}: {exc}",
                    )
                )
            continue

        for instance in instances:
            started = time.time()
            solution_text_path = audit_root / asset.algorithm_id / f"{instance}.sol.txt"
            try:
                instance_path = data_dir / instance
                result = run_asset_for_route_audit(asset, module, instance_path, time_limit, deep_max_iters, turbo_max_iters)
                entries = route_entries_from_result(asset, result)
                text, objective, route_count = build_controller_solution_text(instance, entries, controller, data_dir)
                write_text(solution_text_path, text)
                parsed = controller.parse_and_verify_solution_text(instance, text, "route_level_audit", str(solution_text_path), data_dir)
                value = bks.get(instance)
                gap = normalized_gap_percent(parsed.objective, value, instance)
                records.append(
                    RouteAuditRecord(
                        algorithm_id=asset.algorithm_id,
                        algorithm_name=asset.display_name,
                        instance=instance,
                        rerun_ok=route_count > 0,
                        route_level_certified=bool(parsed.parseable and not parsed.constraint_violations),
                        objective=parsed.objective or objective,
                        bks=value,
                        gap_percent=gap,
                        route_count=route_count,
                        constraint_violations=parsed.constraint_violations,
                        warning=parsed.warning,
                        elapsed_seconds=time.time() - started,
                        solution_text_path=str(solution_text_path),
                    )
                )
            except Exception as exc:  # noqa: BLE001
                records.append(
                    RouteAuditRecord(
                        algorithm_id=asset.algorithm_id,
                        algorithm_name=asset.display_name,
                        instance=instance,
                        rerun_ok=False,
                        route_level_certified=False,
                        objective=None,
                        bks=bks.get(instance),
                        gap_percent=None,
                        route_count=0,
                        constraint_violations="",
                        warning="rerun_failed",
                        elapsed_seconds=time.time() - started,
                        solution_text_path=str(solution_text_path),
                        error=f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}",
                    )
                )
    return records


def write_route_audit_csv(path: Path, records: Sequence[RouteAuditRecord]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(asdict(records[0]).keys()) if records else [field.name for field in RouteAuditRecord.__dataclass_fields__.values()]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            writer.writerow(asdict(record))


def run_smoke_assets(
    selected_assets: Sequence[AlgorithmAsset],
    historical_root: Path,
    data_dir: Path,
    output_root: Path,
    smoke_instance: str,
) -> List[Dict[str, Any]]:
    smoke_root = output_root / "smoke_runs"
    smoke_results: List[Dict[str, Any]] = []
    source_instance = data_dir / smoke_instance
    if not source_instance.exists():
        raise FileNotFoundError(f"Smoke instance not found: {source_instance}")

    for asset in selected_assets:
        work_dir = smoke_root / asset.algorithm_id
        work_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_instance, work_dir / smoke_instance)

        script_path = historical_root / asset.script_name
        started = time.time()
        result: Dict[str, Any] = {
            "algorithm_id": asset.algorithm_id,
            "display_name": asset.display_name,
            "script_path": str(script_path),
            "smoke_data_dir": str(work_dir),
            "smoke_instance": smoke_instance,
            "smoke_ok": False,
            "elapsed_seconds": None,
            "error": "",
        }
        try:
            module = import_module_from_path(f"appendix_smoke_{asset.algorithm_id}", script_path)
            fn = getattr(module, asset.batch_function)
            fn(str(work_dir))
            result["smoke_ok"] = True
        except Exception as exc:  # noqa: BLE001 - smoke report must preserve failure.
            result["error"] = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
        finally:
            result["elapsed_seconds"] = time.time() - started
        smoke_results.append(result)
    return smoke_results


def select_assets(asset_ids: str) -> List[AlgorithmAsset]:
    if asset_ids.strip().lower() in {"", "all"}:
        return list(ASSETS)
    wanted = {item.strip() for item in asset_ids.split(",") if item.strip()}
    found = [asset for asset in ASSETS if asset.algorithm_id in wanted]
    missing = sorted(wanted - {asset.algorithm_id for asset in found})
    if missing:
        raise ValueError(f"Unknown algorithm ids: {', '.join(missing)}")
    return found


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Integrate historical 33-instance / 5-algorithm MDVRP assets into the workflow evidence chain.")
    parser.add_argument("--historical-root", type=Path, default=DEFAULT_HISTORICAL_ROOT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("--bks-file", type=Path, default=DEFAULT_BKS_FILE)
    parser.add_argument("--bks-dir", type=Path, default=DEFAULT_BKS_DIR)
    parser.add_argument("--below-bks-tolerance", type=float, default=1e-4)
    parser.add_argument("--run-smoke", action="store_true", help="Optionally run selected assets on one copied instance.")
    parser.add_argument("--smoke-instance", default="p01")
    parser.add_argument("--smoke-algorithms", default="alns,constructive_sa,turbo_alns", help="Comma-separated asset ids or all. Gurobi may require a local license.")
    parser.add_argument("--run-route-audit", action="store_true", help="Rerun selected fixed algorithm assets and perform route-level reverse validation.")
    parser.add_argument("--audit-instances", default="p01", help="Comma-separated benchmark instances or all. Use all for 33-instance certification.")
    parser.add_argument("--audit-algorithms", default="all", help="Comma-separated asset ids or all.")
    parser.add_argument("--audit-time-limit", type=float, default=60.0)
    parser.add_argument("--deep-max-iters", type=int, default=5000)
    parser.add_argument("--turbo-max-iters", type=int, default=5000)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    historical_root: Path = args.historical_root
    output_root: Path = args.output_root
    data_dir: Path = args.data_dir
    bks_file: Path = args.bks_file
    bks_dir: Path = args.bks_dir

    output_root.mkdir(parents=True, exist_ok=True)
    bks = load_bks_reference(bks_dir, bks_file)
    all_records: List[SummaryRecord] = []
    summaries: List[Dict[str, Any]] = []

    for asset in ASSETS:
        script_path = historical_root / asset.script_name
        summary_path = historical_root / asset.result_dir_name / asset.summary_name
        compile_ok, compile_error = compile_script(script_path, output_root / "_compile_cache")
        records = parse_summary_file(asset, summary_path)
        enrich_with_bks(records, bks, args.below_bks_tolerance)
        all_records.extend(records)
        summaries.append(summarize_asset(asset, records, compile_ok, compile_error))

    manifest = workflow_manifest(historical_root, data_dir, bks_dir, bks_file, ASSETS)
    write_json(output_root / "workflow_asset_manifest.json", manifest)
    write_records_csv(output_root / "appendix_5_algorithm_results_long.csv", all_records)
    write_summary_csv(output_root / "appendix_5_algorithm_summary.csv", summaries)
    write_report(output_root / "appendix_5_algorithm_report.md", summaries, all_records, bks)

    if args.run_smoke:
        smoke_assets = select_assets(args.smoke_algorithms)
        smoke_results = run_smoke_assets(smoke_assets, historical_root, data_dir, output_root, args.smoke_instance)
        write_json(output_root / "smoke_run_results.json", smoke_results)

    if args.run_route_audit:
        audit_assets = select_assets(args.audit_algorithms)
        audit_instances = normalize_instance_list(args.audit_instances, data_dir)
        route_audit_records = run_route_level_audit(
            selected_assets=audit_assets,
            historical_root=historical_root,
            data_dir=data_dir,
            output_root=output_root,
            bks=bks,
            instances=audit_instances,
            time_limit=args.audit_time_limit,
            deep_max_iters=args.deep_max_iters,
            turbo_max_iters=args.turbo_max_iters,
        )
        write_route_audit_csv(output_root / "route_level_audit_results.csv", route_audit_records)
        write_summary_csv(output_root / "route_level_audit_summary.csv", summarize_route_audit(route_audit_records))

    print(f"[INFO] Manifest saved to: {output_root / 'workflow_asset_manifest.json'}")
    print(f"[INFO] Long results saved to: {output_root / 'appendix_5_algorithm_results_long.csv'}")
    print(f"[INFO] Summary saved to: {output_root / 'appendix_5_algorithm_summary.csv'}")
    print(f"[INFO] Report saved to: {output_root / 'appendix_5_algorithm_report.md'}")
    if args.run_smoke:
        print(f"[INFO] Smoke results saved to: {output_root / 'smoke_run_results.json'}")
    if args.run_route_audit:
        print(f"[INFO] Route-level audit saved to: {output_root / 'route_level_audit_results.csv'}")
        print(f"[INFO] Route-level audit summary saved to: {output_root / 'route_level_audit_summary.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
