#!/usr/bin/env python
"""Run and certify the five historical MDVRP algorithm assets on 33 instances.

The historical scripts are kept as algorithm assets.  This runner fixes the
trust boundary around them:

- it reads all pXX/prXX instances from the configured Cordeau directory;
- it calls the five algorithm assets through stable adapters;
- it exports every returned route into a single controller-readable format;
- it recomputes objective value, route load, route distance, and Gap;
- it certifies only route-level feasible solutions;
- it saves original summary screening results, certified results, rejected
  records, and compact statistics for paper tables/figures.

This script deliberately does not trust the original algorithm-reported cost.
For example, the Turbo ALNS asset can return a raw route distance even when its
internal penalty indicates infeasibility.  The certified objective reported by
this runner is always recomputed from exported routes and accepted only after
independent constraint validation.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict, List, Sequence

import appendix_5_algorithm_workflow_integration as wf


DEFAULT_PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_HISTORICAL_ROOT = DEFAULT_PACKAGE_ROOT / "benchmark_data"
DEFAULT_DATA_DIR = DEFAULT_HISTORICAL_ROOT / "C-mdvrp"
DEFAULT_BKS_DIR = DEFAULT_HISTORICAL_ROOT / "C-mdvrp-sol"
DEFAULT_OUTPUT_ROOT = Path("certified_5_algorithm_experiment")


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def list_instances(data_dir: Path, spec: str) -> List[str]:
    return wf.normalize_instance_list(spec, data_dir)


def parse_original_summaries(
    historical_root: Path,
    output_root: Path,
    bks: Dict[str, float],
    tolerance: float,
) -> List[Dict[str, Any]]:
    records: List[wf.SummaryRecord] = []
    summaries: List[Dict[str, Any]] = []
    for asset in wf.ASSETS:
        script_path = historical_root / asset.script_name
        compile_ok, compile_error = wf.compile_script(script_path, output_root / "_compile_cache")
        asset_records = wf.parse_summary_file(asset, historical_root / asset.result_dir_name / asset.summary_name)
        wf.enrich_with_bks(asset_records, bks, tolerance)
        records.extend(asset_records)
        summaries.append(wf.summarize_asset(asset, asset_records, compile_ok, compile_error))
    wf.write_records_csv(output_root / "original_summary_results.csv", records)
    wf.write_summary_csv(output_root / "original_summary_algorithm_stats.csv", summaries)
    return summaries


def route_audit_rows(records: Sequence[wf.RouteAuditRecord]) -> List[Dict[str, Any]]:
    return [vars(record).copy() for record in records]


def certified_performance_rows(records: Sequence[wf.RouteAuditRecord]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for record in records:
        if not record.route_level_certified:
            continue
        rows.append(
            {
                "algorithm_id": record.algorithm_id,
                "algorithm_name": record.algorithm_name,
                "instance": record.instance,
                "certified_objective": record.objective,
                "bks": record.bks,
                "gap_percent": record.gap_percent,
                "route_count": record.route_count,
                "elapsed_seconds": record.elapsed_seconds,
                "solution_text_path": record.solution_text_path,
            }
        )
    return rows


def rejected_rows(records: Sequence[wf.RouteAuditRecord]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for record in records:
        if record.route_level_certified:
            continue
        reason_parts = [record.warning, record.constraint_violations, record.error]
        reason = " | ".join(x for x in reason_parts if str(x).strip())
        rows.append(
            {
                "algorithm_id": record.algorithm_id,
                "algorithm_name": record.algorithm_name,
                "instance": record.instance,
                "rerun_ok": record.rerun_ok,
                "objective": record.objective,
                "bks": record.bks,
                "gap_percent": record.gap_percent,
                "route_count": record.route_count,
                "rejection_reason": reason,
                "solution_text_path": record.solution_text_path,
            }
        )
    return rows


def draw_basic_figures(output_root: Path, certified_rows: Sequence[Dict[str, Any]], summary_rows: Sequence[Dict[str, Any]]) -> None:
    try:
        import matplotlib.pyplot as plt
    except Exception as exc:  # noqa: BLE001
        write_json(output_root / "figure_generation_warning.json", {"warning": f"matplotlib unavailable: {exc}"})
        return

    if certified_rows:
        x = [row["elapsed_seconds"] or 0 for row in certified_rows]
        y = [row["gap_percent"] for row in certified_rows]
        labels = [row["algorithm_id"] for row in certified_rows]
        plt.figure(figsize=(8, 5))
        for algorithm in sorted(set(labels)):
            xs = [x[i] for i, label in enumerate(labels) if label == algorithm]
            ys = [y[i] for i, label in enumerate(labels) if label == algorithm]
            plt.scatter(xs, ys, label=algorithm, alpha=0.75)
        plt.xlabel("Elapsed seconds")
        plt.ylabel("Certified Gap (%)")
        plt.title("Certified Gap vs CPU")
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(output_root / "certified_gap_cpu_scatter.png", dpi=200)
        plt.close()

    if summary_rows:
        names = [row["algorithm_id"] for row in summary_rows]
        rates = [float(row["route_level_certified_rate"]) * 100 for row in summary_rows]
        plt.figure(figsize=(8, 4))
        plt.bar(names, rates)
        plt.ylabel("Certified rate (%)")
        plt.title("Route-Level Certification Rate")
        plt.ylim(0, 105)
        plt.xticks(rotation=20, ha="right")
        plt.tight_layout()
        plt.savefig(output_root / "certification_rate_by_algorithm.png", dpi=200)
        plt.close()


def write_report(output_root: Path, config: Dict[str, Any], original_stats: Sequence[Dict[str, Any]], route_summary: Sequence[Dict[str, Any]]) -> None:
    lines: List[str] = []
    lines.append("# Certified 5-Algorithm MDVRP Experiment")
    lines.append("")
    lines.append("## Configuration")
    lines.append("")
    for key, value in config.items():
        lines.append(f"- {key}: `{value}`")
    lines.append("")
    lines.append("## Original Summary Screening")
    lines.append("")
    lines.append("| Algorithm | Summary records | Successful summaries | Invalid/sentinel | Below-BKS flags | Mean Gap* | Median Gap* |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|")
    for row in original_stats:
        lines.append(
            "| {algorithm_id} | {summary_records} | {successful_summary_records} | {invalid_or_sentinel_records} | {below_bks_count} | {mean_gap} | {median_gap} |".format(
                algorithm_id=row["algorithm_id"],
                summary_records=row["summary_records"],
                successful_summary_records=row["successful_summary_records"],
                invalid_or_sentinel_records=row["invalid_or_sentinel_records"],
                below_bks_count=row["below_bks_count"],
                mean_gap="N/A" if row["mean_gap_excluding_below_bks"] is None else f"{row['mean_gap_excluding_below_bks']:.4f}",
                median_gap="N/A" if row["median_gap_excluding_below_bks"] is None else f"{row['median_gap_excluding_below_bks']:.4f}",
            )
        )
    lines.append("")
    lines.append("*Original summary Gap values are screening values only. Certified statistics below are based on route-level validation.")
    lines.append("")
    lines.append("## Route-Level Certified Statistics")
    lines.append("")
    lines.append("| Algorithm | Audit records | Rerun success | Certified | Certified rate | Negative certified Gap | Mean certified Gap | Median certified Gap | Mean elapsed seconds |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    for row in route_summary:
        lines.append(
            "| {algorithm_id} | {route_audit_records} | {rerun_success_count} | {route_level_certified_count} | {rate:.2%} | {negative_gap_after_route_audit_count} | {mean_gap} | {median_gap} | {elapsed} |".format(
                algorithm_id=row["algorithm_id"],
                route_audit_records=row["route_audit_records"],
                rerun_success_count=row["rerun_success_count"],
                route_level_certified_count=row["route_level_certified_count"],
                rate=float(row["route_level_certified_rate"]),
                negative_gap_after_route_audit_count=row["negative_gap_after_route_audit_count"],
                mean_gap="N/A" if row["mean_gap_certified_nonnegative"] is None else f"{row['mean_gap_certified_nonnegative']:.4f}",
                median_gap="N/A" if row["median_gap_certified_nonnegative"] is None else f"{row['median_gap_certified_nonnegative']:.4f}",
                elapsed="N/A" if row["mean_elapsed_seconds"] is None else f"{row['mean_elapsed_seconds']:.4f}",
            )
        )
    lines.append("")
    lines.append("Certified results are accepted only after independent customer-coverage, duplicate-service, vehicle-count, capacity, route-duration, route-distance, and objective-consistency checks.")
    (output_root / "certified_experiment_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run five MDVRP algorithm assets and compute certified route-level statistics.")
    parser.add_argument("--historical-root", type=Path, default=DEFAULT_HISTORICAL_ROOT)
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("--bks-dir", type=Path, default=DEFAULT_BKS_DIR)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--instances", default="all", help="Comma-separated instances or all.")
    parser.add_argument("--algorithms", default="all", help="Comma-separated algorithm ids or all.")
    parser.add_argument("--time-limit", type=float, default=60.0)
    parser.add_argument("--deep-max-iters", type=int, default=5000)
    parser.add_argument("--turbo-max-iters", type=int, default=5000)
    parser.add_argument("--below-bks-tolerance", type=float, default=1e-4)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output_root: Path = args.output_root
    output_root.mkdir(parents=True, exist_ok=True)

    bks = wf.load_bks_reference(args.bks_dir, Path(""))
    instances = list_instances(args.data_dir, args.instances)
    assets = wf.select_assets(args.algorithms)

    config = {
        "historical_root": str(args.historical_root),
        "data_dir": str(args.data_dir),
        "bks_dir": str(args.bks_dir),
        "output_root": str(output_root),
        "instances": ",".join(instances),
        "algorithms": ",".join(asset.algorithm_id for asset in assets),
        "time_limit": args.time_limit,
        "deep_max_iters": args.deep_max_iters,
        "turbo_max_iters": args.turbo_max_iters,
    }
    write_json(output_root / "experiment_config.json", config)

    original_stats = parse_original_summaries(args.historical_root, output_root, bks, args.below_bks_tolerance)

    route_records = wf.run_route_level_audit(
        selected_assets=assets,
        historical_root=args.historical_root,
        data_dir=args.data_dir,
        output_root=output_root,
        bks=bks,
        instances=instances,
        time_limit=args.time_limit,
        deep_max_iters=args.deep_max_iters,
        turbo_max_iters=args.turbo_max_iters,
    )

    route_rows = route_audit_rows(route_records)
    certified_rows = certified_performance_rows(route_records)
    rejected = rejected_rows(route_records)
    route_summary = wf.summarize_route_audit(route_records)

    write_csv(output_root / "route_level_audit_results.csv", route_rows)
    write_csv(output_root / "certified_solution_results.csv", certified_rows)
    write_csv(output_root / "uncertified_or_rejected_results.csv", rejected)
    write_csv(output_root / "certified_algorithm_statistics.csv", route_summary)
    draw_basic_figures(output_root, certified_rows, route_summary)
    write_report(output_root, config, original_stats, route_summary)

    print(f"[INFO] Output root: {output_root}")
    print(f"[INFO] Certified results: {output_root / 'certified_solution_results.csv'}")
    print(f"[INFO] Rejected results: {output_root / 'uncertified_or_rejected_results.csv'}")
    print(f"[INFO] Certified statistics: {output_root / 'certified_algorithm_statistics.csv'}")
    print(f"[INFO] Report: {output_root / 'certified_experiment_report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
