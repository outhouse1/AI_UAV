#!/usr/bin/env python
"""Build five MDVRP algorithm assets through a workflow-compatible pipeline.

This script is the reproducible bridge between the paper narrative and the
historical five-algorithm artifacts:

1. It reads an AI-KM .flow file and extracts structured workflow context.
2. It defines five progressive algorithm-generation stages.
3. In replay mode, it registers the already generated historical code artifacts
   as the outputs of those stages.  This is the correct mode for documenting
   prior manual Human-LLM interaction without pretending that new API calls were
   made today.
4. In generate mode, it calls the DeepSeek-compatible API for every stage and
   applies compile-error feedback repair.
5. In hybrid mode, it first tries generation and falls back to the historical
   artifact when generation cannot produce compilable code.

The generated/replayed assets are intentionally separate from final numerical
validation.  Run appendix_5_algorithm_workflow_integration.py with
--run-route-audit to certify route-level results.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import py_compile
import shutil
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import mdvrp_structured_workflow_experiment as workflow_core


DEFAULT_FLOW_FILE = Path("FK_Workflow_2026-06-02-14-00-11.flow")
CODE_DIR = Path(__file__).resolve().parent
DEFAULT_HISTORICAL_ROOT = CODE_DIR / "algorithm_assets"
DEFAULT_OUTPUT_ROOT = Path("multi_stage_algorithm_assets")


@dataclass(frozen=True)
class AlgorithmStage:
    stage_index: int
    algorithm_id: str
    display_name: str
    family: str
    historical_script_name: str
    output_script_name: str
    capability_goal: str
    generation_instruction: str


@dataclass
class StageBuildRecord:
    stage_index: int
    algorithm_id: str
    display_name: str
    build_mode: str
    source: str
    script_path: str
    prompt_path: str
    response_path: str
    compile_ok: bool
    compile_error: str
    feedback_rounds_used: int
    sha256: str
    elapsed_seconds: float
    note: str = ""


STAGES: List[AlgorithmStage] = [
    AlgorithmStage(
        stage_index=1,
        algorithm_id="gurobi_model",
        display_name="Gurobi direct model",
        family="exact_or_mip",
        historical_script_name="Untitled-1.py",
        output_script_name="01_gurobi_direct_model.py",
        capability_goal="Generate a direct mathematical-programming solver and expose solver-call failures.",
        generation_instruction=(
            "Generate a Python MDVRP solver based on a direct Gurobi mathematical model. "
            "The code must parse Cordeau MDVRP instances, model customer assignment, "
            "vehicle capacity, depot assignment, route duration when available, and route reconstruction."
        ),
    ),
    AlgorithmStage(
        stage_index=2,
        algorithm_id="alns",
        display_name="ALNS",
        family="metaheuristic",
        historical_script_name="Untitled-2.py",
        output_script_name="02_alns.py",
        capability_goal="Generate a stable adaptive large-neighborhood search solver.",
        generation_instruction=(
            "Generate an Adaptive Large Neighborhood Search solver with destroy and repair operators, "
            "simulated-annealing acceptance, capacity and duration checks, and route-level output."
        ),
    ),
    AlgorithmStage(
        stage_index=3,
        algorithm_id="constructive_sa",
        display_name="Constructive heuristic + SA",
        family="heuristic",
        historical_script_name="Untitled-3.py",
        output_script_name="03_constructive_sa.py",
        capability_goal="Generate a fast constructive baseline with local improvement.",
        generation_instruction=(
            "Generate a fast constructive heuristic that assigns customers to depots, packs feasible routes, "
            "and improves routes with simple simulated annealing or local search."
        ),
    ),
    AlgorithmStage(
        stage_index=4,
        algorithm_id="deep_alns",
        display_name="Deep ALNS",
        family="metaheuristic",
        historical_script_name="Untitled-4.py",
        output_script_name="04_deep_alns.py",
        capability_goal="Extend ALNS with deeper search and stronger repair operators.",
        generation_instruction=(
            "Generate an enhanced ALNS solver with stronger destroy/repair operators, deeper iteration budget, "
            "stagnation control, and explicit feasible-solution export."
        ),
    ),
    AlgorithmStage(
        stage_index=5,
        algorithm_id="turbo_alns",
        display_name="Turbo ALNS",
        family="metaheuristic",
        historical_script_name="Untitled-5.py",
        output_script_name="05_turbo_alns.py",
        capability_goal="Generate a faster ALNS variant while preserving controller-side auditability.",
        generation_instruction=(
            "Generate a computationally optimized ALNS variant.  Do not hide constraint violations behind raw "
            "distance values; any acceptance and final summary must use the same feasibility-aware objective."
        ),
    ),
]


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def compile_python(script_path: Path, cache_dir: Path) -> Tuple[bool, str]:
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        py_compile.compile(str(script_path), cfile=str(cache_dir / f"{script_path.stem}.pyc"), doraise=True)
        return True, ""
    except Exception as exc:  # noqa: BLE001 - build records must preserve failure.
        return False, f"{type(exc).__name__}: {exc}"


def compact_workflow_context(profile: workflow_core.FlowProfile, max_chars: int = 14000) -> str:
    parts: List[str] = []
    for node in profile.algorithm_prior_nodes():
        node_id = node.get("id", "")
        label = str(node.get("name", node_id))
        text = profile.node_text(node).strip()
        if text:
            parts.append(f"[Node {node_id}: {label}]\n{text}")

    for needle in ("MDVRP", "算法", "先验", "反馈", "校验", "约束"):
        for node in profile.find_nodes(name_contains=needle):
            node_id = node.get("id", "")
            label = str(node.get("name", node_id))
            text = profile.node_text(node).strip()
            if text:
                item = f"[Node {node_id}: {label}]\n{text}"
                if item not in parts:
                    parts.append(item)

    context = "\n\n".join(parts)
    return context[:max_chars]


def build_generation_prompt(stage: AlgorithmStage, profile: workflow_core.FlowProfile, previous_records: Sequence[StageBuildRecord]) -> str:
    context = compact_workflow_context(profile)
    previous = "\n".join(
        f"- Stage {r.stage_index} {r.display_name}: compile_ok={r.compile_ok}, source={r.source}, note={r.note}"
        for r in previous_records
    )
    return f"""You are generating one algorithm asset inside a structured Human-LLM workflow for MDVRP.

Workflow context:
{context}

Previous algorithm asset stages:
{previous if previous else "(none)"}

Current stage:
- stage_index: {stage.stage_index}
- algorithm_id: {stage.algorithm_id}
- display_name: {stage.display_name}
- family: {stage.family}
- capability_goal: {stage.capability_goal}

Generation instruction:
{stage.generation_instruction}

Hard requirements:
1. Output one complete Python file only.
2. The code must parse Cordeau MDVRP instance files directly.
3. The code must include a callable function solve_mdvrp_instance(instance_path: str, time_limit: float = 60.0) -> dict.
4. The returned dict must include: obj, routes, vehicles, time.
5. routes must be a list of dictionaries with depot and path fields. path must contain customer ids or zero-based customer indices.
6. The solver must not read BKS or .res solution files.
7. Do not report a raw distance as the final objective if the route is infeasible. Either repair infeasibility or return obj=-1 with diagnostic information.
8. Keep dependencies limited to Python standard library plus numpy/matplotlib; gurobipy is allowed only for the Gurobi stage and must have a fallback when unavailable.
"""


def build_repair_prompt(stage: AlgorithmStage, previous_prompt: str, previous_code: str, compile_error: str) -> str:
    return f"""Repair the generated Python code for stage {stage.algorithm_id}.

Original generation prompt:
{previous_prompt[:10000]}

Compiler error:
{compile_error}

Previous code:
```python
{previous_code[:18000]}
```

Return one complete corrected Python file only. Preserve the required solve_mdvrp_instance contract.
"""


def call_llm(client: workflow_core.DeepSeekClient, prompt: str, model: str) -> str:
    response = client.chat(
        messages=[
            {"role": "system", "content": "You generate robust, auditable Python optimization code."},
            {"role": "user", "content": prompt},
        ],
        model=model,
    )
    return workflow_core.extract_python_code(response)


def replay_stage(stage: AlgorithmStage, historical_root: Path, stage_dir: Path, cache_dir: Path, mode: str, prompt: str) -> StageBuildRecord:
    started = time.time()
    src = historical_root / stage.historical_script_name
    dst = stage_dir / stage.output_script_name
    if not src.exists():
        raise FileNotFoundError(f"Historical script not found: {src}")
    shutil.copy2(src, dst)
    prompt_path = stage_dir / "workflow_generation_prompt.txt"
    response_path = stage_dir / "replay_source_note.txt"
    write_text(prompt_path, prompt)
    write_text(
        response_path,
        "Replay mode: this file was registered as the historical output of the multi-stage Human-LLM workflow.\n"
        f"Source script: {src}\n",
    )
    compile_ok, compile_error = compile_python(dst, cache_dir)
    return StageBuildRecord(
        stage_index=stage.stage_index,
        algorithm_id=stage.algorithm_id,
        display_name=stage.display_name,
        build_mode=mode,
        source="historical_replay",
        script_path=str(dst),
        prompt_path=str(prompt_path),
        response_path=str(response_path),
        compile_ok=compile_ok,
        compile_error=compile_error,
        feedback_rounds_used=0,
        sha256=sha256_file(dst),
        elapsed_seconds=time.time() - started,
        note="Historical artifact replayed as fixed workflow output.",
    )


def generate_stage(
    stage: AlgorithmStage,
    stage_dir: Path,
    cache_dir: Path,
    client: workflow_core.DeepSeekClient,
    model: str,
    prompt: str,
    max_feedback_rounds: int,
) -> StageBuildRecord:
    started = time.time()
    script_path = stage_dir / stage.output_script_name
    prompt_path = stage_dir / "workflow_generation_prompt.txt"
    response_path = stage_dir / "llm_response_initial.py"
    write_text(prompt_path, prompt)
    code = call_llm(client, prompt, model)
    write_text(response_path, code)
    write_text(script_path, code)
    compile_ok, compile_error = compile_python(script_path, cache_dir)
    feedback_used = 0

    while not compile_ok and feedback_used < max_feedback_rounds:
        feedback_used += 1
        repair_prompt = build_repair_prompt(stage, prompt, read_text(script_path), compile_error)
        repair_prompt_path = stage_dir / f"workflow_feedback_prompt_{feedback_used}.txt"
        repair_response_path = stage_dir / f"llm_response_feedback_{feedback_used}.py"
        write_text(repair_prompt_path, repair_prompt)
        repaired = call_llm(client, repair_prompt, model)
        write_text(repair_response_path, repaired)
        write_text(script_path, repaired)
        compile_ok, compile_error = compile_python(script_path, cache_dir)

    return StageBuildRecord(
        stage_index=stage.stage_index,
        algorithm_id=stage.algorithm_id,
        display_name=stage.display_name,
        build_mode="generate",
        source="llm_generated",
        script_path=str(script_path),
        prompt_path=str(prompt_path),
        response_path=str(response_path),
        compile_ok=compile_ok,
        compile_error=compile_error,
        feedback_rounds_used=feedback_used,
        sha256=sha256_file(script_path) if script_path.exists() else "",
        elapsed_seconds=time.time() - started,
        note="Generated through API calls and compile-feedback repair.",
    )


def write_manifest(output_root: Path, flow_file: Path, mode: str, records: Sequence[StageBuildRecord]) -> None:
    payload: Dict[str, Any] = {
        "purpose": "Five algorithm assets generated or replayed through a structured workflow-compatible pipeline.",
        "mode": mode,
        "flow_file": str(flow_file),
        "important_caveat": (
            "Replay mode documents historical Human-LLM interaction artifacts as workflow outputs. "
            "It does not claim that the current run newly called the API. Generate mode performs new API calls."
        ),
        "downstream_validation": (
            "Run appendix_5_algorithm_workflow_integration.py --run-route-audit before using any asset output "
            "as numerical evidence."
        ),
        "stages": [asdict(stage) for stage in STAGES],
        "build_records": [asdict(record) for record in records],
    }
    write_text(output_root / "algorithm_asset_generation_manifest.json", json.dumps(payload, ensure_ascii=False, indent=2))


def write_records_csv(output_root: Path, records: Sequence[StageBuildRecord]) -> None:
    path = output_root / "algorithm_asset_build_records.csv"
    fieldnames = list(asdict(records[0]).keys()) if records else list(StageBuildRecord.__dataclass_fields__.keys())
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            writer.writerow(asdict(record))


def select_stage_ids(value: str) -> List[AlgorithmStage]:
    if value.strip().lower() in {"", "all"}:
        return list(STAGES)
    wanted = {x.strip() for x in value.split(",") if x.strip()}
    selected = [stage for stage in STAGES if stage.algorithm_id in wanted]
    missing = wanted - {stage.algorithm_id for stage in selected}
    if missing:
        raise ValueError(f"Unknown stage ids: {', '.join(sorted(missing))}")
    return selected


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build five MDVRP algorithm assets through a workflow-compatible multi-stage pipeline.")
    parser.add_argument("--flow-file", type=Path, default=DEFAULT_FLOW_FILE)
    parser.add_argument("--historical-root", type=Path, default=DEFAULT_HISTORICAL_ROOT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--mode", choices=["replay", "generate", "hybrid"], default="replay")
    parser.add_argument("--stages", default="all", help="Comma-separated stage ids or all.")
    parser.add_argument("--max-feedback-rounds", type=int, default=2)
    parser.add_argument("--api-key", default="")
    parser.add_argument("--api-url", default=workflow_core.DEEPSEEK_API_URL)
    parser.add_argument("--model", default=workflow_core.DEFAULT_DEEPSEEK_MODEL)
    parser.add_argument("--api-timeout", type=int, default=180)
    parser.add_argument("--api-retries", type=int, default=2)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output_root: Path = args.output_root
    output_root.mkdir(parents=True, exist_ok=True)
    cache_dir = output_root / "_compile_cache"

    flow_file = args.flow_file.resolve()
    if not flow_file.exists():
        print(f"[ERROR] Flow file not found: {flow_file}", file=sys.stderr)
        return 2
    profile = workflow_core.FlowProfile(flow_file)
    selected_stages = select_stage_ids(args.stages)

    api_key = args.api_key or os.environ.get("DEEPSEEK_API_KEY", "") or workflow_core.DEEPSEEK_API_KEY
    client = workflow_core.DeepSeekClient(
        workflow_core.LLMConfig(
            api_key=api_key,
            api_url=args.api_url,
            model=args.model,
            timeout=args.api_timeout,
            retries=args.api_retries,
        ),
        dry_run=args.dry_run,
    )

    records: List[StageBuildRecord] = []
    for stage in selected_stages:
        stage_dir = output_root / f"{stage.stage_index:02d}_{stage.algorithm_id}"
        stage_dir.mkdir(parents=True, exist_ok=True)
        prompt = build_generation_prompt(stage, profile, records)

        if args.mode == "replay":
            record = replay_stage(stage, args.historical_root, stage_dir, cache_dir, args.mode, prompt)
        elif args.mode == "generate":
            record = generate_stage(stage, stage_dir, cache_dir, client, args.model, prompt, args.max_feedback_rounds)
        else:
            record = generate_stage(stage, stage_dir, cache_dir, client, args.model, prompt, args.max_feedback_rounds)
            if not record.compile_ok:
                fallback = replay_stage(stage, args.historical_root, stage_dir, cache_dir, args.mode, prompt)
                fallback.note = f"LLM generation failed compile; fallback replay used. Original error: {record.compile_error[:500]}"
                record = fallback

        records.append(record)
        print(
            f"[INFO] Stage {stage.stage_index} {stage.algorithm_id}: "
            f"source={record.source}, compile_ok={record.compile_ok}, script={record.script_path}"
        )

    write_records_csv(output_root, records)
    write_manifest(output_root, flow_file, args.mode, records)
    print(f"[INFO] Build records saved to: {output_root / 'algorithm_asset_build_records.csv'}")
    print(f"[INFO] Manifest saved to: {output_root / 'algorithm_asset_generation_manifest.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
