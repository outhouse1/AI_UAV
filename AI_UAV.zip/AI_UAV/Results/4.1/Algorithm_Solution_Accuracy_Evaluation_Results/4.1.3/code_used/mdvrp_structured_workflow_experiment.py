#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Structured workflow experiment runner for LLM-generated MDVRP solvers.

Purpose
-------
This script converts an AI-KM .flow workflow into a reproducible Python-side
experiment controller. It is designed for the experiment section:
"Effect of structured interactive workflow on algorithm generation and solving
performance".

What it does
------------
1. Loads the uploaded .flow file and reuses its node prompts, upstream contexts,
   mathematical-model output, algorithm prior knowledge, decision prompt, and
   feedback prompt.
2. Calls a DeepSeek-compatible chat API to generate a complete Python solver.
3. Executes the generated solver on selected Cordeau MDVRP instances.
4. Deterministically checks whether route-level results are parseable.
5. If execution fails or results are not parseable, triggers a feedback-repair
   LLM node and reruns the corrected solver.
6. Optionally runs an autonomous quality-enhancement module. This module uses BKS
   only as a hidden evaluator in the controller; BKS values are not passed to the
   generated solver, and the generated solver is instructed not to read BKS/.res.
7. Supports multiple rounds and multiple experiment modes for ablation tests.

Before running
--------------
Set an environment variable or pass --api-key:
    set DEEPSEEK_API_KEY=<your_api_key>

Typical command
---------------
python mdvrp_structured_workflow_experiment.py ^
  --flow-file FK1_Workflow_2026-06-02-14-24-36.flow ^
  --instances-dir ..\\..\\..\\..\\date\\6-mdvrp ^
  --bks-file ..\\..\\..\\..\\date\\mdvrp-sol-BKS.md ^
  --rounds 20 ^
  --algorithms exact ^
  --modes structured_no_feedback,structured ^
  --solver-time-limit 180 ^
  --execution-timeout 300

Node-ablation example
---------------------
python mdvrp_structured_workflow_experiment.py ^
  --rounds 10 ^
  --algorithms exact ^
  --modes structured,ablation_no_prior ^
  --disable-nodes 50

Notes
-----
- The generated solver is executed as a local subprocess. Use a clean experiment
  directory and inspect generated code if needed.
- Gurobi is optional for the generated solver. The workflow prompt requires a
  fallback feasible constructive/heuristic solution if Gurobi is unavailable.
- The controller reads BKS only for evaluation and optional hidden quality
  feedback. The solver should never read BKS or .res files.
"""

from __future__ import annotations

import argparse
import csv
import datetime as _dt
import json
import math
import os
import py_compile
import re
import shutil
import subprocess
import sys
import textwrap
import time
import traceback
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

# =========================
# 1. API CONFIGURATION AREA
# =========================
# Prefer the environment variable DEEPSEEK_API_KEY or the --api-key option.
DEEPSEEK_API_KEY = ""

# DeepSeek currently supports an OpenAI-compatible chat-completions style API.
# Keep this configurable in case your local proxy or platform endpoint differs.
DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions"

# If empty, the model name stored in the .flow reasoning node is used.
# You may change this to your actual available DeepSeek model name.
DEFAULT_DEEPSEEK_MODEL = "deepseek-v4-flash"

DEFAULT_FLOW_FILE = "FK1_Workflow_2026-06-02-14-24-36.flow"
DEFAULT_ALGORITHMS = "exact"

ALGORITHM_NODE_KEYWORDS = {
    "exact": ("Exact Algorithm Model Solving", "Restricted Route-Pool"),
}

ALGORITHM_FEEDBACK_KEYWORDS = {
    "exact": ("Exact Feedback Reasoning",),
}

ALGORITHM_LABELS = {
    "exact": "A1_gurobi_restricted_route_pool",
}

WAITING_MARKERS = (
    "waiting",
    "waiting for",
    "waiting_",
    "running",
    "node_skipped",
    "please enter",
)


# =========================
# 2. DATA STRUCTURES
# =========================
@dataclass
class LLMConfig:
    api_key: str
    api_url: str = DEEPSEEK_API_URL
    model: str = ""
    temperature: float = 0.2
    max_tokens: int = 16384
    timeout: int = 180
    retries: int = 2


@dataclass
class ParsedSolution:
    instance: str
    objective: Optional[float]
    route_count: int
    parseable: bool
    source: str
    raw_text_path: str = ""
    warning: str = ""
    constraint_violations: str = ""


@dataclass
class CordeauInstance:
    name: str
    vehicles_per_depot: int
    customer_ids: List[int]
    depot_ids: List[int]
    customer_demand: Dict[int, float]
    service_time: Dict[int, float]
    coordinates: Dict[int, Tuple[float, float]]
    max_route_duration: List[float]
    vehicle_capacity: List[float]


@dataclass
class ExecutionOutcome:
    return_code: int
    stdout: str
    stderr: str
    timeout: bool
    elapsed_sec: float
    code_path: str
    stdout_path: str
    stderr_path: str
    compile_error: str = ""
    preflight_warning: str = ""


@dataclass
class TrialRow:
    timestamp: str
    run_id: str
    mode: str
    algorithm: str
    round_index: int
    attempt_index: int
    feedback_used: bool
    enhancement_used: bool
    branch: str
    instance: str
    parseable: bool
    objective: str
    bks: str
    gap_percent: str
    route_count: int
    constraint_violations: str
    return_code: int
    timeout: bool
    elapsed_sec: float
    code_path: str
    stdout_path: str
    stderr_path: str
    warning: str


# =========================
# 3. BASIC UTILITIES
# =========================
def now_stamp() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_name(text: str, max_len: int = 80) -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", text.strip())
    return text[:max_len].strip("_") or "item"


def read_text(path: Path) -> str:
    for enc in ("utf-8", "utf-8-sig", "gbk", "latin-1"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    return path.read_text(errors="replace")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def json_dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)


def is_number_line(line: str) -> bool:
    return re.fullmatch(r"\s*[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?\s*", line) is not None


def to_float_or_none(value: str) -> Optional[float]:
    try:
        x = float(value)
        if math.isfinite(x):
            return x
    except Exception:
        pass
    return None


def is_waiting_or_empty(text: str) -> bool:
    s = str(text or "").strip()
    if not s:
        return True
    lower = s.lower()
    return any(lower.startswith(marker) for marker in WAITING_MARKERS)


def split_csv(text: str) -> List[str]:
    return [x.strip() for x in str(text or "").split(",") if x.strip()]


# =========================
# 4. FLOW PARSING
# =========================
def extract_result_text(raw_result: Any) -> str:
    """Extract human-readable text from a node.result field saved by AI-KM."""
    if raw_result is None:
        return ""
    if not isinstance(raw_result, str):
        return str(raw_result)
    s = raw_result.strip()
    if not s:
        return ""
    try:
        obj = json.loads(s)
        if isinstance(obj, dict):
            for key in ("result", "content", "fileContent", "prompt"):
                val = obj.get(key)
                if isinstance(val, str) and val.strip():
                    return val
            return json_dumps(obj)
        if isinstance(obj, str):
            return obj
    except Exception:
        pass
    return s


class FlowProfile:
    """A small, Python-side profile of the AI-KM workflow."""

    def __init__(self, flow_file: Path, disabled_nodes: Optional[Sequence[str]] = None):
        self.flow_file = flow_file
        self.data = json.loads(read_text(flow_file))
        self.items: List[Dict[str, Any]] = self.data.get("items", [])
        self.links: List[Dict[str, Any]] = self.data.get("links", [])
        self.nodes: Dict[int, Dict[str, Any]] = {
            int(item["id"]): item for item in self.items if "id" in item
        }
        self.disabled_specs = [x.lower() for x in (disabled_nodes or []) if str(x).strip()]
        self.diagnostics: List[Dict[str, Any]] = []
        self._diagnostic_keys: set = set()

    def record_diagnostic(self, node: Dict[str, Any], level: str, message: str) -> None:
        key = (int(node.get("id", -1)), level, message)
        if key in self._diagnostic_keys:
            return
        self._diagnostic_keys.add(key)
        self.diagnostics.append(
            {
                "timestamp": now_stamp(),
                "node_id": int(node.get("id", -1)),
                "node_name": str(node.get("name", "")),
                "node_type": str(node.get("type", "")),
                "level": level,
                "message": message,
            }
        )

    def disabled_node_summary(self) -> List[Dict[str, Any]]:
        return [
            {"id": int(n.get("id", -1)), "name": str(n.get("name", "")), "type": str(n.get("type", ""))}
            for n in self.items
            if self.is_node_disabled(n)
        ]

    def is_node_disabled(self, node: Dict[str, Any]) -> bool:
        if not self.disabled_specs:
            return False
        node_id = str(node.get("id", "")).lower()
        node_name = str(node.get("name", "")).lower()
        node_type = str(node.get("type", "")).lower()
        for spec in self.disabled_specs:
            if spec == node_id or spec in node_name or spec == node_type:
                return True
        return False

    def find_nodes(self, *, node_type: Optional[str] = None, name_contains: str = "") -> List[Dict[str, Any]]:
        out = []
        needle = name_contains.lower()
        for n in self.items:
            if node_type and n.get("type") != node_type:
                continue
            if needle and needle not in str(n.get("name", "")).lower():
                continue
            out.append(n)
        return out

    def find_first(self, *, node_type: Optional[str] = None, name_contains: str = "") -> Optional[Dict[str, Any]]:
        found = self.find_nodes(node_type=node_type, name_contains=name_contains)
        return found[0] if found else None

    def upstream_nodes(self, target_id: int) -> List[Tuple[Dict[str, Any], Dict[str, Any]]]:
        pairs = []
        for link in self.links:
            if int(link.get("target", -999999)) == int(target_id):
                src = self.nodes.get(int(link.get("source", -999999)))
                if src:
                    pairs.append((src, link))
        return pairs

    def downstream_links(self, source_id: int) -> List[Dict[str, Any]]:
        return [l for l in self.links if int(l.get("source", -999999)) == int(source_id)]

    def _local_file_text(self, node: Dict[str, Any]) -> str:
        prompt = str(node.get("prompt", "")).strip().strip('"')
        if not prompt:
            self.record_diagnostic(node, "error", "Local node has no file path in prompt.")
            return ""
        path_match = re.search(r"([A-Za-z]:[\\/][^\n`\"]+|/[^\n`\"]+)", prompt)
        candidate = Path(path_match.group(1).strip()) if path_match else Path(prompt)
        try:
            if candidate.exists() and candidate.is_file():
                text = read_text(candidate)
                self.record_diagnostic(node, "info", f"Recovered local-node content from prompt path: {candidate}")
                return text
            self.record_diagnostic(node, "error", f"Local-node file path does not exist: {candidate}")
        except Exception as e:
            self.record_diagnostic(node, "error", f"Could not read local-node file {candidate}: {e}")
        return ""

    def node_text(self, node: Dict[str, Any], prefer_result: bool = True, visited: Optional[set] = None) -> str:
        if self.is_node_disabled(node):
            self.record_diagnostic(node, "warning", "Node disabled by experiment configuration.")
            return ""
        visited = visited or set()
        node_id = int(node.get("id", -1))
        if node_id in visited:
            self.record_diagnostic(node, "warning", "Cycle detected while resolving node context; node skipped.")
            return ""
        visited.add(node_id)

        if prefer_result:
            text = extract_result_text(node.get("result"))
            if text and not is_waiting_or_empty(text):
                return text

        node_type = str(node.get("type", ""))
        if node_type == "local":
            local_text = self._local_file_text(node)
            if local_text:
                return local_text

        if node_type == "reasoning":
            contexts = []
            for src, link in self.upstream_nodes(node_id):
                src_text = self.node_text(src, prefer_result=True, visited=set(visited))
                if src_text:
                    port = f" / sourcePort={link.get('sourcePort')}" if link.get("sourcePort") else ""
                    contexts.append(f"### Recovered upstream node: {src.get('name', src.get('id'))}{port}\n{src_text}")
            prompt = str(node.get("prompt", ""))
            if contexts:
                self.record_diagnostic(
                    node,
                    "warning",
                    "Reasoning-node result was unavailable; reconstructed context from upstream nodes and its prompt.",
                )
                return "\n\n".join(contexts) + "\n\n### Failed/unrun reasoning-node prompt\n" + prompt
            self.record_diagnostic(node, "warning", "Reasoning-node result was unavailable; using prompt only.")
            return prompt

        return str(node.get("prompt", ""))

    def algorithm_reasoning_node(self, algorithm: str) -> Dict[str, Any]:
        algorithm = normalize_algorithm(algorithm)
        for needle in ALGORITHM_NODE_KEYWORDS[algorithm]:
            n = self.find_first(node_type="reasoning", name_contains=needle)
            if n:
                return n
        raise ValueError(f"Cannot find the {algorithm} reasoning node in the .flow file.")

    def exact_reasoning_node(self) -> Dict[str, Any]:
        return self.algorithm_reasoning_node("exact")

    def feedback_node(self, algorithm: str = "exact") -> Optional[Dict[str, Any]]:
        algorithm = normalize_algorithm(algorithm)
        for needle in ALGORITHM_FEEDBACK_KEYWORDS[algorithm]:
            n = self.find_first(node_type="reasoning", name_contains=needle)
            if n:
                return n
        for needle in ("Feedback Reasoning", "feedback"):
            n = self.find_first(node_type="reasoning", name_contains=needle)
            if n:
                return n
        return None

    def decision_node(self) -> Optional[Dict[str, Any]]:
        return self.find_first(node_type="decision")

    def algorithm_prior_nodes(self) -> List[Dict[str, Any]]:
        priors = []
        for n in self.items:
            name = str(n.get("name", ""))
            if re.search(r"\bA\d+_prior", name, flags=re.I) or "prior_knowledge" in name.lower():
                priors.append(n)
        return priors

    def selected_instances(self) -> List[str]:
        joined = "\n".join(
            [str(n.get("prompt", "")) + "\n" + extract_result_text(n.get("result")) for n in self.items]
        )
        # Cordeau instances in this workflow include p01, p02, p03, p12, pr01, pr02.
        names = re.findall(r"\b(?:pr\d{2}|p\d{2})\b", joined, flags=re.I)
        uniq: List[str] = []
        for x in names:
            lx = x.lower()
            if lx not in uniq:
                uniq.append(lx)
        preferred = ["pr01", "p01", "p02", "p03", "p12", "pr02"]
        ordered = [x for x in preferred if x in uniq] + [x for x in uniq if x not in preferred]
        return ordered or preferred

    def instance_dir_from_flow(self) -> str:
        joined = "\n".join([str(n.get("prompt", "")) + "\n" + extract_result_text(n.get("result")) for n in self.items])
        # Windows path after the phrase "Instance directory" or "file path".
        m = re.search(r"([A-Za-z]:\\[^\n`\"]*6-mdvrp)", joined)
        return m.group(1).strip() if m else ""

    def bks_file_from_flow(self) -> str:
        candidates: List[Tuple[int, str]] = []
        for node in self.items:
            prompt = str(node.get("prompt", "")).strip()
            name = str(node.get("name", "")).lower()
            if "bks" in name or "bks" in prompt.lower():
                m = re.search(r"([A-Za-z]:\\[^\n`\"]+\.(?:md|txt|res))", prompt, flags=re.I)
                if m:
                    candidate = m.group(1).strip()
                    score = 0
                    text = (name + " " + candidate.lower())
                    if "mdvrp-sol-bks" in text:
                        score += 100
                    if "6-instance" in text or "six-instance" in text:
                        score += 50
                    if "structure" in text:
                        score -= 80
                    candidates.append((score, candidate))
        candidates.sort(key=lambda x: x[0], reverse=True)
        for _score, candidate in candidates:
            try:
                if Path(candidate).exists():
                    return candidate
            except Exception:
                continue
        return candidates[0][1] if candidates else ""

    def model_name_from_flow(self, algorithm: str = "exact") -> str:
        node = self.algorithm_reasoning_node(algorithm)
        return str(node.get("model") or "").strip()


def normalize_algorithm(value: str) -> str:
    v = str(value or "").strip().lower()
    aliases = {
        "a1": "exact",
        "gurobi": "exact",
        "mip": "exact",
        "exact_restricted_route_pool": "exact",
        "restricted": "exact",
        "route_pool": "exact",
    }
    v = aliases.get(v, v)
    if v not in ALGORITHM_NODE_KEYWORDS:
        raise ValueError(f"Unsupported algorithm '{value}'. This main 4.3 runner now supports exact/gurobi only.")
    return v


def parse_algorithms(text: str) -> List[str]:
    raw = split_csv(text or DEFAULT_ALGORITHMS)
    if any(x.lower() == "all" for x in raw):
        return list(ALGORITHM_NODE_KEYWORDS.keys())
    out: List[str] = []
    for item in raw:
        alg = normalize_algorithm(item)
        if alg not in out:
            out.append(alg)
    return out or list(ALGORITHM_NODE_KEYWORDS.keys())


# =========================
# 5. DEEPSEEK API CLIENT
# =========================
class DeepSeekClient:
    def __init__(self, cfg: LLMConfig, dry_run: bool = False):
        self.cfg = cfg
        self.dry_run = dry_run

    def complete(self, prompt: str, *, model: str = "", temperature: Optional[float] = None, max_tokens: Optional[int] = None) -> str:
        if self.dry_run:
            return "# DRY RUN: no API call was made."
        api_key = self.cfg.api_key.strip()
        if not api_key:
            raise RuntimeError(
                "DeepSeek API key is empty. Fill DEEPSEEK_API_KEY in the script, "
                "set environment variable DEEPSEEK_API_KEY, or pass --api-key."
            )
        payload = {
            "model": model or self.cfg.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": self.cfg.temperature if temperature is None else temperature,
            "max_tokens": self.cfg.max_tokens if max_tokens is None else max_tokens,
            "stream": False,
        }
        if not payload["model"]:
            raise RuntimeError("Model name is empty. Set DEFAULT_DEEPSEEK_MODEL, --model, or ensure the .flow node has a model.")

        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.cfg.api_url,
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
        )
        last_error: Optional[Exception] = None
        for attempt in range(max(0, self.cfg.retries) + 1):
            try:
                with urllib.request.urlopen(req, timeout=self.cfg.timeout) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as e:
                err_body = e.read().decode("utf-8", errors="replace")
                last_error = RuntimeError(f"LLM HTTP error {e.code}: {err_body}")
                if e.code < 500 and e.code not in {408, 409, 429}:
                    raise last_error from e
            except Exception as e:
                last_error = RuntimeError(f"LLM request failed: {e}")
            if attempt < max(0, self.cfg.retries):
                time.sleep(min(2 ** attempt, 8))
        else:
            raise last_error or RuntimeError("LLM request failed.")

        try:
            return data["choices"][0]["message"]["content"]
        except Exception as e:
            raise RuntimeError(f"Unexpected LLM response schema: {json_dumps(data)[:2000]}") from e


# =========================
# 6. PROMPT CONSTRUCTION
# =========================
def execution_contract(instances: Sequence[str]) -> str:
    inst_text = ", ".join(instances)
    return f"""

Additional controller execution contract. Follow this contract strictly:
1. Output one complete Python program only. Do not output Markdown explanations.
2. The program must be executable as:
   python generated_solver.py --instances-dir <dir> --instances {inst_text} --output-dir <dir> --time-limit <seconds> --seed <int>
3. The program must not call input(). It must not read BKS files, .res files, benchmark result files, or hard-code reference objective values.
4. The program may use gurobipy if available, but it must still return a feasible constructive or heuristic route-level solution if gurobipy is unavailable, times out, or fails.
5. For every selected instance, write a text file to the output directory named <instance>.sol.txt.
6. Each <instance>.sol.txt must use this parseable format:
   first non-empty line: objective value only
   subsequent non-empty route lines:
   depot_sequence_id  route_id  route_distance  route_load  0  customer_sequence  0
7. Also print a clear block to stdout for each instance:
   INSTANCE: <instance>
   <same content as the solution file>
8. Use robust Cordeau MDVRP parsing: header fields are int; depot constraints are float; node_id is int; x, y, service time, and demand are float. Coordinates may be decimal or negative.
9. Interpret the Cordeau header correctly: the second field is vehicles_per_depot. The number of output routes assigned to each depot must not exceed vehicles_per_depot.
10. Preserve original customer IDs in route output. Prefer depot sequence ID 1..m in the first column. If using original depot node IDs, keep them consistent with the instance depot records.
11. Do not output one route per customer unless the vehicle limit allows it. Merge customers into feasible multi-customer routes using capacity and route-duration checks.
12. For max_route_duration <= 0, treat route duration as unconstrained; otherwise enforce travel distance plus customer service time <= max_route_duration.
13. Reported route_load must equal the sum of served customer demands. Reported route_distance must equal depot-customer travel distance for the printed route. The first objective line must equal the sum of printed route distances.
14. Keep route-pool generation bounded. Do not enumerate all customer combinations and all permutations.
15. Catch exceptions per instance and continue solving the remaining instances. If an instance fails, write a short failure file <instance>.failed.txt.
""".strip()


def build_node_prompt(profile: FlowProfile, node: Dict[str, Any], extra_context: str = "") -> str:
    contexts = []
    for src, link in profile.upstream_nodes(int(node["id"])):
        txt = profile.node_text(src, prefer_result=True)
        if txt:
            port = f" / sourcePort={link.get('sourcePort')}" if link.get("sourcePort") else ""
            contexts.append(f"### Upstream node: {src.get('name', src.get('id'))}{port}\n{txt}")
    if extra_context.strip():
        contexts.append(f"### Additional runtime context\n{extra_context.strip()}")
    combined = "\n\n".join(contexts)
    prefix = f"Relevant context:\n\n{combined}\n\n" if combined else ""
    return prefix + "User instruction:\n" + str(node.get("prompt", ""))


def compact_code_for_feedback(code: str, outcome: ExecutionOutcome, max_chars: int = 14000) -> str:
    """Keep feedback prompts compact to reduce truncated repair code.

    Full generated solvers can be long. Sending all of them back to the LLM
    often consumes the response budget and causes incomplete replacement code.
    Prefer the error neighborhood plus the beginning/end of the file.
    """
    if len(code) <= max_chars:
        return code
    report = outcome.compile_error or outcome.stderr or ""
    line_numbers = [int(x) for x in re.findall(r"line\s+(\d+)", report) if x.isdigit()]
    lines = code.splitlines()
    snippets: List[str] = []
    if line_numbers:
        for ln in line_numbers[:3]:
            start = max(1, ln - 35)
            end = min(len(lines), ln + 35)
            snippet = "\n".join(f"{i}: {lines[i - 1]}" for i in range(start, end + 1))
            snippets.append(f"# Error neighborhood around line {ln}\n{snippet}")
    head = "\n".join(lines[:120])
    tail = "\n".join(lines[-120:]) if len(lines) > 120 else ""
    compact = "\n\n".join(
        x
        for x in [
            "# Previous code was too long; compacted for feedback.",
            "# File head:\n" + head,
            *snippets,
            "# File tail:\n" + tail if tail else "",
        ]
        if x
    )
    return compact[:max_chars]


def build_generation_prompt(
    profile: FlowProfile,
    mode: str,
    algorithm: str,
    instances: Sequence[str],
    standard_model_override: str = "",
) -> str:
    algorithm = normalize_algorithm(algorithm)
    reasoning_node = profile.algorithm_reasoning_node(algorithm)
    contract = execution_contract(instances)

    if mode == "unstructured":
        return f"""
Generate a stable single-file Python program for solving selected Cordeau MDVRP instances.
Selected instances: {', '.join(instances)}.
The goal is to minimize total route distance under vehicle-capacity, route-duration, depot, and customer-service constraints.
Algorithm family to use: {ALGORITHM_LABELS[algorithm]}.

{contract}
""".strip()

    upstream_contexts = []
    for src, link in profile.upstream_nodes(int(reasoning_node["id"])):
        if profile.is_node_disabled(src):
            profile.record_diagnostic(src, "warning", f"Skipped as upstream context for {ALGORITHM_LABELS[algorithm]}.")
            continue
        name = str(src.get("name", ""))
        if mode == "ablation_no_prior" and ("prior" in name.lower() or "model prior" in name.lower()):
            profile.record_diagnostic(src, "warning", f"Skipped by ablation_no_prior for {ALGORITHM_LABELS[algorithm]}.")
            continue
        txt = profile.node_text(src, prefer_result=True)
        # If requested, replace the cached mathematical-model node output with a regenerated one.
        if standard_model_override and src.get("type") == "reasoning" and "Exact" not in name:
            txt = standard_model_override
        if txt:
            upstream_contexts.append(f"### Upstream node: {name or src.get('id')}\n{txt}")

    context_text = "\n\n".join(upstream_contexts)
    prompt = f"""
Relevant context:

{context_text}

User instruction:
{reasoning_node.get('prompt', '')}

{contract}
""".strip()
    return prompt


def build_feedback_prompt(
    profile: FlowProfile,
    algorithm: str,
    instances: Sequence[str],
    previous_code: str,
    outcome: ExecutionOutcome,
    parsed: Dict[str, ParsedSolution],
    attempt_index: int,
) -> str:
    algorithm = normalize_algorithm(algorithm)
    fb = profile.feedback_node(algorithm)
    base = str(fb.get("prompt", "")) if fb else "Regenerate corrected stable Python code."
    code_context = compact_code_for_feedback(previous_code, outcome)
    missing = [i for i in instances if not parsed.get(i) or not parsed[i].parseable]
    parsed_diagnostics = {
        inst: {
            "parseable": sol.parseable,
            "objective": sol.objective,
            "route_count": sol.route_count,
            "warning": sol.warning,
            "constraint_violations": sol.constraint_violations,
            "source": sol.source,
        }
        for inst, sol in parsed.items()
    }
    runtime_report = {
        "attempt_index": attempt_index,
        "return_code": outcome.return_code,
        "timeout": outcome.timeout,
        "elapsed_sec": round(outcome.elapsed_sec, 3),
        "compile_error": outcome.compile_error,
        "preflight_warning": outcome.preflight_warning,
        "missing_or_unparseable_instances": missing,
        "parsed_solution_diagnostics": parsed_diagnostics,
        "stdout_tail": outcome.stdout[-6000:],
        "stderr_tail": outcome.stderr[-6000:],
    }
    return f"""
{base}

Selected instances: {', '.join(instances)}
Algorithm branch: {ALGORITHM_LABELS[algorithm]}

Controller execution contract that the revised code must satisfy:
{execution_contract(instances)}

Stability-first repair rules:
1. Return a short, complete, syntactically valid Python file. Keep the code under about 450 lines whenever possible.
2. Do not use unfinished placeholders, pseudocode, explanatory English inside code expressions, or partial snippets.
3. If the previous code had a SyntaxError, truncation, timeout, or overly complex logic, replace it with a simpler stable constructive solver plus bounded local search instead of patching a complex framework.
4. Always build and output a feasible fallback solution before any improvement or optimization step.
5. Keep loops bounded by --time-limit; do not run unbounded while-loops or exhaustive permutation/combination enumeration.
6. At the end, write every selected instance to <output-dir>/<instance>.sol.txt and print an INSTANCE block to stdout.
7. Before returning, mentally check that every opened parenthesis, bracket, string literal, function block, and if/for/while block is closed.
8. If parsed_solution_diagnostics reports constraint_violations, explicitly repair those violations: serve every customer exactly once, respect vehicles_per_depot, capacity and route-duration limits, and make reported route distances and loads match the actual routes.
9. Do not degrade already valid instances while repairing failed ones. Reuse stable parser/output functions and only change routing logic needed to remove the reported violations.
10. If the previous attempt exceeded vehicles_per_depot, redesign the constructive fallback to pack multiple customers per route instead of creating one route per customer.
11. If route distance or load mismatches are reported, recompute objective, route_distance and route_load from the printed customer sequence immediately before writing each .sol.txt file.

Runtime failure / parseability report:
{json_dumps(runtime_report)}

Previous generated code context:
```python
{code_context}
```

Return only the corrected complete Python program. Do not include Markdown explanations.
""".strip()


def build_quality_prompt(
    profile: FlowProfile,
    algorithm: str,
    instances: Sequence[str],
    previous_code: str,
    weak_instances: Sequence[str],
) -> str:
    algorithm = normalize_algorithm(algorithm)
    reasoning_node = profile.algorithm_reasoning_node(algorithm)
    upstream_contexts = []
    for src, _link in profile.upstream_nodes(int(reasoning_node["id"])):
        if profile.is_node_disabled(src):
            continue
        txt = profile.node_text(src, prefer_result=True)
        if txt:
            upstream_contexts.append(f"### Upstream node: {src.get('name', src.get('id'))}\n{txt}")
    weak_text = ", ".join(weak_instances) if weak_instances else "the selected instances as a whole"
    return f"""
You are the autonomous quality-enhancement module for the structured MDVRP workflow.

Goal:
Revise the previous solver to improve solution quality while preserving stability and parseable output.
Algorithm branch: {ALGORITHM_LABELS[algorithm]}.

Important anti-leakage rule:
Do not read BKS files, .res files, benchmark result files, or hard-code reference objective values. The hidden evaluator only reports that the following instances need stronger search quality: {weak_text}. No BKS values are provided.

Recommended improvement directions:
- keep the robust parser and the same output contract;
- strengthen constructive initialization with multi-start depot assignment;
- add bounded local search such as 2-opt, relocate, swap, and inter-route customer exchange;
- diversify route pools without exhaustive combination/permutation enumeration;
- keep runtime bounded by --time-limit and continue to output the best feasible solution.

Relevant workflow context:
{chr(10).join(upstream_contexts)}

Execution contract:
{execution_contract(instances)}

Previous solver code:
```python
{previous_code}
```

Return only the improved complete Python program. Do not include Markdown explanations.
""".strip()


# =========================
# 7. CODE EXTRACTION AND PREFLIGHT
# =========================
def extract_python_code(llm_text: str) -> str:
    """Extract Python code from an LLM response."""
    text = llm_text.strip()
    blocks = re.findall(r"```(?:python|py)?\s*([\s\S]*?)```", text, flags=re.I)
    if blocks:
        return blocks[-1].strip() + "\n"

    # If no fenced block exists, remove common prose before the first code-looking line.
    lines = text.splitlines()
    start = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith(("import ", "from ", "#", "def ", "class ", "if __name__")):
            start = i
            break
    return "\n".join(lines[start:]).strip() + "\n"


def preflight_solver_code(code: str) -> str:
    """Return warnings for risky or experiment-contaminating patterns."""
    warnings = []
    lower = code.lower()
    # These checks are intentionally conservative warnings, not automatic hard stops.
    if "input(" in lower:
        warnings.append("Generated solver appears to call input(), which may block execution.")
    suspicious_reads = ["bks", ".res", "best known", "benchmark result", "mdvrp-sol"]
    for token in suspicious_reads:
        if token in lower:
            warnings.append(f"Generated solver mentions '{token}'. Ensure it does not read BKS/reference result files.")
            break
    dangerous = ["shutil.rmtree", "os.remove(", "os.unlink(", "socket."]
    for token in dangerous:
        if token in lower:
            warnings.append(f"Generated solver contains potentially risky operation '{token}'.")
    return " | ".join(warnings)


def compile_check(code_path: Path) -> str:
    try:
        py_compile.compile(str(code_path), doraise=True)
        return ""
    except Exception:
        return traceback.format_exc()


# =========================
# 8. GENERATED SOLVER EXECUTION
# =========================
def execute_generated_solver(
    code: str,
    run_dir: Path,
    attempt_index: int,
    instances_dir: Path,
    instances: Sequence[str],
    solver_time_limit: int,
    execution_timeout: int,
    seed: int,
    tag: str,
) -> ExecutionOutcome:
    run_dir.mkdir(parents=True, exist_ok=True)
    code_path = run_dir / f"generated_solver_{tag}_attempt{attempt_index}.py"
    stdout_path = run_dir / f"stdout_{tag}_attempt{attempt_index}.txt"
    stderr_path = run_dir / f"stderr_{tag}_attempt{attempt_index}.txt"
    solution_dir = run_dir / f"solutions_{tag}_attempt{attempt_index}"
    solution_dir.mkdir(parents=True, exist_ok=True)

    write_text(code_path, code)
    preflight_warning = preflight_solver_code(code)
    compile_error = compile_check(code_path)
    if compile_error:
        write_text(stdout_path, "")
        write_text(stderr_path, compile_error)
        return ExecutionOutcome(
            return_code=999,
            stdout="",
            stderr=compile_error,
            timeout=False,
            elapsed_sec=0.0,
            code_path=str(code_path),
            stdout_path=str(stdout_path),
            stderr_path=str(stderr_path),
            compile_error=compile_error,
            preflight_warning=preflight_warning,
        )

    cmd = [
        sys.executable,
        str(code_path),
        "--instances-dir",
        str(instances_dir),
        "--instances",
        ",".join(instances),
        "--output-dir",
        str(solution_dir),
        "--time-limit",
        str(solver_time_limit),
        "--seed",
        str(seed),
    ]
    start = time.time()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(run_dir),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=execution_timeout,
        )
        elapsed = time.time() - start
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""
        write_text(stdout_path, stdout)
        write_text(stderr_path, stderr)
        return ExecutionOutcome(
            return_code=proc.returncode,
            stdout=stdout,
            stderr=stderr,
            timeout=False,
            elapsed_sec=elapsed,
            code_path=str(code_path),
            stdout_path=str(stdout_path),
            stderr_path=str(stderr_path),
            compile_error="",
            preflight_warning=preflight_warning,
        )
    except subprocess.TimeoutExpired as e:
        elapsed = time.time() - start
        stdout = e.stdout if isinstance(e.stdout, str) else (e.stdout.decode("utf-8", errors="replace") if e.stdout else "")
        stderr = e.stderr if isinstance(e.stderr, str) else (e.stderr.decode("utf-8", errors="replace") if e.stderr else "")
        stderr += f"\nTIMEOUT after {execution_timeout} seconds."
        write_text(stdout_path, stdout)
        write_text(stderr_path, stderr)
        return ExecutionOutcome(
            return_code=998,
            stdout=stdout,
            stderr=stderr,
            timeout=True,
            elapsed_sec=elapsed,
            code_path=str(code_path),
            stdout_path=str(stdout_path),
            stderr_path=str(stderr_path),
            compile_error="",
            preflight_warning=preflight_warning,
        )


# =========================
# 9. SOLUTION OUTPUT PARSING
# =========================
def looks_like_route_line(line: str) -> bool:
    parts = line.strip().split()
    if len(parts) < 7:
        return False
    # Expected: depot_seq route_id distance load 0 customers... 0
    if to_float_or_none(parts[2]) is None or to_float_or_none(parts[3]) is None:
        return False
    try:
        int(float(parts[0])); int(float(parts[1]))
    except Exception:
        return False
    # Prefer the strict controller format, but tolerate historical BKS-like lines
    # where depot IDs replace the explicit 0 delimiters.
    try:
        for token in parts[4:]:
            int(float(token))
    except Exception:
        return False
    return True


def route_customer_tokens(parts: Sequence[str]) -> List[str]:
    if len(parts) < 7:
        return []
    # Controller contract format:
    # depot route distance load 0 customer... 0
    if parts[4] == "0" and parts[-1] == "0":
        return [x for x in parts[5:-1] if x != "0"]
    # Historical BKS-like format may use depot node IDs as delimiters instead
    # of explicit zeros. Keep this as a fallback but require at least one
    # interior customer.
    return list(parts[5:-1]) if len(parts) > 6 else []


_INSTANCE_CACHE: Dict[str, CordeauInstance] = {}


def load_cordeau_instance(instance_path: Path) -> CordeauInstance:
    key = str(instance_path.resolve()).lower()
    cached = _INSTANCE_CACHE.get(key)
    if cached:
        return cached

    lines = [ln.strip() for ln in read_text(instance_path).splitlines() if ln.strip()]
    if not lines:
        raise ValueError(f"Empty instance file: {instance_path}")

    header = lines[0].split()
    if len(header) < 4:
        raise ValueError(f"Invalid Cordeau header in {instance_path}: {lines[0]}")
    vehicles_per_depot = int(float(header[1]))
    customer_count = int(float(header[2]))
    depot_count = int(float(header[3]))
    idx = 1

    max_route_duration: List[float] = []
    vehicle_capacity: List[float] = []
    for _ in range(depot_count):
        parts = lines[idx].split()
        max_route_duration.append(float(parts[0]))
        vehicle_capacity.append(float(parts[1]))
        idx += 1

    customer_ids: List[int] = []
    depot_ids: List[int] = []
    customer_demand: Dict[int, float] = {}
    service_time: Dict[int, float] = {}
    coordinates: Dict[int, Tuple[float, float]] = {}

    for _ in range(customer_count):
        parts = lines[idx].split()
        node_id = int(float(parts[0]))
        customer_ids.append(node_id)
        coordinates[node_id] = (float(parts[1]), float(parts[2]))
        service_time[node_id] = float(parts[3])
        customer_demand[node_id] = float(parts[4])
        idx += 1

    for _ in range(depot_count):
        parts = lines[idx].split()
        node_id = int(float(parts[0]))
        depot_ids.append(node_id)
        coordinates[node_id] = (float(parts[1]), float(parts[2]))
        service_time[node_id] = float(parts[3])
        idx += 1

    data = CordeauInstance(
        name=instance_path.name.lower(),
        vehicles_per_depot=vehicles_per_depot,
        customer_ids=customer_ids,
        depot_ids=depot_ids,
        customer_demand=customer_demand,
        service_time=service_time,
        coordinates=coordinates,
        max_route_duration=max_route_duration,
        vehicle_capacity=vehicle_capacity,
    )
    _INSTANCE_CACHE[key] = data
    return data


def euclidean(data: CordeauInstance, a: int, b: int) -> float:
    ax, ay = data.coordinates[a]
    bx, by = data.coordinates[b]
    return math.hypot(ax - bx, ay - by)


def verify_solution_constraints(instance: str, text: str, sol: ParsedSolution, instances_dir: Path) -> str:
    """Independently verify route-level MDVRP constraints from a solution text.

    This is deliberately conservative.  It validates the constraints that can be
    checked from the standard Cordeau instance and the required route output:
    customer coverage, duplicate service, depot sequence, route capacity,
    optional route-duration limit, and route-distance consistency.
    """
    if not sol.route_count or sol.objective is None:
        return ""
    instance_path = instances_dir / instance
    if not instance_path.exists():
        return f"instance_file_not_found:{instance_path}"

    try:
        data = load_cordeau_instance(instance_path)
    except Exception as exc:
        return f"instance_parse_failed:{type(exc).__name__}:{exc}"

    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    obj_idx = next((i for i, ln in enumerate(lines) if is_number_line(ln) or re.search(r"(?:objective|obj|cost|distance)\s*[:=]\s*([-+]?\d+(?:\.\d+)?)", ln, flags=re.I)), -1)
    route_lines = [ln for ln in lines[obj_idx + 1 :] if looks_like_route_line(ln)] if obj_idx >= 0 else []

    violations: List[str] = []
    served: List[int] = []
    route_count_by_depot: Dict[int, int] = {}
    customer_set = set(data.customer_ids)

    for route_no, ln in enumerate(route_lines, start=1):
        parts = ln.split()
        try:
            depot_seq = int(float(parts[0]))
            reported_distance = float(parts[2])
            reported_load = float(parts[3])
            customers = [int(float(x)) for x in route_customer_tokens(parts)]
        except Exception:
            violations.append(f"route_{route_no}:malformed_numeric_fields")
            continue

        if 1 <= depot_seq <= len(data.depot_ids):
            depot_idx = depot_seq - 1
        elif depot_seq in data.depot_ids:
            depot_idx = data.depot_ids.index(depot_seq)
        else:
            violations.append(f"route_{route_no}:invalid_depot_sequence_or_id_{depot_seq}")
            continue

        depot_id = data.depot_ids[depot_idx]
        route_count_by_depot[depot_idx] = route_count_by_depot.get(depot_idx, 0) + 1
        if route_count_by_depot[depot_idx] > data.vehicles_per_depot:
            violations.append(f"depot_{depot_seq}:vehicle_count_exceeded")

        if not customers:
            violations.append(f"route_{route_no}:empty_customer_sequence")
            continue

        unknown = [c for c in customers if c not in customer_set]
        if unknown:
            violations.append(f"route_{route_no}:unknown_customers={unknown[:5]}")
            continue

        served.extend(customers)
        actual_load = sum(data.customer_demand[c] for c in customers)
        if actual_load > data.vehicle_capacity[depot_idx] + 1e-6:
            violations.append(f"route_{route_no}:capacity_exceeded:{actual_load:.3f}>{data.vehicle_capacity[depot_idx]:.3f}")
        if abs(actual_load - reported_load) > max(1.0, 0.05 * max(1.0, actual_load)):
            violations.append(f"route_{route_no}:reported_load_mismatch:{reported_load:.3f}!={actual_load:.3f}")

        actual_distance = 0.0
        previous = depot_id
        for customer in customers:
            actual_distance += euclidean(data, previous, customer)
            previous = customer
        actual_distance += euclidean(data, previous, depot_id)
        if abs(actual_distance - reported_distance) > max(1.0, 0.05 * max(1.0, actual_distance)):
            violations.append(f"route_{route_no}:reported_distance_mismatch:{reported_distance:.3f}!={actual_distance:.3f}")

        max_duration = data.max_route_duration[depot_idx]
        if max_duration > 0:
            duration = actual_distance + sum(data.service_time[c] for c in customers)
            if duration > max_duration + 1e-6:
                violations.append(f"route_{route_no}:duration_exceeded:{duration:.3f}>{max_duration:.3f}")

    seen: Dict[int, int] = {}
    for customer in served:
        seen[customer] = seen.get(customer, 0) + 1
    missing = sorted(customer_set - set(served))
    duplicated = sorted(c for c, count in seen.items() if count > 1)
    if missing:
        violations.append(f"missing_customers={missing[:20]}")
    if duplicated:
        violations.append(f"duplicated_customers={duplicated[:20]}")

    # Keep the CSV field compact while retaining the actionable diagnosis.
    compact: List[str] = []
    for item in violations:
        if item not in compact:
            compact.append(item)
    return "; ".join(compact[:20])


def parse_solution_text(instance: str, text: str, source: str, raw_text_path: str = "") -> ParsedSolution:
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    objective: Optional[float] = None
    obj_idx = -1
    for idx, ln in enumerate(lines):
        if is_number_line(ln):
            objective = float(ln)
            obj_idx = idx
            break
        # Tolerate: objective = 123.45
        m = re.search(r"(?:objective|obj|cost|distance)\s*[:=]\s*([-+]?\d+(?:\.\d+)?)", ln, flags=re.I)
        if m:
            objective = float(m.group(1))
            obj_idx = idx
            break
    route_lines = [ln for ln in lines[obj_idx + 1 :] if looks_like_route_line(ln)] if obj_idx >= 0 else []
    route_distance_sum = 0.0
    customer_count = 0
    for ln in route_lines:
        parts = ln.split()
        route_distance_sum += float(parts[2])
        customer_count += len(route_customer_tokens(parts))
    warning = ""
    if objective is None:
        warning = "No numeric objective line found."
    elif objective <= 0:
        warning = "Objective is non-positive."
    elif not route_lines:
        warning = "No parseable route-level lines found."
    elif customer_count <= 0:
        warning = "Route-level output contains no served customers."
    elif abs(route_distance_sum - objective) > max(1.0, abs(objective) * 0.05):
        warning = f"Objective does not match sum of route distances: objective={objective:.6f}, route_sum={route_distance_sum:.6f}."
    return ParsedSolution(
        instance=instance,
        objective=objective,
        route_count=len(route_lines),
        parseable=(objective is not None and len(route_lines) > 0 and warning == ""),
        source=source,
        raw_text_path=raw_text_path,
        warning=warning,
    )


def parse_and_verify_solution_text(instance: str, text: str, source: str, raw_text_path: str, instances_dir: Path) -> ParsedSolution:
    sol = parse_solution_text(instance, text, source=source, raw_text_path=raw_text_path)
    violations = verify_solution_constraints(instance, text, sol, instances_dir)
    sol.constraint_violations = violations
    if violations:
        sol.parseable = False
        sol.warning = "Constraint violations detected." if not sol.warning else f"{sol.warning} Constraint violations detected."
    return sol


def collect_solution_files(run_dir: Path, tag: str, attempt_index: int) -> Path:
    return run_dir / f"solutions_{tag}_attempt{attempt_index}"


def parse_stdout_blocks(stdout: str, instances: Sequence[str]) -> Dict[str, str]:
    blocks: Dict[str, str] = {}
    marker_pattern = re.compile(r"^\s*INSTANCE\s*:\s*([A-Za-z0-9_.-]+)\s*$", flags=re.I | re.M)
    matches = list(marker_pattern.finditer(stdout))
    if matches:
        for i, m in enumerate(matches):
            inst = m.group(1).lower()
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(stdout)
            blocks[inst] = stdout[start:end].strip()
        return blocks

    # Tolerate headings such as === p01 ===.
    heading_pattern = re.compile(r"^\s*=+\s*([A-Za-z0-9_.-]+)\s*=+\s*$", flags=re.I | re.M)
    matches = list(heading_pattern.finditer(stdout))
    if matches:
        for i, m in enumerate(matches):
            inst = m.group(1).lower()
            if inst in [x.lower() for x in instances]:
                start = m.end()
                end = matches[i + 1].start() if i + 1 < len(matches) else len(stdout)
                blocks[inst] = stdout[start:end].strip()
    return blocks


def parse_generated_outputs(
    run_dir: Path,
    tag: str,
    attempt_index: int,
    instances: Sequence[str],
    outcome: ExecutionOutcome,
    instances_dir: Path,
) -> Dict[str, ParsedSolution]:
    parsed: Dict[str, ParsedSolution] = {}
    sol_dir = collect_solution_files(run_dir, tag, attempt_index)

    for inst in instances:
        candidates: List[Path] = []
        if sol_dir.exists():
            patterns = [f"{inst}.sol.txt", f"{inst}.txt", f"*{inst}*.sol*", f"*{inst}*.txt"]
            for pat in patterns:
                candidates.extend(sol_dir.glob(pat))
        # Deduplicate while preserving order.
        seen = set()
        unique_candidates = []
        for p in candidates:
            if p.is_file() and p not in seen:
                unique_candidates.append(p)
                seen.add(p)
        if unique_candidates:
            # Prefer the largest file; tiny failed files are less useful.
            best = sorted(unique_candidates, key=lambda p: p.stat().st_size, reverse=True)[0]
            text = read_text(best)
            parsed[inst] = parse_and_verify_solution_text(inst, text, source="file", raw_text_path=str(best), instances_dir=instances_dir)

    # Fill missing instances from stdout blocks.
    blocks = parse_stdout_blocks(outcome.stdout, instances)
    for inst in instances:
        if inst in parsed and parsed[inst].parseable:
            continue
        if inst.lower() in blocks:
            parsed[inst] = parse_and_verify_solution_text(inst, blocks[inst.lower()], source="stdout", raw_text_path=outcome.stdout_path, instances_dir=instances_dir)

    # If only one instance and no marker, try entire stdout.
    if len(instances) == 1 and instances[0] not in parsed:
        parsed[instances[0]] = parse_and_verify_solution_text(instances[0], outcome.stdout, source="stdout_all", raw_text_path=outcome.stdout_path, instances_dir=instances_dir)

    # Add explicit missing records.
    for inst in instances:
        if inst not in parsed:
            parsed[inst] = ParsedSolution(
                instance=inst,
                objective=None,
                route_count=0,
                parseable=False,
                source="missing",
                raw_text_path="",
                warning="No solution file or stdout block found.",
                constraint_violations="",
            )
    return parsed


def deterministic_branch(instances: Sequence[str], outcome: ExecutionOutcome, parsed: Dict[str, ParsedSolution]) -> str:
    if outcome.timeout or outcome.return_code != 0:
        return "branch_2"
    if all(parsed.get(i) and parsed[i].parseable for i in instances):
        return "branch_1"
    return "branch_2"


# =========================
# 10. BKS PARSING AND EVALUATION
# =========================
def parse_bks_file(path: Optional[Path], selected_instances: Sequence[str]) -> Dict[str, float]:
    if not path or not str(path) or not path.exists():
        return {}
    text = read_text(path)
    inst_set = {x.lower() for x in selected_instances}
    bks: Dict[str, float] = {}
    current_inst: Optional[str] = None
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        # Only section headings of the form "## p01 BKS ..." should switch the
        # current BKS block.  The document also contains a plain selected-
        # instance list; using those list items as block headings can assign the
        # next numeric BKS value to the wrong instance when a subset is selected.
        heading = re.match(r"^#+\s*((?:pr\d{2}|p\d{2}))\b.*\bBKS\b", line, flags=re.I)
        if heading:
            nm = heading.group(1).lower()
            current_inst = nm if nm in inst_set and nm not in bks else None
            continue
        if line.startswith("#"):
            continue
        names = re.findall(r"\b(?:pr\d{2}|p\d{2})\b", line, flags=re.I)
        if names:
            for nm in names:
                nm = nm.lower()
                if nm in inst_set and nm not in bks:
                    current_inst = nm
                    break
        nums = re.findall(r"[-+]?\d+(?:\.\d+)?", line)
        if not nums:
            continue
        if current_inst and current_inst not in bks and is_number_line(line):
            value = to_float_or_none(line)
            if value is not None and value > 0:
                bks[current_inst] = value
                current_inst = None
                continue
        if names:
            # Lines such as "- pr01" contain only the numeric part of the
            # instance name; they are not BKS value lines.
            if len(nums) <= len(names):
                continue
            # Inline formats such as "p01 576.87"; choose the last numeric token
            # because the instance ID itself contributes digits.
            value = to_float_or_none(nums[-1])
            if value is None or value <= 0:
                continue
            for nm in names:
                nm = nm.lower()
                if nm in inst_set and nm not in bks:
                    bks[nm] = value
    return bks


def gap_percent(obj: Optional[float], bks: Optional[float]) -> Optional[float]:
    if obj is None or bks is None or bks <= 0:
        return None
    return 100.0 * (obj - bks) / bks


def choose_weak_instances(parsed: Dict[str, ParsedSolution], bks: Dict[str, float], max_count: int = 3) -> List[str]:
    scored = []
    for inst, sol in parsed.items():
        g = gap_percent(sol.objective, bks.get(inst.lower()))
        if g is not None:
            scored.append((g, inst))
    scored.sort(reverse=True)
    if not scored:
        return [inst for inst, sol in parsed.items() if not sol.parseable][:max_count]
    return [inst for g, inst in scored[:max_count] if g > 0]


def rows_from_attempt(
    run_id: str,
    mode: str,
    algorithm: str,
    round_index: int,
    attempt_index: int,
    feedback_used: bool,
    enhancement_used: bool,
    branch: str,
    parsed: Dict[str, ParsedSolution],
    bks: Dict[str, float],
    outcome: ExecutionOutcome,
) -> List[TrialRow]:
    rows: List[TrialRow] = []
    for inst, sol in parsed.items():
        bk = bks.get(inst.lower())
        gp = gap_percent(sol.objective, bk)
        warn_parts = [x for x in [sol.warning, sol.constraint_violations, outcome.compile_error[:500], outcome.preflight_warning] if x]
        rows.append(
            TrialRow(
                timestamp=now_stamp(),
                run_id=run_id,
                mode=mode,
                algorithm=algorithm,
                round_index=round_index,
                attempt_index=attempt_index,
                feedback_used=feedback_used,
                enhancement_used=enhancement_used,
                branch=branch,
                instance=inst,
                parseable=sol.parseable,
                objective="" if sol.objective is None else f"{sol.objective:.6f}",
                bks="" if bk is None else f"{bk:.6f}",
                gap_percent="" if gp is None else f"{gp:.6f}",
                route_count=sol.route_count,
                constraint_violations=sol.constraint_violations,
                return_code=outcome.return_code,
                timeout=outcome.timeout,
                elapsed_sec=round(outcome.elapsed_sec, 3),
                code_path=outcome.code_path,
                stdout_path=outcome.stdout_path,
                stderr_path=outcome.stderr_path,
                warning=" | ".join(warn_parts),
            )
        )
    return rows


def write_csv(path: Path, rows: List[TrialRow]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(asdict(rows[0]).keys()) if rows else [f.name for f in TrialRow.__dataclass_fields__.values()]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(asdict(r))


def read_trial_rows(path: Path) -> List[TrialRow]:
    rows: List[TrialRow] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for raw in reader:
            rows.append(
                TrialRow(
                    timestamp=raw.get("timestamp", ""),
                    run_id=raw.get("run_id", ""),
                    mode=raw.get("mode", ""),
                    algorithm=raw.get("algorithm", ""),
                    round_index=int(raw.get("round_index") or 0),
                    attempt_index=int(raw.get("attempt_index") or 0),
                    feedback_used=_bool_from_row(raw.get("feedback_used", "")),
                    enhancement_used=_bool_from_row(raw.get("enhancement_used", "")),
                    branch=raw.get("branch", ""),
                    instance=raw.get("instance", ""),
                    parseable=_bool_from_row(raw.get("parseable", "")),
                    objective=raw.get("objective", ""),
                    bks=raw.get("bks", ""),
                    gap_percent=raw.get("gap_percent", ""),
                    route_count=int(float(raw.get("route_count") or 0)),
                    constraint_violations=raw.get("constraint_violations", ""),
                    return_code=int(float(raw.get("return_code") or 0)),
                    timeout=_bool_from_row(raw.get("timeout", "")),
                    elapsed_sec=float(raw.get("elapsed_sec") or 0.0),
                    code_path=raw.get("code_path", ""),
                    stdout_path=raw.get("stdout_path", ""),
                    stderr_path=raw.get("stderr_path", ""),
                    warning=raw.get("warning", ""),
                )
            )
    return rows


def write_dict_csv(path: Path, rows: Sequence[Dict[str, Any]], fieldnames: Optional[Sequence[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    names = list(fieldnames or (list(rows[0].keys()) if rows else []))
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=names)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _float_or_none_from_row(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except Exception:
        return None


def _bool_from_row(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() == "true"


def final_instance_rows(rows: Sequence[TrialRow]) -> List[TrialRow]:
    """Pick one final row per run/algorithm/mode/round/instance.

    If one or more attempts are valid, choose the valid attempt with the lowest
    objective. Otherwise choose the latest attempt so failure reasons are kept.
    """
    grouped: Dict[Tuple[str, str, str, int, str], List[TrialRow]] = {}
    for r in rows:
        if r.enhancement_used:
            continue
        key = (r.run_id, r.algorithm, r.mode, int(r.round_index), r.instance)
        grouped.setdefault(key, []).append(r)

    finals: List[TrialRow] = []
    for rs in grouped.values():
        valid = [r for r in rs if r.parseable and _float_or_none_from_row(r.objective) is not None]
        if valid:
            finals.append(sorted(valid, key=lambda r: float(r.objective))[0])
        else:
            finals.append(sorted(rs, key=lambda r: int(r.attempt_index), reverse=True)[0])
    return finals


def build_analysis_tables(rows: Sequence[TrialRow]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], str]:
    """Build publication-oriented analysis tables for the 4.3 experiment."""
    if not rows:
        return [], [], "No rows."

    metric_fields = [
        "algorithm",
        "mode",
        "rounds",
        "instances",
        "workflow_runs",
        "final_code_compile_success_rate",
        "final_code_execution_success_rate",
        "code_attempts",
        "attempt_compile_success_rate",
        "attempt_execution_success_rate",
        "final_valid_solution_rate",
        "final_constraint_violation_rate",
        "feedback_recovery_rate",
        "valid_final_count",
        "constraint_violation_count",
        "final_count",
        "average_gap_percent",
        "median_gap_percent",
    ]
    comparison_fields = [
        "algorithm",
        "rounds",
        "instances",
        "no_feedback_final_compile_rate",
        "feedback_final_compile_rate",
        "no_feedback_final_execution_rate",
        "feedback_final_execution_rate",
        "no_feedback_valid_rate",
        "feedback_valid_rate",
        "valid_rate_delta",
        "no_feedback_constraint_violation_rate",
        "feedback_constraint_violation_rate",
        "no_feedback_avg_gap",
        "feedback_avg_gap",
        "avg_gap_delta",
        "feedback_recovery_rate",
    ]

    by_group: Dict[Tuple[str, str], List[TrialRow]] = {}
    for r in rows:
        if r.enhancement_used:
            continue
        by_group.setdefault((r.algorithm, r.mode), []).append(r)

    finals = final_instance_rows(rows)
    finals_by_group: Dict[Tuple[str, str], List[TrialRow]] = {}
    for r in finals:
        finals_by_group.setdefault((r.algorithm, r.mode), []).append(r)

    metrics: List[Dict[str, Any]] = []
    for (algorithm, mode), rs in sorted(by_group.items()):
        attempt_map: Dict[Tuple[str, int], TrialRow] = {}
        for r in rs:
            attempt_map.setdefault((r.run_id, int(r.attempt_index)), r)
        attempts = list(attempt_map.values())
        compile_ok = [r for r in attempts if int(r.return_code) != 999]
        exec_ok = [r for r in attempts if int(r.return_code) == 0 and not _bool_from_row(r.timeout)]

        final_attempt_map: Dict[str, TrialRow] = {}
        for r in rs:
            current = final_attempt_map.get(r.run_id)
            if current is None or int(r.attempt_index) > int(current.attempt_index):
                final_attempt_map[r.run_id] = r
        final_attempts = list(final_attempt_map.values())
        final_compile_ok = [r for r in final_attempts if int(r.return_code) != 999]
        final_exec_ok = [r for r in final_attempts if int(r.return_code) == 0 and not _bool_from_row(r.timeout)]

        fs = finals_by_group.get((algorithm, mode), [])
        valid_finals = [r for r in fs if r.parseable]
        constraint_violations = [r for r in fs if str(getattr(r, "constraint_violations", "")).strip()]
        gaps = sorted(
            g
            for g in (_float_or_none_from_row(r.gap_percent) for r in valid_finals)
            if g is not None
        )
        avg_gap = sum(gaps) / len(gaps) if gaps else None
        median_gap = None
        if gaps:
            mid = len(gaps) // 2
            median_gap = gaps[mid] if len(gaps) % 2 else (gaps[mid - 1] + gaps[mid]) / 2

        recovery_rate = ""
        if mode == "structured":
            by_instance: Dict[Tuple[str, str], List[TrialRow]] = {}
            for r in rs:
                by_instance.setdefault((r.run_id, r.instance), []).append(r)
            initial_fail_count = 0
            recovered_count = 0
            for inst_rows in by_instance.values():
                initial = [r for r in inst_rows if int(r.attempt_index) == 0]
                feedback = [r for r in inst_rows if int(r.attempt_index) > 0]
                initial_valid = any(r.parseable for r in initial)
                if not initial_valid:
                    initial_fail_count += 1
                    if any(r.parseable for r in feedback):
                        recovered_count += 1
            recovery_rate = "" if initial_fail_count == 0 else f"{recovered_count / initial_fail_count:.6f}"

        rounds = sorted({int(r.round_index) for r in rs})
        instances = sorted({r.instance for r in rs})
        metrics.append(
            {
                "algorithm": algorithm,
                "mode": mode,
                "rounds": f"{min(rounds)}-{max(rounds)}" if rounds else "",
                "instances": len(instances),
                "workflow_runs": len(final_attempts),
                "final_code_compile_success_rate": "" if not final_attempts else f"{len(final_compile_ok) / len(final_attempts):.6f}",
                "final_code_execution_success_rate": "" if not final_attempts else f"{len(final_exec_ok) / len(final_attempts):.6f}",
                "code_attempts": len(attempts),
                "attempt_compile_success_rate": "" if not attempts else f"{len(compile_ok) / len(attempts):.6f}",
                "attempt_execution_success_rate": "" if not attempts else f"{len(exec_ok) / len(attempts):.6f}",
                "final_valid_solution_rate": "" if not fs else f"{len(valid_finals) / len(fs):.6f}",
                "final_constraint_violation_rate": "" if not fs else f"{len(constraint_violations) / len(fs):.6f}",
                "feedback_recovery_rate": recovery_rate,
                "valid_final_count": len(valid_finals),
                "constraint_violation_count": len(constraint_violations),
                "final_count": len(fs),
                "average_gap_percent": "" if avg_gap is None else f"{avg_gap:.6f}",
                "median_gap_percent": "" if median_gap is None else f"{median_gap:.6f}",
            }
        )

    metric_lookup = {(r["algorithm"], r["mode"]): r for r in metrics}
    comparisons: List[Dict[str, Any]] = []
    algorithms = sorted({r.algorithm for r in rows})
    for algorithm in algorithms:
        nf = metric_lookup.get((algorithm, "structured_no_feedback"))
        fb = metric_lookup.get((algorithm, "structured"))
        if not nf or not fb:
            continue
        nf_valid = _float_or_none_from_row(nf["final_valid_solution_rate"])
        fb_valid = _float_or_none_from_row(fb["final_valid_solution_rate"])
        nf_gap = _float_or_none_from_row(nf["average_gap_percent"])
        fb_gap = _float_or_none_from_row(fb["average_gap_percent"])
        comparisons.append(
            {
                "algorithm": algorithm,
                "rounds": fb["rounds"],
                "instances": fb["instances"],
                "no_feedback_final_compile_rate": nf["final_code_compile_success_rate"],
                "feedback_final_compile_rate": fb["final_code_compile_success_rate"],
                "no_feedback_final_execution_rate": nf["final_code_execution_success_rate"],
                "feedback_final_execution_rate": fb["final_code_execution_success_rate"],
                "no_feedback_valid_rate": nf["final_valid_solution_rate"],
                "feedback_valid_rate": fb["final_valid_solution_rate"],
                "valid_rate_delta": "" if nf_valid is None or fb_valid is None else f"{fb_valid - nf_valid:.6f}",
                "no_feedback_constraint_violation_rate": nf["final_constraint_violation_rate"],
                "feedback_constraint_violation_rate": fb["final_constraint_violation_rate"],
                "no_feedback_avg_gap": nf["average_gap_percent"],
                "feedback_avg_gap": fb["average_gap_percent"],
                "avg_gap_delta": "" if nf_gap is None or fb_gap is None else f"{fb_gap - nf_gap:.6f}",
                "feedback_recovery_rate": fb["feedback_recovery_rate"],
            }
        )

    def pct(value: Any) -> str:
        x = _float_or_none_from_row(value)
        return "N/A" if x is None else f"{100 * x:.2f}%"

    lines = [
        "4.3 Structured Workflow Experiment Analysis",
        "===========================================",
        "",
        "Metric definitions:",
        "- Compile success rate: unique generated-code attempts with no syntax error.",
        "- Execution success rate: unique generated-code attempts with return_code=0 and no timeout.",
        "- Final code compile/execution rates: one final generated code per workflow run after feedback, if feedback was triggered.",
        "- Final valid solution rate: one final record per algorithm/mode/round/instance, choosing the lowest independently feasible route-level objective among attempts.",
        "- Constraint violation rate: final records with controller-detected coverage, duplication, capacity, duration, or route-distance violations.",
        "- Feedback recovery rate: structured-mode instances where attempt 0 was invalid but a feedback attempt became valid.",
        "- Average/median gap: computed only over final valid solutions with BKS.",
        "",
        "By algorithm and mode:",
        "",
        "| Algorithm | Mode | Final compile | Final execution | Attempt compile | Attempt execution | Final valid | Constraint violations | Recovery | Avg gap | Median gap |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in metrics:
        lines.append(
            "| {algorithm} | {mode} | {final_code_compile_success_rate} | {final_code_execution_success_rate} | {attempt_compile_success_rate} | {attempt_execution_success_rate} | {final_valid_solution_rate} | {final_constraint_violation_rate} | {feedback_recovery_rate} | {average_gap_percent} | {median_gap_percent} |".format(
                algorithm=r["algorithm"],
                mode=r["mode"],
                final_code_compile_success_rate=pct(r["final_code_compile_success_rate"]),
                final_code_execution_success_rate=pct(r["final_code_execution_success_rate"]),
                attempt_compile_success_rate=pct(r["attempt_compile_success_rate"]),
                attempt_execution_success_rate=pct(r["attempt_execution_success_rate"]),
                final_valid_solution_rate=pct(r["final_valid_solution_rate"]),
                final_constraint_violation_rate=pct(r["final_constraint_violation_rate"]),
                feedback_recovery_rate=pct(r["feedback_recovery_rate"]) if r["feedback_recovery_rate"] != "" else "N/A",
                average_gap_percent=r["average_gap_percent"] or "N/A",
                median_gap_percent=r["median_gap_percent"] or "N/A",
            )
        )

    lines.extend(
        [
            "",
            "Structured feedback comparison:",
            "",
            "| Algorithm | Final compile no/fb | Final execution no/fb | Valid-rate delta | Constraint violation no/fb | Avg-gap delta | Feedback recovery |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for r in comparisons:
        lines.append(
            "| {algorithm} | {compile_pair} | {execution_pair} | {valid_rate_delta} | {constraint_pair} | {avg_gap_delta} | {feedback_recovery_rate} |".format(
                algorithm=r["algorithm"],
                compile_pair=f"{pct(r['no_feedback_final_compile_rate'])} / {pct(r['feedback_final_compile_rate'])}",
                execution_pair=f"{pct(r['no_feedback_final_execution_rate'])} / {pct(r['feedback_final_execution_rate'])}",
                valid_rate_delta=pct(r["valid_rate_delta"]),
                constraint_pair=f"{pct(r['no_feedback_constraint_violation_rate'])} / {pct(r['feedback_constraint_violation_rate'])}",
                avg_gap_delta=r["avg_gap_delta"] or "N/A",
                feedback_recovery_rate=pct(r["feedback_recovery_rate"]) if r["feedback_recovery_rate"] != "" else "N/A",
            )
        )

    return metrics, comparisons, "\n".join(lines)


def write_analysis_outputs(output_root: Path, rows: Sequence[TrialRow]) -> None:
    metrics, comparisons, report = build_analysis_tables(rows)
    metric_fields = [
        "algorithm",
        "mode",
        "rounds",
        "instances",
        "workflow_runs",
        "final_code_compile_success_rate",
        "final_code_execution_success_rate",
        "code_attempts",
        "attempt_compile_success_rate",
        "attempt_execution_success_rate",
        "final_valid_solution_rate",
        "final_constraint_violation_rate",
        "feedback_recovery_rate",
        "valid_final_count",
        "constraint_violation_count",
        "final_count",
        "average_gap_percent",
        "median_gap_percent",
    ]
    comparison_fields = [
        "algorithm",
        "rounds",
        "instances",
        "no_feedback_final_compile_rate",
        "feedback_final_compile_rate",
        "no_feedback_final_execution_rate",
        "feedback_final_execution_rate",
        "no_feedback_valid_rate",
        "feedback_valid_rate",
        "valid_rate_delta",
        "no_feedback_constraint_violation_rate",
        "feedback_constraint_violation_rate",
        "no_feedback_avg_gap",
        "feedback_avg_gap",
        "avg_gap_delta",
        "feedback_recovery_rate",
    ]
    write_dict_csv(output_root / "analysis_by_algorithm_mode.csv", metrics, metric_fields)
    write_dict_csv(output_root / "analysis_feedback_comparison.csv", comparisons, comparison_fields)
    write_text(output_root / "analysis_report.md", report)


# =========================
# 11. TRIAL EXECUTION
# =========================
def run_single_trial(
    *,
    profile: FlowProfile,
    client: DeepSeekClient,
    mode: str,
    algorithm: str,
    round_index: int,
    run_dir: Path,
    instances_dir: Path,
    instances: Sequence[str],
    bks: Dict[str, float],
    solver_time_limit: int,
    execution_timeout: int,
    max_feedback_rounds: int,
    quality_enhancement_rounds: int,
    seed: int,
    model: str,
    temperature: float,
) -> List[TrialRow]:
    algorithm = normalize_algorithm(algorithm)
    algorithm_label = ALGORITHM_LABELS[algorithm]
    run_id = f"{safe_name(algorithm)}_{safe_name(mode)}_round{round_index:03d}_seed{seed}"
    trial_dir = run_dir / run_id
    trial_dir.mkdir(parents=True, exist_ok=True)

    feedback_enabled = mode not in {"structured_no_feedback", "unstructured_no_feedback"}
    enhancement_enabled = mode in {"structured_enhanced", "unstructured_enhanced"}

    prompt = build_generation_prompt(profile, mode.replace("_enhanced", ""), algorithm, instances)
    write_text(trial_dir / "prompt_initial.txt", prompt)
    write_text(trial_dir / "workflow_node_diagnostics_initial.json", json_dumps(profile.diagnostics))

    all_rows: List[TrialRow] = []
    response = client.complete(prompt, model=model, temperature=temperature)
    write_text(trial_dir / "llm_response_initial.txt", response)
    code = extract_python_code(response)

    final_success = False
    parsed: Dict[str, ParsedSolution] = {}
    outcome: Optional[ExecutionOutcome] = None

    effective_feedback_rounds = max_feedback_rounds if feedback_enabled else 0
    for attempt_index in range(effective_feedback_rounds + 1):
        tag = "repair" if attempt_index > 0 else "initial"
        outcome = execute_generated_solver(
            code=code,
            run_dir=trial_dir,
            attempt_index=attempt_index,
            instances_dir=instances_dir,
            instances=instances,
            solver_time_limit=solver_time_limit,
            execution_timeout=execution_timeout,
            seed=seed,
            tag=tag,
        )
        parsed = parse_generated_outputs(trial_dir, tag, attempt_index, instances, outcome, instances_dir)
        branch = deterministic_branch(instances, outcome, parsed)
        all_rows.extend(
            rows_from_attempt(
                run_id=run_id,
                mode=mode,
                algorithm=algorithm_label,
                round_index=round_index,
                attempt_index=attempt_index,
                feedback_used=(attempt_index > 0),
                enhancement_used=False,
                branch=branch,
                parsed=parsed,
                bks=bks,
                outcome=outcome,
            )
        )
        write_text(trial_dir / f"parsed_{tag}_attempt{attempt_index}.json", json_dumps({k: asdict(v) for k, v in parsed.items()}))

        if branch == "branch_1":
            final_success = True
            break

        if attempt_index < effective_feedback_rounds:
            fb_prompt = build_feedback_prompt(profile, algorithm, instances, code, outcome, parsed, attempt_index)
            write_text(trial_dir / f"prompt_feedback_attempt{attempt_index + 1}.txt", fb_prompt)
            fb_resp = client.complete(fb_prompt, model=model, temperature=max(0.05, temperature * 0.8))
            write_text(trial_dir / f"llm_response_feedback_attempt{attempt_index + 1}.txt", fb_resp)
            code = extract_python_code(fb_resp)

    # Optional autonomous quality-enhancement module.
    if final_success and enhancement_enabled and quality_enhancement_rounds > 0 and outcome is not None:
        for q_round in range(quality_enhancement_rounds):
            weak = choose_weak_instances(parsed, bks, max_count=3)
            q_prompt = build_quality_prompt(profile, algorithm, instances, code, weak)
            write_text(trial_dir / f"prompt_quality_enhancement_{q_round}.txt", q_prompt)
            q_resp = client.complete(q_prompt, model=model, temperature=max(0.05, temperature * 0.8))
            write_text(trial_dir / f"llm_response_quality_enhancement_{q_round}.txt", q_resp)
            q_code = extract_python_code(q_resp)
            q_attempt_index = 100 + q_round
            q_tag = "quality"
            q_outcome = execute_generated_solver(
                code=q_code,
                run_dir=trial_dir,
                attempt_index=q_attempt_index,
                instances_dir=instances_dir,
                instances=instances,
                solver_time_limit=solver_time_limit,
                execution_timeout=execution_timeout,
                seed=seed + 1000 + q_round,
                tag=q_tag,
            )
            q_parsed = parse_generated_outputs(trial_dir, q_tag, q_attempt_index, instances, q_outcome, instances_dir)
            q_branch = deterministic_branch(instances, q_outcome, q_parsed)
            all_rows.extend(
                rows_from_attempt(
                    run_id=run_id,
                    mode=mode,
                    algorithm=algorithm_label,
                    round_index=round_index,
                    attempt_index=q_attempt_index,
                    feedback_used=False,
                    enhancement_used=True,
                    branch=q_branch,
                    parsed=q_parsed,
                    bks=bks,
                    outcome=q_outcome,
                )
            )
            write_text(trial_dir / f"parsed_quality_{q_round}.json", json_dumps({k: asdict(v) for k, v in q_parsed.items()}))

            # Keep the enhanced code as the next base only if parseable for all instances.
            if q_branch == "branch_1":
                code = q_code
                parsed = q_parsed
                outcome = q_outcome

    write_text(trial_dir / "workflow_node_diagnostics_final.json", json_dumps(profile.diagnostics))
    return all_rows


# =========================
# 12. SUMMARY REPORTING
# =========================
def summarize_rows(rows: Sequence[TrialRow]) -> str:
    if not rows:
        return "No rows."
    metrics, comparisons, _report = build_analysis_tables(rows)
    lines = ["Experiment summary", "==================", f"Total attempt records: {len(rows)}", ""]

    def pct(text: Any) -> str:
        value = _float_or_none_from_row(text)
        return "N/A" if value is None else f"{100 * value:.2f}%"

    for item in metrics:
        lines.append(f"Mode: {item['mode']}")
        lines.append(f"  Workflow runs: {item['workflow_runs']}")
        lines.append(f"  Final compile success rate: {pct(item['final_code_compile_success_rate'])}")
        lines.append(f"  Final execution success rate: {pct(item['final_code_execution_success_rate'])}")
        lines.append(f"  Final valid route rate: {pct(item['final_valid_solution_rate'])} ({item['valid_final_count']}/{item['final_count']})")
        lines.append(f"  Constraint violation rate: {pct(item['final_constraint_violation_rate'])} ({item['constraint_violation_count']}/{item['final_count']})")
        lines.append(f"  Feedback recovery rate: {pct(item['feedback_recovery_rate']) if item['feedback_recovery_rate'] != '' else 'N/A'}")
        lines.append(f"  Average gap over valid final solutions: {item['average_gap_percent'] or 'N/A'}")
        lines.append(f"  Median gap over valid final solutions: {item['median_gap_percent'] or 'N/A'}")
        lines.append("")

    if comparisons:
        lines.append("Structured feedback comparison")
        lines.append("------------------------------")
        for item in comparisons:
            lines.append(f"Algorithm: {item['algorithm']}")
            lines.append(f"  Final compile no/fb: {pct(item['no_feedback_final_compile_rate'])} / {pct(item['feedback_final_compile_rate'])}")
            lines.append(f"  Final execution no/fb: {pct(item['no_feedback_final_execution_rate'])} / {pct(item['feedback_final_execution_rate'])}")
            lines.append(f"  Valid-route delta: {pct(item['valid_rate_delta'])}")
            lines.append(f"  Constraint violation no/fb: {pct(item['no_feedback_constraint_violation_rate'])} / {pct(item['feedback_constraint_violation_rate'])}")
            lines.append(f"  Average-gap delta: {item['avg_gap_delta'] or 'N/A'}")
            lines.append(f"  Feedback recovery: {pct(item['feedback_recovery_rate']) if item['feedback_recovery_rate'] != '' else 'N/A'}")
            lines.append("")
    return "\n".join(lines)


# =========================
# 13. CLI
# =========================
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run structured AI-KM workflow experiments for LLM-generated MDVRP solvers."
    )
    parser.add_argument("--flow-file", type=str, default=DEFAULT_FLOW_FILE)
    parser.add_argument("--instances-dir", type=str, default="", help="Directory containing Cordeau MDVRP instance files with no extension.")
    parser.add_argument("--instances", type=str, default="", help="Comma-separated instance IDs. Default: read from .flow.")
    parser.add_argument("--bks-file", type=str, default="", help="Optional BKS markdown/text file used only by the controller evaluator. Default: auto-detect from .flow.")
    parser.add_argument("--output-root", type=str, default="workflow_experiment_outputs")
    parser.add_argument("--rounds", type=int, default=1)
    parser.add_argument(
        "--algorithms",
        type=str,
        default=DEFAULT_ALGORITHMS,
        help="Comma-separated algorithm ids. This main 4.3 runner supports exact/gurobi only.",
    )
    parser.add_argument(
        "--modes",
        type=str,
        default="structured_no_feedback,structured",
        help="Comma-separated: structured_no_feedback, structured. Other legacy modes remain accepted only for ablation checks.",
    )
    parser.add_argument(
        "--disable-nodes",
        type=str,
        default="",
        help="Comma-separated node IDs, node-name substrings, or node types to exclude from workflow context for ablation.",
    )
    parser.add_argument("--solver-time-limit", type=int, default=180)
    parser.add_argument("--execution-timeout", type=int, default=300)
    parser.add_argument("--max-feedback-rounds", type=int, default=2)
    parser.add_argument("--quality-enhancement-rounds", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260602)
    parser.add_argument("--api-key", type=str, default="")
    parser.add_argument("--api-url", type=str, default=DEEPSEEK_API_URL)
    parser.add_argument("--model", type=str, default="")
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--max-tokens", type=int, default=16384)
    parser.add_argument("--api-timeout", type=int, default=180)
    parser.add_argument("--api-retries", type=int, default=2)
    parser.add_argument("--analyze-only", action="store_true", help="Do not run LLM or solvers; rebuild analysis outputs from output-root/experiment_results.csv.")
    parser.add_argument("--dry-run", action="store_true", help="Build prompts but do not call the LLM API. Useful for checking setup.")
    parser.add_argument("--clean-output", action="store_true", help="Delete output-root before running.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    flow_file = Path(args.flow_file).expanduser().resolve()
    if not flow_file.exists():
        print(f"[ERROR] Flow file not found: {flow_file}", file=sys.stderr)
        return 2
    disabled_nodes = split_csv(args.disable_nodes)
    profile = FlowProfile(flow_file, disabled_nodes=disabled_nodes)

    instances = [x.strip().lower() for x in args.instances.split(",") if x.strip()] if args.instances else profile.selected_instances()
    if not instances:
        print("[ERROR] No selected instances found.", file=sys.stderr)
        return 2

    instance_dir_text = args.instances_dir or profile.instance_dir_from_flow()
    if not instance_dir_text:
        print("[ERROR] Please provide --instances-dir. The path in the .flow file was not detected.", file=sys.stderr)
        return 2
    instances_dir = Path(instance_dir_text).expanduser()
    if not args.dry_run and not instances_dir.exists():
        print(f"[ERROR] instances-dir does not exist: {instances_dir}", file=sys.stderr)
        return 2

    algorithms = parse_algorithms(args.algorithms)
    first_algorithm = algorithms[0]
    model = args.model or DEFAULT_DEEPSEEK_MODEL or profile.model_name_from_flow(first_algorithm)
    api_key = args.api_key or os.environ.get("DEEPSEEK_API_KEY", "") or DEEPSEEK_API_KEY
    llm_cfg = LLMConfig(
        api_key=api_key,
        api_url=args.api_url,
        model=model,
        temperature=args.temperature,
        max_tokens=args.max_tokens,
        timeout=args.api_timeout,
        retries=args.api_retries,
    )
    client = DeepSeekClient(llm_cfg, dry_run=args.dry_run)

    output_root = Path(args.output_root).expanduser().resolve()
    if args.analyze_only:
        existing_rows = read_trial_rows(output_root / "experiment_results.csv")
        if not existing_rows:
            print(f"[ERROR] No experiment rows found at: {output_root / 'experiment_results.csv'}", file=sys.stderr)
            return 2
        write_analysis_outputs(output_root, existing_rows)
        write_text(output_root / "summary.txt", summarize_rows(existing_rows))
        print(f"[INFO] Analysis rebuilt from: {output_root / 'experiment_results.csv'}")
        print(f"[INFO] Analysis saved to: {output_root / 'analysis_report.md'}")
        return 0
    if args.clean_output and output_root.exists():
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    auto_bks_file = profile.bks_file_from_flow()
    bks_path = Path(args.bks_file or auto_bks_file).expanduser() if (args.bks_file or auto_bks_file) else None
    bks = parse_bks_file(bks_path, instances)

    modes = [m.strip() for m in args.modes.split(",") if m.strip()]
    all_rows: List[TrialRow] = []

    print(f"[INFO] Flow file: {flow_file}")
    print(f"[INFO] Instances: {', '.join(instances)}")
    print(f"[INFO] Instances dir: {instances_dir}")
    print(f"[INFO] Algorithms: {', '.join(algorithms)}")
    print(f"[INFO] Modes: {', '.join(modes)}")
    print(f"[INFO] Rounds: {args.rounds}")
    print(f"[INFO] Model: {model or 'N/A'}")
    if disabled_nodes:
        print(f"[INFO] Disabled node specs: {', '.join(disabled_nodes)}")
        print(f"[INFO] Disabled nodes matched: {json_dumps(profile.disabled_node_summary())}")
    if bks:
        print(f"[INFO] BKS loaded for: {', '.join(sorted(bks))}")
    elif bks_path:
        print(f"[WARN] BKS file was found/provided, but no BKS values were parsed: {bks_path}")

    # Save experiment setup for reproducibility.
    write_text(
        output_root / "experiment_setup.json",
        json_dumps(
            {
                "timestamp": now_stamp(),
                "flow_file": str(flow_file),
                "instances_dir": str(instances_dir),
                "instances": instances,
                "bks_file": str(bks_path) if bks_path else "",
                "bks_loaded": bks,
                "algorithms": algorithms,
                "modes": modes,
                "disabled_node_specs": disabled_nodes,
                "disabled_nodes_matched": profile.disabled_node_summary(),
                "rounds": args.rounds,
                "solver_time_limit": args.solver_time_limit,
                "execution_timeout": args.execution_timeout,
                "max_feedback_rounds": args.max_feedback_rounds,
                "quality_enhancement_rounds": args.quality_enhancement_rounds,
                "model": model,
                "temperature": args.temperature,
                "api_retries": args.api_retries,
                "dry_run": args.dry_run,
            }
        ),
    )

    if args.dry_run:
        # Build and save all mode prompts, then exit.
        prompt_dir = output_root / "dry_run_prompts"
        prompt_dir.mkdir(parents=True, exist_ok=True)
        for algorithm in algorithms:
            for mode in modes:
                prompt = build_generation_prompt(profile, mode.replace("_enhanced", ""), algorithm, instances)
                write_text(prompt_dir / f"prompt_{safe_name(algorithm)}_{safe_name(mode)}.txt", prompt)
        write_text(output_root / "workflow_node_diagnostics.json", json_dumps(profile.diagnostics))
        print(f"[DRY-RUN] Prompts saved to: {prompt_dir}")
        return 0

    for round_index in range(1, args.rounds + 1):
        for algorithm in algorithms:
            for mode in modes:
                print(f"[INFO] Starting algorithm={algorithm}, mode={mode}, round={round_index}/{args.rounds}")
                trial_model = args.model or DEFAULT_DEEPSEEK_MODEL or profile.model_name_from_flow(algorithm)
                try:
                    rows = run_single_trial(
                        profile=profile,
                        client=client,
                        mode=mode,
                        algorithm=algorithm,
                        round_index=round_index,
                        run_dir=output_root,
                        instances_dir=instances_dir,
                        instances=instances,
                        bks=bks,
                        solver_time_limit=args.solver_time_limit,
                        execution_timeout=args.execution_timeout,
                        max_feedback_rounds=args.max_feedback_rounds,
                        quality_enhancement_rounds=args.quality_enhancement_rounds,
                        seed=args.seed + round_index,
                        model=trial_model,
                        temperature=args.temperature,
                    )
                    all_rows.extend(rows)
                    write_csv(output_root / "experiment_results.csv", all_rows)
                    write_text(output_root / "summary.txt", summarize_rows(all_rows))
                    write_analysis_outputs(output_root, all_rows)
                    write_text(output_root / "workflow_node_diagnostics.json", json_dumps(profile.diagnostics))
                    print(f"[INFO] Finished algorithm={algorithm}, mode={mode}, round={round_index}; cumulative records={len(all_rows)}")
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    err_dir = output_root / "controller_errors"
                    err_dir.mkdir(parents=True, exist_ok=True)
                    err_path = err_dir / f"error_{safe_name(algorithm)}_{safe_name(mode)}_round{round_index}.txt"
                    write_text(err_path, traceback.format_exc())
                    print(f"[ERROR] Trial failed at controller level: {e}. Details: {err_path}", file=sys.stderr)

    if all_rows:
        write_csv(output_root / "experiment_results.csv", all_rows)
        write_analysis_outputs(output_root, all_rows)
        summary = summarize_rows(all_rows)
        write_text(output_root / "summary.txt", summary)
        print("\n" + summary)
        print(f"[INFO] Results saved to: {output_root / 'experiment_results.csv'}")
        print(f"[INFO] Summary saved to: {output_root / 'summary.txt'}")
    else:
        print("[WARN] No experiment rows were produced.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
