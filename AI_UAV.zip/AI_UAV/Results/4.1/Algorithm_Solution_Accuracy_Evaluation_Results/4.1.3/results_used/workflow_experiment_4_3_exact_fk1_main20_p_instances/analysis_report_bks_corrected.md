4.3 Structured Workflow Experiment Analysis
===========================================

Metric definitions:
- Compile success rate: unique generated-code attempts with no syntax error.
- Execution success rate: unique generated-code attempts with return_code=0 and no timeout.
- Final code compile/execution rates: one final generated code per workflow run after feedback, if feedback was triggered.
- Final valid solution rate: one final record per algorithm/mode/round/instance, choosing the lowest independently feasible route-level objective among attempts.
- Constraint violation rate: final records with controller-detected coverage, duplication, capacity, duration, or route-distance violations.
- Feedback recovery rate: structured-mode instances where attempt 0 was invalid but a feedback attempt became valid.
- Average/median gap: computed only over final valid solutions with BKS.

By algorithm and mode:

| Algorithm | Mode | Final compile | Final execution | Attempt compile | Attempt execution | Final valid | Constraint violations | Recovery | Avg gap | Median gap |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A1_gurobi_restricted_route_pool | structured | 100.00% | 90.00% | 97.56% | 82.93% | 90.00% | 1.25% | 82.22% | 58.649235 | 39.011058 |
| A1_gurobi_restricted_route_pool | structured_no_feedback | 90.00% | 80.00% | 90.00% | 80.00% | 22.50% | 17.50% | N/A | 74.598977 | 48.477830 |

Structured feedback comparison:

| Algorithm | Final compile no/fb | Final execution no/fb | Valid-rate delta | Constraint violation no/fb | Avg-gap delta | Feedback recovery |
|---|---:|---:|---:|---:|---:|---:|
| A1_gurobi_restricted_route_pool | 90.00% / 100.00% | 80.00% / 90.00% | 67.50% | 17.50% / 1.25% | -15.949742 | 82.22% |