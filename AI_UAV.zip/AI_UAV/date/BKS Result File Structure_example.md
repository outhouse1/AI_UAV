# Node: MDVRP BKS Result File Structure

This node describes the BKS result file structure for the selected Cordeau MDVRP instances used in the first-layer framework validation experiment.

The selected BKS result files are:

```text
pr01.res
p01.res
p02.res
p03.res
p12.res
pr02.res
```

The corresponding instance files are located in:

```text
date/6-mdvrp
```

---

## 1. BKS Data Structure

Each BKS result file contains two parts:

1. The first line: reference BKS objective value;
2. The following lines: route-level reference solution records.

General structure:

```text
reference_objective_value
base_sequence_id  route_id  route_distance_or_duration  route_load  route_sequence
base_sequence_id  route_id  route_distance_or_duration  route_load  route_sequence
...
```

In many `.res` files, the route sequence is written as:

```text
0  customer_1  customer_2  ...  customer_k  0
```

In some `.res` files, especially pr-series files, the route sequence may instead be written with the actual depot node ID at both ends:

```text
actual_depot_node_id  customer_1  customer_2  ...  customer_k  actual_depot_node_id
```

The parser should support both formats.

---

## 2. Reference Objective Value

The first line contains one numerical value:

```text
reference_objective_value
```

This value is the reference BKS objective value for the instance.

Use boundary:

- The reference value should only be used by the independent evaluation node.
- It should not be injected into algorithm-generation prompts.
- It should not be used as a prior knowledge target for the LLM.
- It should not be used to induce the model to generate routes close to the BKS objective value.

---

## 3. BKS Values for the Six Selected Instances

| Instance | BKS File | Reference BKS Objective Value |
|---|---|---:|
| pr01 | pr01.res | 861.32 |
| p01 | p01.res | 576.87 |
| p02 | p02.res | 473.53 |
| p03 | p03.res | 641.19 |
| p12 | p12.res | 1318.95 |
| pr02 | pr02.res | 1288.37 |

---

## 4. Route Line Fields

A route line generally contains the following fields:

```text
base_sequence_id  route_id  route_distance_or_duration  route_load  route_sequence
```

Field definitions:

| Field | Meaning |
|---|---|
| base_sequence_id | Depot sequence number in the result file, starting from 1. It is not necessarily the actual depot node ID in the instance file. |
| route_id | Route or vehicle identifier under the corresponding depot. |
| route_distance_or_duration | Reported route length or route duration. For instances with service times, this may include service time. |
| route_load | Total demand served by this route. |
| route_sequence | Ordered route sequence. It may use either 0 markers or actual depot node IDs at the beginning and end. |

---

## 5. Depot Sequence and Actual Depot Node Mapping

The `.res` file uses `base_sequence_id` starting from 1.

The actual depot node ID in the instance file is:

```text
actual_depot_node_id = customer_count + base_sequence_id
```

Examples:

- In p01, `customer_count = 50`; therefore, `base_sequence_id = 1` corresponds to actual depot node 51.
- In p01, `base_sequence_id = 4` corresponds to actual depot node 54.
- In pr01, `customer_count = 48`; therefore, `base_sequence_id = 1` corresponds to actual depot node 49.
- In pr02, `customer_count = 96`; therefore, `base_sequence_id = 4` corresponds to actual depot node 100.

---

## 6. Route Boundary Parsing Rule

The evaluator should parse route boundaries using the following rule.

### Case 1: Zero-boundary format

```text
base_sequence_id  route_id  route_distance_or_duration  route_load  0  customer_sequence  0
```

Interpretation:

- The first 0 means the route starts from the depot associated with `base_sequence_id`.
- The final 0 means the route returns to the same depot.
- The values between the two 0 markers are customer IDs.

### Case 2: Actual-depot-boundary format

```text
base_sequence_id  route_id  route_distance_or_duration  route_load  actual_depot_node_id  customer_sequence  actual_depot_node_id
```

Interpretation:

- The first and final route-sequence values are actual depot node IDs.
- These depot node IDs must match:

```text
actual_depot_node_id = customer_count + base_sequence_id
```

- The values between the two depot IDs are customer IDs.

The parser should normalize both cases to the following internal representation:

```text
base_sequence_id
actual_depot_node_id
customer_sequence
```

---

## 7. Route Distance and Route Load Recalculation

The independent evaluator should not blindly trust the route-level distance or load reported in the `.res` file.

Recalculation rules:

1. Read the customer sequence from each route.
2. Recalculate route load by summing the demand of all customers in the route.
3. Recalculate travel distance using the instance coordinates and the Euclidean distance matrix.
4. If the instance has nonzero service times, separately compute route duration as:

```text
route_duration = travel_distance + sum(customer_service_times)
```

5. Compare recalculated route load with the reported `route_load`.
6. Compare recalculated route travel distance or duration with the reported route field according to the instance type and file convention.

Suggested numerical tolerance:

```text
0.01
```

Important note:

- The first-line BKS objective is used as the reference objective value.
- In instances with nonzero service times, route-level reported values may reflect route duration, while the first-line objective may represent travel distance excluding service time.
- Therefore, the evaluator should distinguish objective-distance checking from route-duration feasibility checking.

---

## 8. Route-Level Feasibility Checks

The independent evaluator should conduct the following checks for both BKS files and algorithm-generated solutions.

### 8.1 Customer Coverage Check

Each customer must be served exactly once.

The following cases are not allowed:

- A customer is not served;
- A customer is served more than once;
- A route contains a non-customer node inside the customer sequence;
- A route contains an ID outside the valid customer range.

### 8.2 Route Closure Check

Each route must start from one depot and return to the same depot.

For zero-boundary format, both boundary markers are 0.

For actual-depot-boundary format, the first and final route-sequence values must be the same actual depot node ID.

### 8.3 Depot Consistency Check

Each route must be associated with exactly one depot.

The route boundary depot must match the depot implied by `base_sequence_id`.

### 8.4 Vehicle Count Check

For each depot, the number of selected routes must not exceed `vehicles_per_depot` in the corresponding instance file.

### 8.5 Capacity Check

For each route, the total demand of served customers must not exceed the vehicle capacity of the associated depot.

### 8.6 Maximum Route-Duration Check

If the associated depot has `maximum_route_duration > 0`, the evaluator must check:

```text
travel_distance + service_time_sum <= maximum_route_duration
```

If `maximum_route_duration = 0`, this constraint is not activated.

### 8.7 Objective Consistency Check

The evaluator should check whether the sum of recalculated route travel distances is consistent with the first-line objective value within a numerical tolerance.

If an algorithm-generated solution reports an objective value lower than the reference BKS value, the evaluator must first conduct a full route-level feasibility audit. A negative deviation can only be treated as a valid improvement if all constraints are independently verified.

---

## 9. Reference Deviation Calculation

After an algorithm-generated solution passes all feasibility checks, the independent evaluator may compute its deviation from the reference BKS value:

```text
reference_deviation_percent =
    (algorithm_objective_value - reference_bks_value)
    / reference_bks_value
    * 100
```

Field definitions:

| Field | Meaning |
|---|---|
| algorithm_objective_value | Feasible objective value produced by the algorithm. |
| reference_bks_value | Reference BKS objective value from the first line of the `.res` file. |
| reference_deviation_percent | Percentage deviation from the reference BKS value. |

Rules:

- Compute reference deviation only for solutions that pass the independent feasibility check.
- Infeasible solutions must not be included in average deviation calculations.
- Negative deviations must be accompanied by a full route-level feasibility audit.
- A negative deviation must not be interpreted as an improvement over BKS unless all constraints are verified independently.
