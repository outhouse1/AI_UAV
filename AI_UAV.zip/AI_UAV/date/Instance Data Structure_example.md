# Node: MDVRP Instance Data Structure

This node describes the input data structure for the selected Cordeau MDVRP instances used in the first-layer framework validation experiment.

The selected instances are:

- pr01
- p01
- p02
- p03
- p12
- pr02

The instance files are located in:

```text
date/6-mdvrp
```

These instance files have no file extension. The file name itself is the instance identifier.

## 1. Instance File Naming Rule

The workflow uses the following six representative instance files as unified input data:

```text
pr01
p01
p02
p03
p12
pr02
```


## 2. General File Structure

Each instance file consists of four parts:

1. Header information;
2. Depot-level constraint information;
3. Customer node information;
4. Depot node information.

The general reading order is:

1. Read the first line to obtain the problem type, number of vehicles per depot, number of customers, and number of depots;
2. Read the following depot-level constraint records to obtain the maximum route duration and vehicle capacity for each depot;
3. Read the customer node records;
4. Read the depot node records.


## 3. Header Fields

The first line contains four fields:

```text
problem_type  vehicles_per_depot  customer_count  depot_count
```

Field definitions:

| Field | Meaning |
|---|---|
| problem_type | Problem type identifier. In this experiment, the value is 2, indicating the MDVRP. |
| vehicles_per_depot | Maximum number of vehicles available at each depot. In this workflow, vehicles may be interpreted as UAVs. |
| customer_count | Number of customers. In this workflow, customers may be interpreted as demand points. |
| depot_count | Number of depots. In this workflow, depots may be interpreted as UAV bases. |

---

## 4. Depot-Level Constraint Records

Immediately after the header, the file provides depot-level constraint records. The number of these records equals `depot_count`.

Each depot-level constraint record contains two fields:

```text
maximum_route_duration  vehicle_capacity
```

Field definitions:

| Field | Meaning |
|---|---|
| maximum_route_duration | Maximum duration or distance allowed for a single route from the corresponding depot. |
| vehicle_capacity | Maximum load capacity of a vehicle from the corresponding depot. |

Processing rules:

- If `maximum_route_duration = 0`, the route-duration constraint is not activated for that depot.
- If `maximum_route_duration > 0`, the route-duration constraint must be checked during solution construction and feasibility evaluation.
- The vehicle capacity must be checked for every generated route.


## 5. Customer Node Records

After the depot-level constraint records, the file provides customer node records. The number of customer records equals `customer_count`.

Each customer record generally follows this structure:

```text
node_id  x_coordinate  y_coordinate  service_time  demand  frequency  available_combination_count  available_combination_list
```

Field definitions:

| Field | Meaning |
|---|---|
| node_id | Customer node identifier. Customer IDs start from 1. |
| x_coordinate | X-coordinate of the customer node. |
| y_coordinate | Y-coordinate of the customer node. |
| service_time | Service time required at the customer node. |
| demand | Demand quantity of the customer node. |
| frequency | Service frequency. In the basic MDVRP setting, this is usually 1. |
| available_combination_count | Number of available visit combinations in the original Cordeau format. |
| available_combination_list | Encoded visit-combination list in the original Cordeau format. |
