# A2 Prior Knowledge: Large Neighborhood Search for MDVRP

## Purpose
Guide the heuristic reasoning node to generate stable LNS code that runs without parsing errors and returns a feasible route-level MDVRP solution whenever possible.

## Selected Instances
```text
pr01, p01, p02, p03, p12, pr02
```

## Minimal Data-Parsing Guard
The code must use a robust parser.

Do not parse customer or depot node records with:
```python
list(map(int, line.split()))
```

Parsing rules:
```text
header fields: int
maximum_route_duration: float
vehicle_capacity: float
node_id: int
x_coordinate: float
y_coordinate: float
service_time: float
demand: float
frequency/count fields: int if present
```

Coordinates may be decimal or negative. Preserve original customer IDs and actual depot node IDs.

## Solution Representation
A solution is a set of depot-based routes. Each route must store:
```text
assigned depot sequence ID
actual depot node ID
ordered customer ID sequence
route distance
route load
route duration
```

## Stable LNS Logic
Use a simple and stable LNS structure:
```text
1. Build a feasible constructive initial solution.
2. Remove a small subset of customers.
3. Reinsert every removed customer using feasible insertion.
4. Accept only complete feasible candidate solutions.
5. Track the best feasible solution.
6. Stop by time limit, iteration limit, or no-improvement limit.
```

During insertion and repair:
```text
check capacity before insertion
check route duration when active
open a new route only if the depot still has available vehicles
do not accept a candidate if any removed customer remains uninserted
```

## Stable Local Search
Use only simple operators:
```text
intra-route 2-opt
single-customer relocation
single-customer swap
```

Do not add many complex operators. Stability is more important than algorithmic complexity.

## Feasibility Requirements
The reported solution must satisfy:
```text
each customer is served exactly once
no missing or duplicated customers
each route starts from and returns to the same assigned depot
route load does not exceed vehicle capacity
route duration does not exceed the active maximum route duration
number of routes assigned to each depot does not exceed vehicle limit
reported objective equals recalculated total route distance
```

## Output Requirement
Print route-level results in BKS-like format:
```text
objective_value
depot_sequence_id  route_id  route_distance  route_load  0  customer_sequence  0
```

Use depot sequence ID in the first column and original customer IDs in the route sequence.

## Prohibited
```text
Do not read BKS or .res files.
Do not report the last candidate instead of the best feasible solution.
Do not drop capacity or active duration constraints.
Do not report incomplete solutions as feasible.
```
