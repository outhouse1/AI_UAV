# A3 Prior Knowledge: Genetic Algorithm with Split Decoding for MDVRP

## Purpose
Guide the metaheuristic reasoning node to generate stable GA code that keeps chromosomes and decoded solutions separate, avoids object-type errors, and returns a feasible route-level MDVRP solution whenever possible.

## Selected Instances
```text
pr01, p01, p02, p03, p12, pr02
```

## Minimal Data-Parsing Guard
The code must use a robust parser.

Do not parse customer or depot node records with:
```python
list(map(int, line.split()))
```

Parsing rules:
```text
header fields: int
maximum_route_duration: float
vehicle_capacity: float
node_id: int
x_coordinate: float
y_coordinate: float
service_time: float
demand: float
frequency/count fields: int if present
```

Coordinates may be decimal or negative. Preserve original customer IDs and actual depot node IDs.

## Chromosome and Solution Type Guard
Use customer-ID permutations as chromosomes:
```text
[customer_id_1, customer_id_2, ..., customer_id_n]
```

Keep raw chromosomes and decoded solutions in separate containers:
```text
population_chromosomes: list of customer-ID permutations
decoded_solutions: list of Solution objects
```

Rules:
```text
crossover and mutation operate only on chromosomes
split decoding converts chromosomes into Solution objects
get_fitness is called only on Solution objects
feasibility checks are called only on Solution objects
best_solution is selected from decoded_solutions, not from raw chromosomes
```

Avoid:
```python
min(population_chromosomes, key=lambda x: x.get_fitness())
```

Use:
```python
best_idx = min(range(len(decoded_solutions)), key=lambda i: decoded_solutions[i].get_fitness())
best_solution = decoded_solutions[best_idx].copy()
```

## Split-Decoding Requirements
The decoder must:
```text
convert each chromosome into depot-based routes
check capacity during decoding
check route duration when active
open a new route only if depot vehicle availability allows it
mark the decoded solution infeasible if any customer cannot be inserted
```

## Feasible Fallback
Before running GA, build one feasible constructive solution if possible. If GA fails to improve or produces no feasible individual, report the constructive feasible solution and clearly mark the status.

## Feasibility Requirements
The reported solution must satisfy:
```text
each customer is served exactly once
no missing or duplicated customers
each route starts from and returns to the same assigned depot
route load does not exceed vehicle capacity
route duration does not exceed the active maximum route duration
number of routes assigned to each depot does not exceed vehicle limit
reported objective equals recalculated total route distance
```

## Output Requirement
Print route-level results in BKS-like format:
```text
objective_value
depot_sequence_id  route_id  route_distance  route_load  0  customer_sequence  0
```

Use depot sequence ID in the first column and original customer IDs in the route sequence.

## Prohibited
```text
Do not read BKS or .res files.
Do not call Solution methods on raw list chromosomes.
Do not decode routes without depot assignment.
Do not drop capacity or active duration constraints.
Do not report infeasible individuals as final solutions.
```
