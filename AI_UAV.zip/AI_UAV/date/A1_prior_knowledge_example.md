# A1 Prior Knowledge: Exact / Restricted Route-Pool Optimization for MDVRP

## Purpose
Guide the exact-algorithm reasoning node to generate Python code that runs stably, avoids combinatorial explosion, and returns a route-level MDVRP solution.

## Selected Instances
```text
pr01, p01, p02, p03, p12, pr02
```

## Minimal Data-Parsing Guard
The code must use a robust parser.

Do not parse customer or depot node records with:
```python
list(map(int, line.split()))
```

Parsing rules:
```text
header fields: int
maximum_route_duration: float
vehicle_capacity: float
node_id: int
x_coordinate: float
y_coordinate: float
service_time: float
demand: float
frequency/count fields: int if present
```

Coordinates may be decimal or negative. Preserve original customer IDs and actual depot node IDs.

## Exact-Solver Guard
A route-based exact strategy may be used, but route-pool generation must be bounded.

Do not enumerate all customer combinations and all permutations for large route pools.

Use:
```text
single-customer routes
nearest-neighbour routes
savings or cheapest-insertion routes
limited random feasible routes
route-pool size cap
route-generation time cap
Gurobi time limit
```

If the route pool is bounded, report the result as a restricted route-pool MIP solution, not a proven global optimum.

## Feasible Fallback
To ensure the program returns a result, build a simple feasible constructive solution before optimization whenever possible. If Gurobi fails, times out, or is unavailable, output the best feasible constructed solution and clearly mark the solver status.

Do not claim exact optimality for fallback solutions.

## Feasibility Requirements
The reported solution must satisfy:
```text
each customer is served exactly once
each route starts from and returns to the same assigned depot
route load does not exceed vehicle capacity
route duration does not exceed the active maximum route duration
number of routes assigned to each depot does not exceed vehicle limit
reported objective equals recalculated total route distance
```

## Output Requirement
Print route-level results in BKS-like format:
```text
objective_value
depot_sequence_id  route_id  route_distance  route_load  0  customer_sequence  0
```

Use depot sequence ID in the first column and original customer IDs in the route sequence.

## Prohibited
```text
Do not read BKS or .res files.
Do not hard-code reference objective values.
Do not drop capacity or active duration constraints.
Do not report a solution without route-level details.
```
